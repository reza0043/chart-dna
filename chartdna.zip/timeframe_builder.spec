# -*- mode: python ; coding: utf-8 -*-
# فایل ساخت exe کمکی برای اسکریپت scripts/timeframe_builder.py
# این فایل باید قبل از app.spec ساخته شود (به README.txt نگاه کنید)،
# چون app.spec آن را داخل خروجی نهایی کپی می‌کند.

a = Analysis(
    ['scripts/timeframe_builder.py'],
    pathex=[],
    binaries=[],
    datas=[],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='timeframe_builder',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
