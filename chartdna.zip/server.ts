import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

let genAIClient: GoogleGenAI | null = null;

function getGenAI(): GoogleGenAI {
  if (!genAIClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("GEMINI_API_KEY environment variable is not configured.");
    }
    genAIClient = new GoogleGenAI({ apiKey: key });
  }
  return genAIClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON Body Parser with higher limit for chart images
  app.use(express.json({ limit: "25mb" }));

  // Health endpoint
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", service: "ChartDNA Engine" });
  });

  // AI Vision & Technical Chart Analysis Endpoint
  app.post("/api/ai-vision", async (req, res) => {
    try {
      const { imageBase64, promptExtra, patternContext } = req.body;
      if (!imageBase64) {
        return res.status(400).json({ error: "Missing imageBase64 in request body." });
      }

      // Check if API key is provided
      if (!process.env.GEMINI_API_KEY) {
        return res.status(400).json({
          error: "GEMINI_API_KEY is not set. Please provide a GEMINI_API_KEY in the environment settings to use AI Chart Vision."
        });
      }

      const ai = getGenAI();

      // Clean base64 string
      const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, "");

      const systemPrompt = `You are ChartDNA's Chief Technical Market Analyst.
Analyze the provided financial chart image with precision.

Respond in structured Markdown format with these exact sections:
1. **Market Context & Trend Direction**: Primary trend (Bullish, Bearish, or Ranging/Consolidation) across visible time horizons.
2. **Key Price Levels**: Significant horizontal resistance, support zones, supply/demand imbalances, or previous high/low pivot targets.
3. **Recognized Chart Patterns**: Any classical or algorithmic patterns observed (e.g. Double Top/Bottom, Head & Shoulders, Flags/Pennants, Triangles, Fair Value Gaps, Liquidity Sweeps).
4. **Probabilistic Forward Outlook**: Probability breakdown of next probable legs (e.g., Continuation vs. Pullback/Reversal with estimated percentage likelihoods).
5. **Technical Confirmation Factors**: Volume clues, candle wick rejections, and momentum characteristics.
6. **Disclaimer**: Note that this visual AI interpretation is for informational and pattern education purposes only and does not constitute financial advice.

Write clearly and professionally. You may provide the response in English or Persian (if requested), formatted with bold headings and clean bullet points.`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [
          {
            role: "user",
            parts: [
              {
                inlineData: {
                  mimeType: "image/png",
                  data: cleanBase64,
                },
              },
              {
                text: `${systemPrompt}\n\nAdditional user notes or focus area: ${promptExtra || "Analyze general pattern and price action"}\nPattern context: ${patternContext ? JSON.stringify(patternContext) : "None"}`
              }
            ]
          }
        ]
      });

      const analysisText = response.text || "No analysis text generated.";
      res.json({ success: true, analysis: analysisText });
    } catch (error: any) {
      console.error("AI Vision Error:", error);
      res.status(500).json({
        error: error.message || "Failed to generate AI chart analysis."
      });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`ChartDNA Server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
