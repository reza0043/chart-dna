import React, { useState, useEffect, useRef } from "react";
import { Header } from "./components/Header";
import { SidebarControls } from "./components/SidebarControls";
import { ImageCropperCanvas } from "./components/ImageCropperCanvas";
import { ComparativeChart } from "./components/ComparativeChart";
import { ResultsTable } from "./components/ResultsTable";
import { SettingsModal } from "./components/SettingsModal";
import { CandleChartModal } from "./components/CandleChartModal";
import { AIVisionModal } from "./components/AIVisionModal";
import { MyDNAModal } from "./components/MyDNAModal";

import {
  MarketDataset,
  MatchResult,
  SearchConfig,
  MyDNAPattern,
  TrendBreakdown,
} from "./engine/types";
import { PRESET_PATTERNS } from "./engine/presetPatterns";
import { PatternMatcher } from "./engine/matcher";

const DEFAULT_CONFIG: SearchConfig = {
  threshold: 75,
  patternLength: 60,
  futureCandles: 20,
  topResults: 50,
  rangeLookback: 5,
  skipOverlap: true,
  weights: {
    pearson: 0.4,
    dtw: 0.3,
    slope: 0.15,
    structural: 0.15,
  },
};

export const App: React.FC = () => {
  // Localization
  const [isPersian, setIsPersian] = useState<boolean>(false);

  // Datasets (empty by default so user can import their own market CSV data)
  const [datasets, setDatasets] = useState<MarketDataset[]>([]);
  const [selectedDatasetIds, setSelectedDatasetIds] = useState<string[]>([]);

  // Engine Configuration
  const [config, setConfig] = useState<SearchConfig>(DEFAULT_CONFIG);

  // Active Reference Pattern (80 normalized values)
  const [referencePattern, setReferencePattern] = useState<number[] | null>(null);
  const [referencePatternName, setReferencePatternName] = useState<string>("");

  // Chart Image Source
  const [imageSrc, setImageSrc] = useState<string | null>(null);

  // Saved My DNA Patterns Library
  const [savedPatterns, setSavedPatterns] = useState<MyDNAPattern[]>(() => {
    const fromStorage = localStorage.getItem("chartdna_saved_patterns");
    if (fromStorage) {
      try {
        return JSON.parse(fromStorage);
      } catch (e) {
        console.error(e);
      }
    }
    // Initial library from presets
    return PRESET_PATTERNS.map((p) => ({
      id: p.id,
      name: p.name,
      category: p.category,
      createdAt: "2024-01-01",
      points: p.points,
      normalizedPoints: p.points,
      notes: p.description,
    }));
  });

  // Save to LocalStorage
  useEffect(() => {
    localStorage.setItem("chartdna_saved_patterns", JSON.stringify(savedPatterns));
  }, [savedPatterns]);

  // Search and Matching Results State
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [progressPercent, setProgressPercent] = useState<number>(0);
  const [results, setResults] = useState<MatchResult[]>([]);
  const [selectedMatchIndex, setSelectedMatchIndex] = useState<number | null>(null);
  const [trendBreakdown, setTrendBreakdown] = useState<TrendBreakdown | null>(null);

  // Cancellation token ref
  const shouldStopRef = useRef<boolean>(false);

  // Modals state
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAIVisionOpen, setIsAIVisionOpen] = useState(false);
  const [isMyDNAOpen, setIsMyDNAOpen] = useState(false);
  const [candleModalResult, setCandleModalResult] = useState<MatchResult | null>(null);

  // Calculate total candles across active datasets
  const activeDatasets = datasets.filter((d) => selectedDatasetIds.includes(d.id));
  const totalCandlesCount = activeDatasets.reduce((acc, d) => acc + d.candles.length, 0);

  // Handler: Start Analysis
  const handleStartAnalysis = async () => {
    if (!referencePattern || activeDatasets.length === 0) return;

    setIsAnalyzing(true);
    setProgressPercent(0);
    shouldStopRef.current = false;
    setSelectedMatchIndex(null);

    try {
      const foundMatches = await PatternMatcher.analyzeMultiDatasets(
        referencePattern,
        activeDatasets,
        config,
        (pct) => setProgressPercent(pct),
        () => shouldStopRef.current
      );

      setResults(foundMatches);
      setTrendBreakdown(PatternMatcher.computeTrendBreakdown(foundMatches));
      if (foundMatches.length > 0) {
        setSelectedMatchIndex(0);
      }
    } catch (err) {
      console.error("Analysis Error:", err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Handler: Stop Analysis
  const handleStopAnalysis = () => {
    shouldStopRef.current = true;
    setIsAnalyzing(false);
  };

  // Handler: Clear All
  const handleClearAll = () => {
    setImageSrc(null);
    setReferencePattern(null);
    setReferencePatternName("");
    setResults([]);
    setSelectedMatchIndex(null);
    setTrendBreakdown(null);
    setProgressPercent(0);
  };

  // Handler: Export CSV
  const handleExportCSV = () => {
    if (results.length === 0) return;

    const headers = [
      "Rank",
      "Similarity_Percent",
      "Symbol",
      "Timeframe",
      "StartTime",
      "EndTime",
      "Trend",
      "File",
    ];

    const rows = results.map((r) => [
      r.rank,
      r.similarity.toFixed(2),
      r.symbol,
      r.timeframe,
      `"${r.startTime}"`,
      `"${r.endTime}"`,
      r.trend,
      `"${r.fileName}"`,
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map((e) => e.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `chartdna_matches_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const selectedMatch =
    selectedMatchIndex !== null && results[selectedMatchIndex]
      ? results[selectedMatchIndex]
      : results[0] || null;

  return (
    <div
      id="chart-dna-app"
      className={`min-h-screen bg-[#070b12] text-slate-100 flex flex-col font-sans ${
        isPersian ? "rtl font-['Vazirmatn',sans-serif]" : "ltr"
      }`}
    >
      {/* App Header */}
      <Header
        activeSymbol={activeDatasets[0]?.symbol || "EURUSD"}
        selectedDatasetsCount={activeDatasets.length}
        totalCandlesCount={totalCandlesCount}
        onOpenSettings={() => setIsSettingsOpen(true)}
        isPersian={isPersian}
        onToggleLanguage={() => setIsPersian(!isPersian)}
      />

      {/* Main Workspace Layout */}
      <main className="w-full max-w-[1920px] mx-auto px-3 sm:px-5 lg:px-8 py-3.5 flex-1 flex flex-col lg:flex-row gap-4 items-stretch">
        {/* Left Sidebar: Compact width for sleek high-density cockpit */}
        <div className="w-full lg:w-56 xl:w-60 shrink-0 flex flex-col">
          <SidebarControls
            onSelectImageClick={() => {
              const input = document.createElement("input");
              input.type = "file";
              input.accept = "image/*";
              input.onchange = (e: any) => {
                const file = e.target.files?.[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onload = (ev) => {
                  setImageSrc(ev.target?.result as string);
                };
                reader.readAsDataURL(file);
              };
              input.click();
            }}
            onClearAll={handleClearAll}
            onExtractPattern={() => {
              // Triggered automatically on crop, or explicit focus
            }}
            onStartAnalysis={handleStartAnalysis}
            onStopAnalysis={handleStopAnalysis}
            isAnalyzing={isAnalyzing}
            progressPercent={progressPercent}
            hasImage={!!imageSrc}
            hasPattern={!!referencePattern && referencePattern.length > 5}
            hasDatasets={activeDatasets.length > 0}
            trendBreakdown={trendBreakdown}
            rangeLookback={config.rangeLookback}
            isPersian={isPersian}
          />
        </div>

        {/* Right Main Column: Contains Top 2 Visualizer Cards & Results Table Below Them */}
        <div className="flex-1 flex flex-col gap-4 min-w-0">
          {/* Top Row: Two Visualizer Cards */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            {/* Chart Image & Cropper */}
            <ImageCropperCanvas
              imageSrc={imageSrc}
              onImageLoaded={() => {}}
              onPatternExtracted={(pat) => {
                setReferencePattern(pat);
                setReferencePatternName("Extracted from Crop");
              }}
              isPersian={isPersian}
            />

            {/* Comparative Overlay Chart */}
            <ComparativeChart
              referencePattern={referencePattern}
              selectedMatch={selectedMatch}
              onOpenCandleChart={(match) => setCandleModalResult(match)}
              isPersian={isPersian}
            />
          </div>

          {/* Bottom Area: Pattern Similarity Match Results Table (under the two blocks) */}
          <ResultsTable
            results={results}
            selectedIndex={selectedMatchIndex}
            onSelectResult={(idx) => setSelectedMatchIndex(idx)}
            onOpenCandleChart={(match) => setCandleModalResult(match)}
            isPersian={isPersian}
          />
        </div>
      </main>

      {/* Settings & Data Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        config={config}
        onUpdateConfig={(newConf) => setConfig(newConf)}
        datasets={datasets}
        onUpdateDatasets={(newDatasets) => setDatasets(newDatasets)}
        selectedDatasetIds={selectedDatasetIds}
        onToggleDatasetId={(id) => {
          setSelectedDatasetIds((prev) =>
            prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
          );
        }}
        onSelectAllDatasets={(selectAll) => {
          setSelectedDatasetIds(selectAll ? datasets.map((d) => d.id) : []);
        }}
        isPersian={isPersian}
      />

      {/* AI Vision Analysis Modal */}
      <AIVisionModal
        isOpen={isAIVisionOpen}
        onClose={() => setIsAIVisionOpen(false)}
        currentImageBase64={imageSrc}
        referencePattern={referencePattern}
        selectedMatch={selectedMatch}
        isPersian={isPersian}
      />

      {/* My DNA Library Modal */}
      <MyDNAModal
        isOpen={isMyDNAOpen}
        onClose={() => setIsMyDNAOpen(false)}
        savedPatterns={savedPatterns}
        onApplyPattern={(pat, name) => {
          setReferencePattern(pat);
          setReferencePatternName(name);
        }}
        onDeletePattern={(id) => {
          setSavedPatterns((prev) => prev.filter((p) => p.id !== id));
        }}
        onImportLibrary={(imported) => {
          setSavedPatterns(imported);
        }}
        isPersian={isPersian}
      />

      {/* Candlestick Modal */}
      <CandleChartModal
        isOpen={!!candleModalResult}
        onClose={() => setCandleModalResult(null)}
        result={candleModalResult}
        datasets={datasets}
        isPersian={isPersian}
      />
    </div>
  );
};
export default App;
