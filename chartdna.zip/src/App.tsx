import React, { useState, useEffect, useRef } from "react";
import { Header } from "./components/Header";
import { SidebarControls } from "./components/SidebarControls";
import { ImageCropperCanvas } from "./components/ImageCropperCanvas";
import { ComparativeChart } from "./components/ComparativeChart";
import { ResultsTable } from "./components/ResultsTable";
import { SettingsModal } from "./components/SettingsModal";
import { CandleChartModal } from "./components/CandleChartModal";
import { AIVisionModal } from "./components/AIVisionModal";
import { MyDNAModal } from "./components/MyDNAModal";

import {
  MarketDataset,
  MatchResult,
  SearchConfig,
  MyDNAPattern,
  TrendBreakdown,
} from "./engine/types";
import { PRESET_PATTERNS } from "./engine/presetPatterns";
import { PatternMatcher } from "./engine/matcher";
import { LanguageCode, getTranslation } from "./i18n/languages";
import { ThemeId, getTheme, applyThemeVariables } from "./theme/themes";

const DEFAULT_CONFIG: SearchConfig = {
  threshold: 75,
  patternLength: 60,
  futureCandles: 20,
  topResults: 50,
  rangeLookback: 5,
  skipOverlap: true,
  weights: {
    pearson: 0.4,
    dtw: 0.3,
    slope: 0.15,
    structural: 0.15,
  },
};

export const App: React.FC = () => {
  // 1. Language State & Persistence (Default to Persian 'fa' as user's native language)
  const [activeLanguage, setActiveLanguage] = useState<LanguageCode>(() => {
    const saved = localStorage.getItem("chartdna_language");
    if (saved && ["en", "fa", "ar", "es", "fr", "de", "ru", "zh", "tr", "ja"].includes(saved)) {
      return saved as LanguageCode;
    }
    return "fa";
  });

  // 2. Theme State & Persistence (10 distinct themes)
  const [activeTheme, setActiveTheme] = useState<ThemeId>(() => {
    const saved = localStorage.getItem("chartdna_theme");
    if (saved) {
      return saved as ThemeId;
    }
    return "cyber-obsidian";
  });

  // Save Language to LocalStorage
  useEffect(() => {
    localStorage.setItem("chartdna_language", activeLanguage);
    const dir = activeLanguage === "fa" || activeLanguage === "ar" ? "rtl" : "ltr";
    document.documentElement.dir = dir;
    document.documentElement.lang = activeLanguage;
  }, [activeLanguage]);

  // Save Theme to LocalStorage & HTML data attribute & CSS variables
  useEffect(() => {
    localStorage.setItem("chartdna_theme", activeTheme);
    document.documentElement.setAttribute("data-theme", activeTheme);
    const currentDef = getTheme(activeTheme);
    applyThemeVariables(currentDef);
  }, [activeTheme]);

  // Datasets (Loaded from LocalStorage or empty by default)
  const [datasets, setDatasets] = useState<MarketDataset[]>(() => {
    const fromStorage = localStorage.getItem("chartdna_datasets");
    if (fromStorage) {
      try {
        return JSON.parse(fromStorage);
      } catch (e) {
        console.error(e);
      }
    }
    return [];
  });

  const [selectedDatasetIds, setSelectedDatasetIds] = useState<string[]>(() => {
    const fromStorage = localStorage.getItem("chartdna_selected_dataset_ids");
    if (fromStorage) {
      try {
        return JSON.parse(fromStorage);
      } catch (e) {
        console.error(e);
      }
    }
    return [];
  });

  // Save Datasets & Selected IDs to LocalStorage
  useEffect(() => {
    localStorage.setItem("chartdna_datasets", JSON.stringify(datasets));
  }, [datasets]);

  useEffect(() => {
    localStorage.setItem("chartdna_selected_dataset_ids", JSON.stringify(selectedDatasetIds));
  }, [selectedDatasetIds]);

  // Engine Configuration (Persistent)
  const [config, setConfig] = useState<SearchConfig>(() => {
    const fromStorage = localStorage.getItem("chartdna_config");
    if (fromStorage) {
      try {
        return JSON.parse(fromStorage);
      } catch (e) {
        console.error(e);
      }
    }
    return DEFAULT_CONFIG;
  });

  useEffect(() => {
    localStorage.setItem("chartdna_config", JSON.stringify(config));
  }, [config]);

  // Active Reference Pattern (80 normalized values)
  const [referencePattern, setReferencePattern] = useState<number[] | null>(null);
  const [referencePatternName, setReferencePatternName] = useState<string>("");

  // Chart Image Source
  const [imageSrc, setImageSrc] = useState<string | null>(null);

  // Saved My DNA Patterns Library (Persistent)
  const [savedPatterns, setSavedPatterns] = useState<MyDNAPattern[]>(() => {
    const fromStorage = localStorage.getItem("chartdna_saved_patterns");
    if (fromStorage) {
      try {
        return JSON.parse(fromStorage);
      } catch (e) {
        console.error(e);
      }
    }
    // Initial library from presets
    return PRESET_PATTERNS.map((p) => ({
      id: p.id,
      name: p.name,
      category: p.category,
      createdAt: "2024-01-01",
      points: p.points,
      normalizedPoints: p.points,
      notes: p.description,
    }));
  });

  // Save Patterns to LocalStorage
  useEffect(() => {
    localStorage.setItem("chartdna_saved_patterns", JSON.stringify(savedPatterns));
  }, [savedPatterns]);

  // Search and Matching Results State
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [progressPercent, setProgressPercent] = useState<number>(0);
  const [results, setResults] = useState<MatchResult[]>([]);
  const [selectedMatchIndex, setSelectedMatchIndex] = useState<number | null>(null);
  const [trendBreakdown, setTrendBreakdown] = useState<TrendBreakdown | null>(null);

  // Cancellation token ref
  const shouldStopRef = useRef<boolean>(false);

  // Modals state
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAIVisionOpen, setIsAIVisionOpen] = useState(false);
  const [isMyDNAOpen, setIsMyDNAOpen] = useState(false);
  const [candleModalResult, setCandleModalResult] = useState<MatchResult | null>(null);

  // Calculate total candles across active datasets
  const activeDatasets = datasets.filter((d) => selectedDatasetIds.includes(d.id));
  const totalCandlesCount = activeDatasets.reduce((acc, d) => acc + d.candles.length, 0);

  const currentTheme = getTheme(activeTheme);
  const isRtl = activeLanguage === "fa" || activeLanguage === "ar";

  // Handler: Start Analysis
  const handleStartAnalysis = async () => {
    if (!referencePattern || activeDatasets.length === 0) return;

    setIsAnalyzing(true);
    setProgressPercent(0);
    shouldStopRef.current = false;
    setSelectedMatchIndex(null);

    try {
      const foundMatches = await PatternMatcher.analyzeMultiDatasets(
        referencePattern,
        activeDatasets,
        config,
        (pct) => setProgressPercent(pct),
        () => shouldStopRef.current
      );

      setResults(foundMatches);
      setTrendBreakdown(PatternMatcher.computeTrendBreakdown(foundMatches));
      if (foundMatches.length > 0) {
        setSelectedMatchIndex(0);
      }
    } catch (err) {
      console.error("Analysis Error:", err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Handler: Stop Analysis
  const handleStopAnalysis = () => {
    shouldStopRef.current = true;
    setIsAnalyzing(false);
  };

  // Handler: Clear All
  const handleClearAll = () => {
    setImageSrc(null);
    setReferencePattern(null);
    setReferencePatternName("");
    setResults([]);
    setSelectedMatchIndex(null);
    setTrendBreakdown(null);
    setProgressPercent(0);
  };

  const selectedMatch =
    selectedMatchIndex !== null && results[selectedMatchIndex]
      ? results[selectedMatchIndex]
      : results[0] || null;

  return (
    <div
      id="chart-dna-app"
      data-theme={activeTheme}
      dir={isRtl ? "rtl" : "ltr"}
      className={`min-h-screen text-slate-100 flex flex-col font-sans transition-colors duration-300 ${
        isRtl ? "rtl font-['Vazirmatn',sans-serif]" : "ltr"
      }`}
      style={{
        backgroundColor: "var(--theme-bg, #060913)",
        color: "var(--theme-text, #f8fafc)",
      }}
    >
      {/* App Header */}
      <Header
        activeSymbol={activeDatasets[0]?.symbol || "EURUSD"}
        selectedDatasetsCount={activeDatasets.length}
        totalCandlesCount={totalCandlesCount}
        onOpenSettings={() => setIsSettingsOpen(true)}
        activeLanguage={activeLanguage}
        onSelectLanguage={(lang) => setActiveLanguage(lang)}
        activeTheme={activeTheme}
        onSelectTheme={(themeId) => setActiveTheme(themeId)}
      />

      {/* Main Workspace Layout */}
      <main className="w-full max-w-[1920px] mx-auto px-2.5 sm:px-4 lg:px-6 py-3 flex-1 flex flex-col lg:flex-row gap-3.5 items-stretch">
        {/* Left Sidebar: Compact, elegant width for sleek cockpit */}
        <div className="w-full lg:w-48 xl:w-52 shrink-0 flex flex-col">
          <SidebarControls
            onSelectImageClick={() => {
              const input = document.createElement("input");
              input.type = "file";
              input.accept = "image/*";
              input.onchange = (e: any) => {
                const file = e.target.files?.[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onload = (ev) => {
                  setImageSrc(ev.target?.result as string);
                };
                reader.readAsDataURL(file);
              };
              input.click();
            }}
            onClearAll={handleClearAll}
            onExtractPattern={() => {
              // Triggered automatically on crop or explicit focus
            }}
            onStartAnalysis={handleStartAnalysis}
            onStopAnalysis={handleStopAnalysis}
            isAnalyzing={isAnalyzing}
            progressPercent={progressPercent}
            hasImage={!!imageSrc}
            hasPattern={!!referencePattern && referencePattern.length > 5}
            hasDatasets={activeDatasets.length > 0}
            trendBreakdown={trendBreakdown}
            rangeLookback={config.rangeLookback}
            activeLanguage={activeLanguage}
            activeTheme={activeTheme}
          />
        </div>

        {/* Right Main Column: Contains Top 2 Visualizer Cards & Results Table Below Them */}
        <div className="flex-1 flex flex-col gap-3.5 min-w-0">
          {/* Top Row: Two Visualizer Cards */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-3.5">
            {/* Chart Image & Cropper */}
            <ImageCropperCanvas
              imageSrc={imageSrc}
              onImageLoaded={() => {}}
              onPatternExtracted={(pat) => {
                setReferencePattern(pat);
                setReferencePatternName("Extracted from Crop");
              }}
              activeLanguage={activeLanguage}
              activeTheme={activeTheme}
            />

            {/* Comparative Overlay Chart */}
            <ComparativeChart
              referencePattern={referencePattern}
              selectedMatch={selectedMatch}
              onOpenCandleChart={(match) => setCandleModalResult(match)}
              activeLanguage={activeLanguage}
              activeTheme={activeTheme}
            />
          </div>

          {/* Bottom Area: Pattern Similarity Match Results Table */}
          <ResultsTable
            results={results}
            selectedIndex={selectedMatchIndex}
            onSelectResult={(idx) => setSelectedMatchIndex(idx)}
            onOpenCandleChart={(match) => setCandleModalResult(match)}
            activeLanguage={activeLanguage}
            activeTheme={activeTheme}
          />
        </div>
      </main>

      {/* Settings & Data Modal (Themes, Languages, Algorithm, Weights, Data) */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        config={config}
        onUpdateConfig={(newConf) => setConfig(newConf)}
        datasets={datasets}
        onUpdateDatasets={(newDatasets) => setDatasets(newDatasets)}
        selectedDatasetIds={selectedDatasetIds}
        onToggleDatasetId={(id) => {
          setSelectedDatasetIds((prev) =>
            prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
          );
        }}
        onSelectAllDatasets={(selectAll) => {
          setSelectedDatasetIds(selectAll ? datasets.map((d) => d.id) : []);
        }}
        activeTheme={activeTheme}
        onSelectTheme={(th) => setActiveTheme(th)}
        activeLanguage={activeLanguage}
        onSelectLanguage={(lang) => setActiveLanguage(lang)}
      />

      {/* AI Vision Analysis Modal */}
      <AIVisionModal
        isOpen={isAIVisionOpen}
        onClose={() => setIsAIVisionOpen(false)}
        currentImageBase64={imageSrc}
        referencePattern={referencePattern}
        selectedMatch={selectedMatch}
        activeLanguage={activeLanguage}
        activeTheme={activeTheme}
      />

      {/* My DNA Library Modal */}
      <MyDNAModal
        isOpen={isMyDNAOpen}
        onClose={() => setIsMyDNAOpen(false)}
        savedPatterns={savedPatterns}
        onApplyPattern={(pat, name) => {
          setReferencePattern(pat);
          setReferencePatternName(name);
        }}
        onDeletePattern={(id) => {
          setSavedPatterns((prev) => prev.filter((p) => p.id !== id));
        }}
        onImportLibrary={(imported) => {
          setSavedPatterns(imported);
        }}
        activeLanguage={activeLanguage}
        activeTheme={activeTheme}
      />

      {/* Candlestick Modal */}
      <CandleChartModal
        isOpen={!!candleModalResult}
        onClose={() => setCandleModalResult(null)}
        result={candleModalResult}
        datasets={datasets}
        activeLanguage={activeLanguage}
        activeTheme={activeTheme}
      />
    </div>
  );
};

export default App;

