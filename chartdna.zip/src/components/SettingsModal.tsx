import React, { useState } from "react";
import {
  X,
  Sliders,
  Database,
  Upload,
  Check,
  RotateCcw,
  Sparkles,
  Layers,
  FileSpreadsheet,
  FolderOpen,
} from "lucide-react";
import { SearchConfig, MarketDataset, SimilarityWeights } from "../engine/types";
import { MarketDataManager } from "./MarketDataManager";

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: SearchConfig;
  onUpdateConfig: (newConfig: SearchConfig) => void;
  datasets: MarketDataset[];
  onUpdateDatasets: (newDatasets: MarketDataset[]) => void;
  selectedDatasetIds: string[];
  onToggleDatasetId: (id: string) => void;
  onSelectAllDatasets: (select: boolean) => void;
  isPersian: boolean;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  config,
  onUpdateConfig,
  datasets,
  onUpdateDatasets,
  selectedDatasetIds,
  onToggleDatasetId,
  onSelectAllDatasets,
  isPersian,
}) => {
  const [activeTab, setActiveTab] = useState<"algorithm" | "weights" | "data">("algorithm");
  const [tempConfig, setTempConfig] = useState<SearchConfig>({ ...config });

  if (!isOpen) return null;

  const handleSave = () => {
    onUpdateConfig(tempConfig);
    onClose();
  };

  const handleResetDefaults = () => {
    setTempConfig({
      threshold: 80,
      patternLength: 60,
      futureCandles: 20,
      topResults: 50,
      rangeLookback: 5,
      skipOverlap: true,
      weights: {
        pearson: 0.4,
        dtw: 0.3,
        slope: 0.15,
        structural: 0.15,
      },
    });
  };

  return (
    <div
      id="settings-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-black/80 backdrop-blur-sm"
    >
      <div className="bg-[#0d1322] border border-slate-700/80 rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-slate-900/90 border-b border-slate-800 px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-cyan-400" />
            <h2 className="text-sm font-bold text-white">
              {isPersian ? "تنظیمات موتور و مدیریت داده‌های بازار" : "Engine Parameters & Market Data Settings"}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-slate-800 bg-slate-950/60 px-4">
          <button
            onClick={() => setActiveTab("algorithm")}
            className={`py-3 px-4 text-xs font-semibold border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === "algorithm"
                ? "border-cyan-400 text-cyan-300"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>{isPersian ? "پارامترهای جستجو" : "Search Parameters"}</span>
          </button>

          <button
            onClick={() => setActiveTab("weights")}
            className={`py-3 px-4 text-xs font-semibold border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === "weights"
                ? "border-cyan-400 text-cyan-300"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isPersian ? "وزن‌دهی فرمول شباهت" : "Similarity Weights"}</span>
          </button>

          <button
            onClick={() => setActiveTab("data")}
            className={`py-3 px-4 text-xs font-semibold border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === "data"
                ? "border-cyan-400 text-cyan-300"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <FolderOpen className="w-3.5 h-3.5 text-emerald-400" />
            <span>{isPersian ? "مدیریت داده‌ها و انتخاب فولدر" : "Market Data & Folder Manager"}</span>
          </button>
        </div>

        {/* Tab Contents */}
        <div className="p-5 md:p-6 overflow-y-auto flex-1 flex flex-col gap-6 text-xs text-slate-300">
          {/* Tab 1: Algorithm Parameters */}
          {activeTab === "algorithm" && (
            <div className="flex flex-col gap-4">
              {/* Threshold */}
              <div>
                <div className="flex justify-between mb-1.5 font-semibold text-slate-200">
                  <span>{isPersian ? "آستانه حداقل شباهت (Threshold %):" : "Similarity Threshold (%):"}</span>
                  <span className="font-mono text-cyan-400">{tempConfig.threshold}%</span>
                </div>
                <input
                  type="range"
                  min="60"
                  max="98"
                  value={tempConfig.threshold}
                  onChange={(e) =>
                    setTempConfig({ ...tempConfig, threshold: parseInt(e.target.value) })
                  }
                  className="w-full accent-cyan-400 cursor-pointer"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  {isPersian
                    ? "الگوهایی با شباهت ریاضی بالاتر از این درصد در نتایج نمایش داده می‌شوند."
                    : "Only matches with mathematical score higher than this value are included in results."}
                </p>
              </div>

              {/* Future Candles */}
              <div>
                <div className="flex justify-between mb-1.5 font-semibold text-slate-200">
                  <span>{isPersian ? "تعداد کندل‌های آینده (Future Window):" : "Future Projection Candles:"}</span>
                  <span className="font-mono text-cyan-400">{tempConfig.futureCandles}</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="100"
                  value={tempConfig.futureCandles}
                  onChange={(e) =>
                    setTempConfig({ ...tempConfig, futureCandles: parseInt(e.target.value) })
                  }
                  className="w-full accent-cyan-400 cursor-pointer"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  {isPersian
                    ? "تعداد کندل‌های بعد از الگو که جهت پیش‌بینی و ترسیم خط سبز آینده استخراج می‌شوند."
                    : "Number of candles after the pattern to trace forward path and classify trend."}
                </p>
              </div>

              {/* Pattern Length */}
              <div>
                <div className="flex justify-between mb-1.5 font-semibold text-slate-200">
                  <span>{isPersian ? "طول پنجره اسکن الگو (Pattern Length):" : "Scan Window Pattern Length:"}</span>
                  <span className="font-mono text-cyan-400">{tempConfig.patternLength}</span>
                </div>
                <input
                  type="range"
                  min="15"
                  max="150"
                  value={tempConfig.patternLength}
                  onChange={(e) =>
                    setTempConfig({ ...tempConfig, patternLength: parseInt(e.target.value) })
                  }
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              {/* Range Lookback */}
              <div>
                <div className="flex justify-between mb-1.5 font-semibold text-slate-200">
                  <span>{isPersian ? "بازه محاسبه رنج (Range Lookback):" : "Range Lookback Candles:"}</span>
                  <span className="font-mono text-cyan-400">{tempConfig.rangeLookback}</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="20"
                  value={tempConfig.rangeLookback}
                  onChange={(e) =>
                    setTempConfig({ ...tempConfig, rangeLookback: parseInt(e.target.value) })
                  }
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              {/* Skip Overlap Checkbox */}
              <div className="flex items-center gap-3 bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                <input
                  type="checkbox"
                  id="chk-overlap"
                  checked={tempConfig.skipOverlap}
                  onChange={(e) =>
                    setTempConfig({ ...tempConfig, skipOverlap: e.target.checked })
                  }
                  className="w-4 h-4 accent-emerald-400 rounded cursor-pointer"
                />
                <label htmlFor="chk-overlap" className="cursor-pointer text-slate-200 font-medium">
                  {isPersian
                    ? "فیلتر هم‌پوشانی الگوهای تکراری مجاور (Skip Overlap)"
                    : "Suppress Overlapping Adjacent Windows (Recommended)"}
                </label>
              </div>
            </div>
          )}

          {/* Tab 2: Similarity Weights */}
          {activeTab === "weights" && (
            <div className="flex flex-col gap-4">
              <p className="text-slate-400 text-xs leading-relaxed">
                {isPersian
                  ? "ترکیب ضرایب محاسباتی موتور برای تشخیص فرم هندسی، انحنا، همبستگی آماری و ساختار نقاط عطف:"
                  : "Calibrate the mathematical weights for Pearson Correlation, DTW time warping, gradient slope, and structural turning points:"}
              </p>

              {/* Pearson */}
              <div>
                <div className="flex justify-between mb-1 font-semibold text-slate-200">
                  <span>Pearson Correlation (همبستگی پیرسون)</span>
                  <span className="font-mono text-cyan-400">
                    {Math.round(tempConfig.weights.pearson * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={tempConfig.weights.pearson}
                  onChange={(e) =>
                    setTempConfig({
                      ...tempConfig,
                      weights: { ...tempConfig.weights, pearson: parseFloat(e.target.value) },
                    })
                  }
                  className="w-full accent-cyan-400"
                />
              </div>

              {/* DTW */}
              <div>
                <div className="flex justify-between mb-1 font-semibold text-slate-200">
                  <span>Dynamic Time Warping (DTW انطباق زمانی)</span>
                  <span className="font-mono text-cyan-400">
                    {Math.round(tempConfig.weights.dtw * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={tempConfig.weights.dtw}
                  onChange={(e) =>
                    setTempConfig({
                      ...tempConfig,
                      weights: { ...tempConfig.weights, dtw: parseFloat(e.target.value) },
                    })
                  }
                  className="w-full accent-cyan-400"
                />
              </div>

              {/* Slope */}
              <div>
                <div className="flex justify-between mb-1 font-semibold text-slate-200">
                  <span>Slope / Tangent Alignment (شیب و زاویه)</span>
                  <span className="font-mono text-cyan-400">
                    {Math.round(tempConfig.weights.slope * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={tempConfig.weights.slope}
                  onChange={(e) =>
                    setTempConfig({
                      ...tempConfig,
                      weights: { ...tempConfig.weights, slope: parseFloat(e.target.value) },
                    })
                  }
                  className="w-full accent-cyan-400"
                />
              </div>

              {/* Structural */}
              <div>
                <div className="flex justify-between mb-1 font-semibold text-slate-200">
                  <span>Structural Peaks & Valleys (ساختار قله‌ها و کف‌ها)</span>
                  <span className="font-mono text-cyan-400">
                    {Math.round(tempConfig.weights.structural * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={tempConfig.weights.structural}
                  onChange={(e) =>
                    setTempConfig({
                      ...tempConfig,
                      weights: { ...tempConfig.weights, structural: parseFloat(e.target.value) },
                    })
                  }
                  className="w-full accent-cyan-400"
                />
              </div>
            </div>
          )}

          {/* Tab 3: Data Manager & CSV Folder Selection */}
          {activeTab === "data" && (
            <MarketDataManager
              datasets={datasets}
              onUpdateDatasets={onUpdateDatasets}
              selectedDatasetIds={selectedDatasetIds}
              onToggleDatasetId={onToggleDatasetId}
              onSelectAllDatasets={onSelectAllDatasets}
              isPersian={isPersian}
            />
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-900/90 border-t border-slate-800 px-6 py-3 flex items-center justify-between">
          <button
            onClick={handleResetDefaults}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 px-3 py-1.5 bg-slate-800 rounded-xl border border-slate-700"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{isPersian ? "بازنشانی پیش‌فرض" : "Reset Defaults"}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-slate-200"
            >
              {isPersian ? "انصراف" : "Cancel"}
            </button>
            <button
              onClick={handleSave}
              className="flex items-center gap-1.5 px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-emerald-600/20"
            >
              <Check className="w-4 h-4" />
              <span>{isPersian ? "ذخیره تغییرات" : "Save Changes"}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
