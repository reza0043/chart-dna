import React, { useState } from "react";
import {
  X,
  Sliders,
  Check,
  RotateCcw,
  Sparkles,
  FolderOpen,
  Palette,
  Globe,
  CheckCircle2,
} from "lucide-react";
import { SearchConfig, MarketDataset } from "../engine/types";
import { MarketDataManager } from "./MarketDataManager";
import { THEMES, ThemeId } from "../theme/themes";
import { SUPPORTED_LANGUAGES, LanguageCode, getTranslation } from "../i18n/languages";

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: SearchConfig;
  onUpdateConfig: (newConfig: SearchConfig) => void;
  datasets: MarketDataset[];
  onUpdateDatasets: (newDatasets: MarketDataset[]) => void;
  selectedDatasetIds: string[];
  onToggleDatasetId: (id: string) => void;
  onSelectAllDatasets: (select: boolean) => void;
  activeTheme: ThemeId;
  onSelectTheme: (themeId: ThemeId) => void;
  activeLanguage: LanguageCode;
  onSelectLanguage: (lang: LanguageCode) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  config,
  onUpdateConfig,
  datasets,
  onUpdateDatasets,
  selectedDatasetIds,
  onToggleDatasetId,
  onSelectAllDatasets,
  activeTheme,
  onSelectTheme,
  activeLanguage,
  onSelectLanguage,
}) => {
  const [activeTab, setActiveTab] = useState<"themes" | "languages" | "algorithm" | "weights" | "data">("themes");
  const [tempConfig, setTempConfig] = useState<SearchConfig>({ ...config });

  if (!isOpen) return null;

  const t = (key: string, fallback?: string) => getTranslation(activeLanguage, key, fallback);
  const isRtl = activeLanguage === "fa" || activeLanguage === "ar";

  const handleSave = () => {
    onUpdateConfig(tempConfig);
    onClose();
  };

  const handleResetDefaults = () => {
    setTempConfig({
      threshold: 75,
      patternLength: 60,
      futureCandles: 20,
      topResults: 50,
      rangeLookback: 5,
      skipOverlap: true,
      weights: {
        pearson: 0.4,
        dtw: 0.3,
        slope: 0.15,
        structural: 0.15,
      },
    });
  };

  return (
    <div
      id="settings-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 md:p-6 bg-black/80 backdrop-blur-md"
      dir={isRtl ? "rtl" : "ltr"}
    >
      <div className="bg-[#0b101c]/95 border border-slate-700/80 rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden backdrop-blur-xl">
        {/* Header */}
        <div className="bg-slate-900/90 border-b border-slate-800/80 px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-cyan-500/15 border border-cyan-400/30 text-cyan-300">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">
                {t("settingsTitle", "تنظیمات جامع سیستم")}
              </h2>
              <p className="text-[10px] text-slate-400">
                {t("persistedNotice", "تنظیمات به طور خودکار ذخیره و پایدار می‌مانند")}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] text-slate-400 hover:text-white transition-all cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex flex-wrap border-b border-slate-800/80 bg-slate-950/60 px-3 overflow-x-auto gap-1">
          {/* Tab 1: Themes */}
          <button
            onClick={() => setActiveTab("themes")}
            className={`py-2.5 px-3 text-xs font-semibold border-b-2 transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === "themes"
                ? "border-cyan-400 text-cyan-300 bg-cyan-500/10 rounded-t-lg"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <Palette className="w-3.5 h-3.5 text-cyan-400" />
            <span>{t("tabThemes", "تم‌های رنگی (۱۰ تم)")}</span>
          </button>

          {/* Tab 2: Language */}
          <button
            onClick={() => setActiveTab("languages")}
            className={`py-2.5 px-3 text-xs font-semibold border-b-2 transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === "languages"
                ? "border-cyan-400 text-cyan-300 bg-cyan-500/10 rounded-t-lg"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <Globe className="w-3.5 h-3.5 text-emerald-400" />
            <span>{t("tabLanguages", "انتخاب زبان (۱۰ زبان)")}</span>
          </button>

          {/* Tab 3: Search Parameters */}
          <button
            onClick={() => setActiveTab("algorithm")}
            className={`py-2.5 px-3 text-xs font-semibold border-b-2 transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === "algorithm"
                ? "border-cyan-400 text-cyan-300 bg-cyan-500/10 rounded-t-lg"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <Sliders className="w-3.5 h-3.5 text-amber-400" />
            <span>{t("tabSearch", "پارامترهای جستجو")}</span>
          </button>

          {/* Tab 4: Similarity Weights */}
          <button
            onClick={() => setActiveTab("weights")}
            className={`py-2.5 px-3 text-xs font-semibold border-b-2 transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === "weights"
                ? "border-cyan-400 text-cyan-300 bg-cyan-500/10 rounded-t-lg"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>{t("tabWeights", "وزن‌دهی فرمول")}</span>
          </button>

          {/* Tab 5: Market Data Manager */}
          <button
            onClick={() => setActiveTab("data")}
            className={`py-2.5 px-3 text-xs font-semibold border-b-2 transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === "data"
                ? "border-cyan-400 text-cyan-300 bg-cyan-500/10 rounded-t-lg"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <FolderOpen className="w-3.5 h-3.5 text-emerald-400" />
            <span>{t("tabData", "مدیریت داده‌ها")}</span>
          </button>
        </div>

        {/* Tab Contents */}
        <div className="p-4 sm:p-5 md:p-6 overflow-y-auto flex-1 flex flex-col gap-5 text-xs text-slate-300">
          {/* TAB 1: 10 Color Themes */}
          {activeTab === "themes" && (
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Palette className="w-4 h-4 text-cyan-400" />
                    <span>{t("tabThemes", "تم‌های رنگی رابط کاربری")}</span>
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    {t("selectThemeDesc", "یکی از ۱۰ تم زیر را برای تغییر کل پالت رنگی برنامه انتخاب کنید:")}
                  </p>
                </div>
              </div>

              {/* 10 Theme Cards Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-3">
                {THEMES.map((theme) => {
                  const isSelected = activeTheme === theme.id;
                  const themeName =
                    theme.name[activeLanguage] || theme.name.en || theme.id;
                  const themeDesc =
                    theme.description[activeLanguage] || theme.description.en;

                  return (
                    <div
                      key={theme.id}
                      onClick={() => onSelectTheme(theme.id)}
                      className={`relative p-3.5 rounded-xl border transition-all duration-200 cursor-pointer flex flex-col justify-between gap-3 ${
                        isSelected
                          ? "bg-white/[0.08] border-cyan-400 shadow-lg shadow-cyan-950/40 ring-1 ring-cyan-400/50"
                          : "bg-slate-900/60 hover:bg-slate-900/90 border-slate-800 hover:border-slate-700"
                      }`}
                      style={{
                        backgroundColor: isSelected ? undefined : `${theme.colors.cardBg}cc`,
                        borderColor: isSelected ? theme.colors.primary : undefined,
                      }}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          {/* Color preview palette dots */}
                          <div className="flex items-center -space-x-1.5 rtl:space-x-reverse">
                            <span
                              className="w-4 h-4 rounded-full border border-black/40 shadow-sm"
                              style={{ backgroundColor: theme.colors.primary }}
                            />
                            <span
                              className="w-4 h-4 rounded-full border border-black/40 shadow-sm"
                              style={{ backgroundColor: theme.colors.secondary }}
                            />
                            <span
                              className="w-4 h-4 rounded-full border border-black/40 shadow-sm"
                              style={{ backgroundColor: theme.colors.bg }}
                            />
                          </div>
                          <div>
                            <h4 className="font-bold text-xs text-white">
                              {themeName}
                            </h4>
                            {theme.isLight && (
                              <span className="text-[9px] px-1.5 py-0.2 bg-blue-500/20 text-blue-300 rounded border border-blue-400/30">
                                Light Mode
                              </span>
                            )}
                          </div>
                        </div>

                        {isSelected && (
                          <span
                            className="flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-md border"
                            style={{
                              backgroundColor: `${theme.colors.primary}20`,
                              color: theme.colors.primary,
                              borderColor: `${theme.colors.primary}50`,
                            }}
                          >
                            <CheckCircle2 className="w-3 h-3" />
                            <span>{t("activeCandles", "فعال")}</span>
                          </span>
                        )}
                      </div>

                      <p className="text-[11px] text-slate-400 leading-relaxed">
                        {themeDesc}
                      </p>

                      {/* Visual Line preview */}
                      <div
                        className="w-full h-7 rounded-lg border p-1 flex items-center justify-between px-2.5 overflow-hidden"
                        style={{
                          backgroundColor: theme.colors.bg,
                          borderColor: theme.colors.border,
                        }}
                      >
                        <div className="flex items-center gap-2">
                          <span
                            className="w-5 h-1 rounded-full"
                            style={{ backgroundColor: theme.colors.dnaLine }}
                          />
                          <span
                            className="w-5 h-1 rounded-full"
                            style={{ backgroundColor: theme.colors.matchedLine }}
                          />
                          <span
                            className="w-5 h-1 rounded-full"
                            style={{ backgroundColor: theme.colors.futureLine }}
                          />
                        </div>
                        <span
                          className="text-[9px] font-mono"
                          style={{ color: theme.colors.textMuted }}
                        >
                          preview
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: 10 World Languages */}
          {activeTab === "languages" && (
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Globe className="w-4 h-4 text-emerald-400" />
                    <span>{t("tabLanguages", "انتخاب زبان برنامه")}</span>
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    {t("selectLangDesc", "زبان مورد نظر خود را از میان ۱۰ زبان زنده دنیا انتخاب کنید:")}
                  </p>
                </div>
              </div>

              {/* 10 Languages Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {SUPPORTED_LANGUAGES.map((lang) => {
                  const isSelected = activeLanguage === lang.code;

                  return (
                    <div
                      key={lang.code}
                      onClick={() => onSelectLanguage(lang.code)}
                      className={`p-3 rounded-xl border flex items-center justify-between transition-all duration-150 cursor-pointer ${
                        isSelected
                          ? "bg-emerald-500/15 border-emerald-400/80 shadow-md shadow-emerald-950/40"
                          : "bg-slate-900/60 hover:bg-slate-900/90 border-slate-800 hover:border-slate-700"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{lang.flag}</span>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-xs text-white">
                              {lang.name}
                            </span>
                            <span className="text-[10px] text-slate-400">
                              ({lang.englishName})
                            </span>
                          </div>
                          <span className="text-[9px] text-slate-500 font-mono">
                            {lang.dir.toUpperCase()} • Code: {lang.code}
                          </span>
                        </div>
                      </div>

                      {isSelected ? (
                        <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded-md border border-emerald-400/30">
                          <Check className="w-3.5 h-3.5" />
                          <span>فعال</span>
                        </div>
                      ) : (
                        <button className="text-[11px] text-slate-400 hover:text-slate-200 px-2.5 py-1 bg-white/[0.04] rounded-lg border border-white/[0.08]">
                          Select
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: Search Parameters */}
          {activeTab === "algorithm" && (
            <div className="flex flex-col gap-4">
              {/* Threshold */}
              <div>
                <div className="flex justify-between mb-1.5 font-semibold text-slate-200">
                  <span>{t("similarityThreshold", "آستانه حداقل شباهت (Threshold %):")}</span>
                  <span className="font-mono text-cyan-400">{tempConfig.threshold}%</span>
                </div>
                <input
                  type="range"
                  min="60"
                  max="98"
                  value={tempConfig.threshold}
                  onChange={(e) =>
                    setTempConfig({ ...tempConfig, threshold: parseInt(e.target.value) })
                  }
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              {/* Future Candles */}
              <div>
                <div className="flex justify-between mb-1.5 font-semibold text-slate-200">
                  <span>{t("futureCandlesCount", "تعداد کندل‌های آینده (آینده‌نگری):")}</span>
                  <span className="font-mono text-cyan-400">{tempConfig.futureCandles}</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="100"
                  value={tempConfig.futureCandles}
                  onChange={(e) =>
                    setTempConfig({ ...tempConfig, futureCandles: parseInt(e.target.value) })
                  }
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              {/* Pattern Length */}
              <div>
                <div className="flex justify-between mb-1.5 font-semibold text-slate-200">
                  <span>{t("patternLength", "طول بازه الگو (تعداد کندل):")}</span>
                  <span className="font-mono text-cyan-400">{tempConfig.patternLength}</span>
                </div>
                <input
                  type="range"
                  min="15"
                  max="150"
                  value={tempConfig.patternLength}
                  onChange={(e) =>
                    setTempConfig({ ...tempConfig, patternLength: parseInt(e.target.value) })
                  }
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              {/* Range Lookback */}
              <div>
                <div className="flex justify-between mb-1.5 font-semibold text-slate-200">
                  <span>{t("rangeTolerance", "بازه محاسبه رنج (Range Lookback):")}</span>
                  <span className="font-mono text-cyan-400">{tempConfig.rangeLookback}</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="20"
                  value={tempConfig.rangeLookback}
                  onChange={(e) =>
                    setTempConfig({ ...tempConfig, rangeLookback: parseInt(e.target.value) })
                  }
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              {/* Skip Overlap Checkbox */}
              <div className="flex items-center gap-3 bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                <input
                  type="checkbox"
                  id="chk-overlap"
                  checked={tempConfig.skipOverlap}
                  onChange={(e) =>
                    setTempConfig({ ...tempConfig, skipOverlap: e.target.checked })
                  }
                  className="w-4 h-4 accent-emerald-400 rounded cursor-pointer"
                />
                <label htmlFor="chk-overlap" className="cursor-pointer text-slate-200 font-medium">
                  {t("skipOverlap", "فیلتر هم‌پوشانی الگوهای تکراری مجاور (Skip Overlaps)")}
                </label>
              </div>
            </div>
          )}

          {/* TAB 4: Similarity Weights */}
          {activeTab === "weights" && (
            <div className="flex flex-col gap-4">
              <p className="text-slate-400 text-xs leading-relaxed">
                {t("weightsNotice", "ترکیب ضرایب محاسباتی موتور برای انطباق آماری و ساختاری:")}
              </p>

              {/* Pearson */}
              <div>
                <div className="flex justify-between mb-1 font-semibold text-slate-200">
                  <span>{t("pearsonWeight", "همبستگی پیرسون (Pearson Correlation)")}</span>
                  <span className="font-mono text-cyan-400">
                    {Math.round(tempConfig.weights.pearson * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={tempConfig.weights.pearson}
                  onChange={(e) =>
                    setTempConfig({
                      ...tempConfig,
                      weights: { ...tempConfig.weights, pearson: parseFloat(e.target.value) },
                    })
                  }
                  className="w-full accent-cyan-400"
                />
              </div>

              {/* DTW */}
              <div>
                <div className="flex justify-between mb-1 font-semibold text-slate-200">
                  <span>{t("dtwWeight", "انطباق دینامیکی زمانی (Dynamic Time Warping - DTW)")}</span>
                  <span className="font-mono text-cyan-400">
                    {Math.round(tempConfig.weights.dtw * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={tempConfig.weights.dtw}
                  onChange={(e) =>
                    setTempConfig({
                      ...tempConfig,
                      weights: { ...tempConfig.weights, dtw: parseFloat(e.target.value) },
                    })
                  }
                  className="w-full accent-cyan-400"
                />
              </div>

              {/* Slope */}
              <div>
                <div className="flex justify-between mb-1 font-semibold text-slate-200">
                  <span>{t("slopeWeight", "شیب و زاویه کلی بردار (Slope Vector)")}</span>
                  <span className="font-mono text-cyan-400">
                    {Math.round(tempConfig.weights.slope * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={tempConfig.weights.slope}
                  onChange={(e) =>
                    setTempConfig({
                      ...tempConfig,
                      weights: { ...tempConfig.weights, slope: parseFloat(e.target.value) },
                    })
                  }
                  className="w-full accent-cyan-400"
                />
              </div>

              {/* Structural */}
              <div>
                <div className="flex justify-between mb-1 font-semibold text-slate-200">
                  <span>{t("structuralWeight", "ساختار قله‌ها و کف‌ها (Structural Extrema)")}</span>
                  <span className="font-mono text-cyan-400">
                    {Math.round(tempConfig.weights.structural * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={tempConfig.weights.structural}
                  onChange={(e) =>
                    setTempConfig({
                      ...tempConfig,
                      weights: { ...tempConfig.weights, structural: parseFloat(e.target.value) },
                    })
                  }
                  className="w-full accent-cyan-400"
                />
              </div>
            </div>
          )}

          {/* TAB 5: Market Data Manager */}
          {activeTab === "data" && (
            <MarketDataManager
              datasets={datasets}
              onUpdateDatasets={onUpdateDatasets}
              selectedDatasetIds={selectedDatasetIds}
              onToggleDatasetId={onToggleDatasetId}
              onSelectAllDatasets={onSelectAllDatasets}
              isPersian={activeLanguage === "fa"}
            />
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-900/90 border-t border-slate-800/80 px-4 sm:px-6 py-3 flex items-center justify-between">
          <button
            onClick={handleResetDefaults}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 px-3 py-1.5 bg-white/[0.04] hover:bg-white/[0.08] rounded-xl border border-white/[0.08] transition-all cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{t("resetDefaults", "بازنشانی پیش‌فرض")}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3.5 py-1.5 text-xs font-semibold text-slate-400 hover:text-slate-200 transition-all cursor-pointer"
            >
              {t("clearAll", "بستن")}
            </button>
            <button
              onClick={handleSave}
              className="flex items-center gap-1.5 px-4 py-1.5 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-200 hover:text-white border border-emerald-400/40 font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer active:scale-[0.98]"
            >
              <Check className="w-4 h-4" />
              <span>{t("saveAndApply", "ذخیره و بستن")}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
