import React, { useState } from "react";
import {
  Activity,
  X,
  Plus,
  Trash2,
  Check,
  Download,
  Upload,
  Calendar,
  Layers,
  Sparkles,
} from "lucide-react";
import { MyDNAPattern } from "../engine/types";
import { PRESET_PATTERNS } from "../engine/presetPatterns";

interface MyDNAModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedPatterns: MyDNAPattern[];
  onApplyPattern: (pattern: number[], name: string) => void;
  onDeletePattern: (id: string) => void;
  onImportLibrary: (patterns: MyDNAPattern[]) => void;
  isPersian: boolean;
}

export const MyDNAModal: React.FC<MyDNAModalProps> = ({
  isOpen,
  onClose,
  savedPatterns,
  onApplyPattern,
  onDeletePattern,
  onImportLibrary,
  isPersian,
}) => {
  const [selectedId, setSelectedId] = useState<string | null>(
    savedPatterns[0]?.id || null
  );

  if (!isOpen) return null;

  const activePattern = savedPatterns.find((p) => p.id === selectedId) || savedPatterns[0];

  const handleExportJSON = () => {
    const jsonStr = JSON.stringify(savedPatterns, null, 2);
    const blob = new Blob([jsonStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `chartdna_my_library_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const parsed = JSON.parse(ev.target?.result as string);
        if (Array.isArray(parsed)) {
          onImportLibrary(parsed);
        }
      } catch (err) {
        console.error("Failed to import JSON library", err);
      }
    };
    reader.readAsText(file);
  };

  // Generate SVG path string from 1D points
  const generateSvgPath = (points: number[], width = 280, height = 120) => {
    if (!points || points.length < 2) return "";
    const minVal = Math.min(...points);
    const maxVal = Math.max(...points);
    const span = maxVal - minVal || 1;

    return points
      .map((val, idx) => {
        const x = (idx / (points.length - 1)) * (width - 20) + 10;
        const normY = (val - minVal) / span;
        const y = height - 10 - normY * (height - 20);
        return `${idx === 0 ? "M" : "L"} ${x.toFixed(1)} ${y.toFixed(1)}`;
      })
      .join(" ");
  };

  return (
    <div
      id="my-dna-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-black/80 backdrop-blur-sm"
    >
      <div className="bg-[#0d1322] border border-slate-700/80 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-slate-900/90 border-b border-slate-800 px-5 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center justify-center">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">
                {isPersian ? "کتابخانه الگوهای ذخیره شده (My DNA Library)" : "My DNA Patterns Library"}
              </h2>
              <p className="text-xs text-slate-400">
                {isPersian
                  ? "مدیریت، پیش‌نمایش و اعمال الگوهای سفارشی یا هندسه‌های استخراج‌شده"
                  : "Saved algorithmic signatures, extracted geometries, and custom user patterns"}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 flex-1 overflow-y-auto flex flex-col md:flex-row gap-5 text-xs text-slate-300">
          {/* Left: Pattern List */}
          <div className="w-full md:w-80 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-200">
                {isPersian ? "الگوهای موجود:" : "Stored Patterns:"} ({savedPatterns.length})
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleExportJSON}
                  className="p-1 text-slate-400 hover:text-emerald-400 rounded hover:bg-slate-800"
                  title="Export library as JSON"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
                <label
                  className="p-1 text-slate-400 hover:text-cyan-400 rounded hover:bg-slate-800 cursor-pointer"
                  title="Import JSON library"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <input
                    type="file"
                    accept=".json"
                    className="hidden"
                    onChange={handleImportJSON}
                  />
                </label>
              </div>
            </div>

            <div className="flex-1 max-h-[360px] overflow-y-auto flex flex-col gap-2 pr-1">
              {savedPatterns.map((p) => {
                const isSelected = selectedId === p.id;
                return (
                  <div
                    key={p.id}
                    onClick={() => setSelectedId(p.id)}
                    className={`p-3 rounded-xl border transition-all cursor-pointer flex flex-col gap-1.5 ${
                      isSelected
                        ? "bg-emerald-950/40 border-emerald-500/60 shadow-sm"
                        : "bg-slate-900/70 border-slate-800 hover:bg-slate-800/60"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-100 text-xs">
                        {p.name}
                      </span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                        {p.category || "General"}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-slate-400">
                      <span className="flex items-center gap-1 font-mono">
                        <Calendar className="w-3 h-3 text-slate-500" />
                        {p.createdAt || "2024"}
                      </span>
                      <span className="font-mono">{p.points?.length || 80} pts</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right: Detailed Inspection & Waveform */}
          <div className="flex-1 flex flex-col gap-4 bg-slate-950/60 border border-slate-800 rounded-xl p-4">
            {activePattern ? (
              <>
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <span>{activePattern.name}</span>
                      <span className="text-[10px] font-normal px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                        {activePattern.category || "Custom DNA"}
                      </span>
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {activePattern.notes || "Mathematical curve pattern signature"}
                    </p>
                  </div>

                  <button
                    onClick={() => onDeletePattern(activePattern.id)}
                    className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-slate-900 rounded-lg transition-colors"
                    title="Delete pattern from library"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                {/* SVG Visualizer */}
                <div className="h-44 bg-[#090d16] border border-slate-800 rounded-xl flex items-center justify-center p-3 relative overflow-hidden">
                  <svg className="w-full h-full" viewBox="0 0 280 120" preserveAspectRatio="none">
                    <path
                      d={generateSvgPath(activePattern.points, 280, 120)}
                      fill="none"
                      stroke="#10b981"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </div>

                {/* Apply Button */}
                <div className="flex items-center justify-end gap-3 mt-auto pt-3 border-t border-slate-800">
                  <button
                    onClick={() => {
                      onApplyPattern(activePattern.points, activePattern.name);
                      onClose();
                    }}
                    className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-emerald-600/25 transition-all"
                  >
                    <Check className="w-4 h-4" />
                    <span>{isPersian ? "اعمال به‌عنوان الگوی جستجو" : "Apply as Active Search DNA"}</span>
                  </button>
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-slate-500">
                <Layers className="w-8 h-8 mb-2" />
                <p>{isPersian ? "الگویی انتخاب نشده است" : "No pattern selected"}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
