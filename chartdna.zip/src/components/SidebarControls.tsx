import React from "react";
import {
  Image as ImageIcon,
  Trash2,
  Crop,
  Play,
  Square,
  TrendingUp,
  TrendingDown,
  Minus,
} from "lucide-react";
import { TrendBreakdown } from "../engine/types";
import { LanguageCode, getTranslation } from "../i18n/languages";
import { ThemeId, getTheme } from "../theme/themes";

interface SidebarControlsProps {
  onSelectImageClick: () => void;
  onClearAll: () => void;
  onExtractPattern: () => void;
  onStartAnalysis: () => void;
  onStopAnalysis: () => void;
  isAnalyzing: boolean;
  progressPercent: number;
  hasImage: boolean;
  hasPattern: boolean;
  hasDatasets: boolean;
  trendBreakdown: TrendBreakdown | null;
  rangeLookback: number;
  activeLanguage: LanguageCode;
  activeTheme?: ThemeId;
}

export const SidebarControls: React.FC<SidebarControlsProps> = ({
  onSelectImageClick,
  onClearAll,
  onExtractPattern,
  onStartAnalysis,
  onStopAnalysis,
  isAnalyzing,
  progressPercent,
  hasImage,
  hasPattern,
  hasDatasets,
  trendBreakdown,
  rangeLookback,
  activeLanguage,
  activeTheme = "cyber-obsidian",
}) => {
  const t = (key: string, fallback?: string) => getTranslation(activeLanguage, key, fallback);
  const theme = getTheme(activeTheme);

  return (
    <aside
      id="sidebar-controls"
      className="w-full backdrop-blur-xl border rounded-2xl p-3 flex flex-col gap-2.5 shadow-xl h-full overflow-y-auto transition-colors duration-200"
      style={{
        backgroundColor: `${theme.colors.sidebarBg}f0`,
        borderColor: theme.colors.border,
        color: theme.colors.text,
      }}
    >
      {/* Primary Action Buttons */}
      <div className="flex flex-col gap-2">
        {/* Import Image */}
        <button
          id="btn-import-image"
          onClick={onSelectImageClick}
          className="w-full flex items-center justify-center gap-2 px-3 py-2 border font-medium text-xs rounded-xl transition-all duration-150 shadow-sm cursor-pointer active:scale-[0.98]"
          style={{
            backgroundColor: `${theme.colors.subpanelBg}ee`,
            borderColor: theme.colors.borderSubtle,
            color: theme.colors.text,
          }}
        >
          <ImageIcon className="w-3.5 h-3.5 shrink-0" style={{ color: theme.colors.secondary }} />
          <span className="truncate">{t("importChartImage", "Import Chart Image")}</span>
        </button>

        {/* Extract Pattern from Image */}
        <button
          id="btn-extract-pattern"
          onClick={onExtractPattern}
          disabled={!hasImage}
          className="w-full flex items-center justify-center gap-2 px-3 py-2 font-medium text-xs rounded-xl transition-all duration-150 shadow-sm"
          style={{
            backgroundColor: hasImage ? `${theme.colors.primary}20` : `${theme.colors.subpanelBg}50`,
            borderColor: hasImage ? `${theme.colors.primary}50` : theme.colors.borderSubtle,
            color: hasImage ? theme.colors.primary : theme.colors.textMuted,
            cursor: hasImage ? "pointer" : "not-allowed",
            opacity: hasImage ? 1 : 0.6,
          }}
        >
          <Crop className="w-3.5 h-3.5 shrink-0" />
          <span className="truncate">{t("extractFromCrop", "Extract From Crop")}</span>
        </button>

        {/* Clear All */}
        <button
          id="btn-clear-all"
          onClick={onClearAll}
          className="w-full flex items-center justify-center gap-2 px-3 py-1.5 bg-rose-950/20 hover:bg-rose-900/30 active:bg-rose-950/40 border border-rose-900/30 hover:border-rose-700/40 text-rose-300/90 hover:text-rose-200 font-medium text-[11px] rounded-xl transition-all duration-150 cursor-pointer active:scale-[0.98]"
        >
          <Trash2 className="w-3 h-3 shrink-0" />
          <span className="truncate">{t("clearAll", "Clear All")}</span>
        </button>

        {/* Start Analysis Button */}
        <button
          id="btn-start-analysis"
          onClick={onStartAnalysis}
          disabled={isAnalyzing || !hasPattern || !hasDatasets}
          className="w-full flex items-center justify-center gap-2 px-3 py-2.5 font-bold text-xs rounded-xl transition-all duration-150 shadow-md"
          style={{
            backgroundColor: !isAnalyzing && hasPattern && hasDatasets ? theme.colors.primary : `${theme.colors.subpanelBg}60`,
            color: !isAnalyzing && hasPattern && hasDatasets ? theme.colors.primaryText : theme.colors.textMuted,
            borderColor: !isAnalyzing && hasPattern && hasDatasets ? `${theme.colors.primary}80` : theme.colors.borderSubtle,
            cursor: !isAnalyzing && hasPattern && hasDatasets ? "pointer" : "not-allowed",
            opacity: !isAnalyzing && hasPattern && hasDatasets ? 1 : 0.6,
          }}
        >
          <Play className="w-3.5 h-3.5 fill-current shrink-0" />
          <span className="truncate">{t("startDnaSearch", "Start DNA Search")}</span>
        </button>

        {/* Stop Analysis Button */}
        {isAnalyzing && (
          <button
            id="btn-stop-analysis"
            onClick={onStopAnalysis}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 font-bold text-xs rounded-xl transition-all duration-150 bg-red-600/80 hover:bg-red-500/90 border border-red-400/40 text-white shadow-md shadow-red-950/50 cursor-pointer animate-pulse active:scale-[0.98]"
          >
            <Square className="w-3.5 h-3.5 fill-current shrink-0" />
            <span className="truncate">{t("stopAnalysis", "Stop Analysis")}</span>
          </button>
        )}
      </div>

      {/* Progress Bar & Percentage */}
      <div
        className="backdrop-blur-md border rounded-xl p-2.5 flex flex-col gap-1.5"
        style={{
          backgroundColor: `${theme.colors.subpanelBg}bb`,
          borderColor: theme.colors.borderSubtle,
        }}
      >
        <div className="flex items-center justify-between text-[11px] font-semibold" style={{ color: theme.colors.text }}>
          <span>{t("scanProgress", "Scan Progress")}</span>
          <span className="font-mono" style={{ color: theme.colors.primary }}>{progressPercent}%</span>
        </div>
        <div
          className="w-full h-2 rounded-full overflow-hidden border"
          style={{
            backgroundColor: theme.colors.bg,
            borderColor: theme.colors.borderSubtle,
          }}
        >
          <div
            className="h-full transition-all duration-200 rounded-full"
            style={{
              width: `${progressPercent}%`,
              backgroundColor: theme.colors.primary,
            }}
          />
        </div>
      </div>

      {/* Post-Analysis Trend Summary Box */}
      <div
        className="backdrop-blur-md border rounded-xl p-2.5 flex flex-col gap-2"
        style={{
          backgroundColor: `${theme.colors.subpanelBg}bb`,
          borderColor: theme.colors.borderSubtle,
        }}
      >
        <div className="flex items-center justify-between">
          <h3 className="text-[11px] font-bold uppercase tracking-wider" style={{ color: theme.colors.text }}>
            {t("trendForecast", "Trend Forecast")}
          </h3>
          {trendBreakdown && (
            <span className="text-[9px] font-mono" style={{ color: theme.colors.textMuted }}>
              ({trendBreakdown.total} {t("hits", "hits")})
            </span>
          )}
        </div>

        {/* Visual Multi-Color Bar */}
        <div
          className="w-full h-3 rounded-md overflow-hidden flex border"
          style={{
            backgroundColor: theme.colors.bg,
            borderColor: theme.colors.borderSubtle,
          }}
        >
          {trendBreakdown && trendBreakdown.total > 0 ? (
            <>
              {trendBreakdown.pctUp > 0 && (
                <div
                  className="h-full bg-emerald-500 transition-all"
                  style={{ width: `${trendBreakdown.pctUp}%` }}
                  title={`Bullish: ${trendBreakdown.pctUp.toFixed(1)}%`}
                />
              )}
              {trendBreakdown.pctDown > 0 && (
                <div
                  className="h-full bg-rose-500 transition-all"
                  style={{ width: `${trendBreakdown.pctDown}%` }}
                  title={`Bearish: ${trendBreakdown.pctDown.toFixed(1)}%`}
                />
              )}
              {trendBreakdown.pctRange > 0 && (
                <div
                  className="h-full bg-slate-600 transition-all"
                  style={{ width: `${trendBreakdown.pctRange}%` }}
                  title={`Range: ${trendBreakdown.pctRange.toFixed(1)}%`}
                />
              )}
            </>
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <span className="text-[9px]" style={{ color: theme.colors.textMuted }}>{t("noActiveResults", "No active results")}</span>
            </div>
          )}
        </div>

        {/* Labels & Percentages */}
        <div className="flex flex-col gap-1.5 text-xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-emerald-400">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>{t("bullish", "Bullish")}:</span>
            </div>
            <span className="font-mono font-bold" style={{ color: theme.colors.text }}>
              {trendBreakdown ? `${trendBreakdown.pctUp.toFixed(0)}%` : "—"}
            </span>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-rose-400">
              <TrendingDown className="w-3.5 h-3.5" />
              <span>{t("bearish", "Bearish")}:</span>
            </div>
            <span className="font-mono font-bold" style={{ color: theme.colors.text }}>
              {trendBreakdown ? `${trendBreakdown.pctDown.toFixed(0)}%` : "—"}
            </span>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5" style={{ color: theme.colors.textMuted }}>
              <Minus className="w-3.5 h-3.5" />
              <span>{t("range", "Range")}:</span>
            </div>
            <span className="font-mono font-bold" style={{ color: theme.colors.text }}>
              {trendBreakdown ? `${trendBreakdown.pctRange.toFixed(0)}%` : "—"}
            </span>
          </div>
        </div>

        {/* Explanation footnote */}
        <p
          className="text-[10px] leading-relaxed border-t pt-2 text-justify"
          style={{
            borderColor: theme.colors.borderSubtle,
            color: theme.colors.textMuted,
          }}
        >
          {activeLanguage === "fa"
            ? `محاسبه بر اساس محدوده سقف و کف ${rangeLookback} کندل پایانی بازه آینده نسبت به قیمت انتهایی الگو.`
            : `Calculated from the range of the last ${rangeLookback} future candles relative to pattern closing price.`}
        </p>
      </div>
    </aside>
  );
};
