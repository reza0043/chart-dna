import React from "react";
import {
  Image as ImageIcon,
  Trash2,
  Crop,
  Play,
  Square,
  TrendingUp,
  TrendingDown,
  Minus,
  CheckCircle2,
} from "lucide-react";
import { TrendBreakdown } from "../engine/types";

interface SidebarControlsProps {
  onSelectImageClick: () => void;
  onClearAll: () => void;
  onExtractPattern: () => void;
  onStartAnalysis: () => void;
  onStopAnalysis: () => void;
  isAnalyzing: boolean;
  progressPercent: number;
  hasImage: boolean;
  hasPattern: boolean;
  hasDatasets: boolean;
  trendBreakdown: TrendBreakdown | null;
  rangeLookback: number;
  isPersian: boolean;
}

export const SidebarControls: React.FC<SidebarControlsProps> = ({
  onSelectImageClick,
  onClearAll,
  onExtractPattern,
  onStartAnalysis,
  onStopAnalysis,
  isAnalyzing,
  progressPercent,
  hasImage,
  hasPattern,
  hasDatasets,
  trendBreakdown,
  rangeLookback,
  isPersian,
}) => {
  return (
    <aside
      id="sidebar-controls"
      className="w-full bg-[#0b101c]/85 backdrop-blur-xl border border-slate-800/80 rounded-2xl p-3 flex flex-col gap-2.5 shadow-xl h-full overflow-y-auto"
    >
      {/* Primary Action Buttons */}
      <div className="flex flex-col gap-2">
        {/* Import Image */}
        <button
          id="btn-import-image"
          onClick={onSelectImageClick}
          className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-white/[0.05] hover:bg-white/[0.09] active:bg-white/[0.03] backdrop-blur-md border border-white/[0.1] hover:border-emerald-500/40 text-slate-200 hover:text-white font-medium text-xs rounded-xl transition-all duration-150 shadow-sm cursor-pointer active:scale-[0.98]"
        >
          <ImageIcon className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span className="truncate">{isPersian ? "ورود تصویر چارت" : "Import Chart Image"}</span>
        </button>

        {/* Extract Pattern from Image */}
        <button
          id="btn-extract-pattern"
          onClick={onExtractPattern}
          disabled={!hasImage}
          className={`w-full flex items-center justify-center gap-2 px-3 py-2 font-medium text-xs rounded-xl transition-all duration-150 shadow-sm backdrop-blur-md ${
            hasImage
              ? "bg-cyan-500/20 hover:bg-cyan-500/30 active:bg-cyan-500/15 border border-cyan-400/40 text-cyan-200 hover:text-white shadow-cyan-950/40 cursor-pointer active:scale-[0.98]"
              : "bg-white/[0.02] text-slate-600 border border-white/[0.04] cursor-not-allowed"
          }`}
        >
          <Crop className="w-3.5 h-3.5 shrink-0" />
          <span className="truncate">{isPersian ? "استخراج الگو از کادر" : "Extract From Crop"}</span>
        </button>

        {/* Clear All */}
        <button
          id="btn-clear-all"
          onClick={onClearAll}
          className="w-full flex items-center justify-center gap-2 px-3 py-1.5 bg-rose-950/20 hover:bg-rose-900/30 active:bg-rose-950/40 border border-rose-900/30 hover:border-rose-700/40 text-rose-300/90 hover:text-rose-200 font-medium text-[11px] rounded-xl transition-all duration-150 cursor-pointer active:scale-[0.98]"
        >
          <Trash2 className="w-3 h-3 shrink-0" />
          <span className="truncate">{isPersian ? "پاکسازی محیط" : "Clear All"}</span>
        </button>

        {/* Start Analysis Button (Prominent Glassy Emerald) */}
        <button
          id="btn-start-analysis"
          onClick={onStartAnalysis}
          disabled={isAnalyzing || !hasPattern || !hasDatasets}
          className={`w-full flex items-center justify-center gap-2 px-3 py-2.5 font-bold text-xs rounded-xl transition-all duration-150 shadow-md backdrop-blur-md ${
            !isAnalyzing && hasPattern && hasDatasets
              ? "bg-gradient-to-r from-emerald-500/90 to-teal-500/90 hover:from-emerald-500 hover:to-teal-500 text-white border border-emerald-300/40 shadow-emerald-950/50 cursor-pointer active:scale-[0.98]"
              : "bg-white/[0.02] text-slate-600 border border-white/[0.04] cursor-not-allowed"
          }`}
        >
          <Play className="w-3.5 h-3.5 fill-current shrink-0" />
          <span className="truncate">{isPersian ? "شروع تحلیل DNA" : "Start DNA Search"}</span>
        </button>

        {/* Stop Analysis Button */}
        {isAnalyzing && (
          <button
            id="btn-stop-analysis"
            onClick={onStopAnalysis}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 font-bold text-xs rounded-xl transition-all duration-150 bg-red-600/80 hover:bg-red-500/90 border border-red-400/40 text-white shadow-md shadow-red-950/50 cursor-pointer animate-pulse active:scale-[0.98]"
          >
            <Square className="w-3.5 h-3.5 fill-current shrink-0" />
            <span className="truncate">{isPersian ? "توقف تحلیل" : "Stop Analysis"}</span>
          </button>
        )}
      </div>

      {/* Progress Bar & Percentage */}
      <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800/70 rounded-xl p-2.5 flex flex-col gap-1.5">
        <div className="flex items-center justify-between text-[11px] font-semibold text-slate-300">
          <span>{isPersian ? "پیشرفت اسکن" : "Scan Progress"}</span>
          <span className="font-mono text-emerald-400">{progressPercent}%</span>
        </div>
        <div className="w-full h-2 bg-slate-950/80 rounded-full overflow-hidden border border-slate-800/80">
          <div
            className="h-full bg-gradient-to-r from-emerald-400 to-cyan-400 transition-all duration-200 rounded-full"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Post-Analysis Trend Summary Box */}
      <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800/70 rounded-xl p-2.5 flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <h3 className="text-[11px] font-bold text-slate-200 uppercase tracking-wider">
            {isPersian ? "خلاصه‌ی روند" : "Trend Forecast"}
          </h3>
          {trendBreakdown && (
            <span className="text-[9px] text-slate-400 font-mono">
              ({trendBreakdown.total})
            </span>
          )}
        </div>

        {/* Visual Multi-Color Bar */}
        <div className="w-full h-3 bg-slate-950/80 rounded-md overflow-hidden flex border border-slate-800/80">
          {trendBreakdown && trendBreakdown.total > 0 ? (
            <>
              {trendBreakdown.pctUp > 0 && (
                <div
                  className="h-full bg-emerald-500 transition-all"
                  style={{ width: `${trendBreakdown.pctUp}%` }}
                  title={`Bullish: ${trendBreakdown.pctUp.toFixed(1)}%`}
                />
              )}
              {trendBreakdown.pctDown > 0 && (
                <div
                  className="h-full bg-rose-500 transition-all"
                  style={{ width: `${trendBreakdown.pctDown}%` }}
                  title={`Bearish: ${trendBreakdown.pctDown.toFixed(1)}%`}
                />
              )}
              {trendBreakdown.pctRange > 0 && (
                <div
                  className="h-full bg-slate-600 transition-all"
                  style={{ width: `${trendBreakdown.pctRange}%` }}
                  title={`Range: ${trendBreakdown.pctRange.toFixed(1)}%`}
                />
              )}
            </>
          ) : (
            <div className="w-full h-full bg-slate-800/30 flex items-center justify-center">
              <span className="text-[9px] text-slate-500">{isPersian ? "هنوز تحلیلی انجام نشده" : "No active results"}</span>
            </div>
          )}
        </div>

        {/* Labels & Percentages */}
        <div className="flex flex-col gap-1.5 text-xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-emerald-400">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>{isPersian ? "صعودی (Bullish):" : "Bullish (Up):"}</span>
            </div>
            <span className="font-mono font-bold text-slate-200">
              {trendBreakdown ? `${trendBreakdown.pctUp.toFixed(0)}%` : "—"}
            </span>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-rose-400">
              <TrendingDown className="w-3.5 h-3.5" />
              <span>{isPersian ? "نزولی (Bearish):" : "Bearish (Down):"}</span>
            </div>
            <span className="font-mono font-bold text-slate-200">
              {trendBreakdown ? `${trendBreakdown.pctDown.toFixed(0)}%` : "—"}
            </span>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-slate-400">
              <Minus className="w-3.5 h-3.5" />
              <span>{isPersian ? "رنج (Range):" : "Consolidation (Range):"}</span>
            </div>
            <span className="font-mono font-bold text-slate-200">
              {trendBreakdown ? `${trendBreakdown.pctRange.toFixed(0)}%` : "—"}
            </span>
          </div>
        </div>

        {/* Explanation footnote */}
        <p className="text-[10px] text-slate-400 leading-relaxed border-t border-slate-800/80 pt-2 text-justify">
          {isPersian
            ? `محاسبه بر اساس محدوده سقف و کف ${rangeLookback} کندل پایانی بازه آینده نسبت به قیمت انتهایی الگو.`
            : `Calculated from the high/low range of the last ${rangeLookback} future candles relative to pattern closing price.`}
        </p>
      </div>
    </aside>
  );
};
