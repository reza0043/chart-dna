import React, { useState, useRef, useEffect } from "react";
import {
  Layers,
  Settings as SettingsIcon,
  TrendingUp,
  Globe,
  Palette,
  Check,
  ChevronDown,
} from "lucide-react";
import { SUPPORTED_LANGUAGES, LanguageCode, getTranslation } from "../i18n/languages";
import { THEMES, ThemeId, getTheme } from "../theme/themes";

interface HeaderProps {
  activeSymbol: string;
  selectedDatasetsCount: number;
  totalCandlesCount: number;
  onOpenSettings: () => void;
  activeLanguage: LanguageCode;
  onSelectLanguage: (lang: LanguageCode) => void;
  activeTheme: ThemeId;
  onSelectTheme: (theme: ThemeId) => void;
}

export const Header: React.FC<HeaderProps> = ({
  selectedDatasetsCount,
  totalCandlesCount,
  onOpenSettings,
  activeLanguage,
  onSelectLanguage,
  activeTheme,
  onSelectTheme,
}) => {
  const [isLangOpen, setIsLangOpen] = useState(false);
  const [isThemeOpen, setIsThemeOpen] = useState(false);

  const langRef = useRef<HTMLDivElement>(null);
  const themeRef = useRef<HTMLDivElement>(null);

  const t = (key: string, fallback?: string) => getTranslation(activeLanguage, key, fallback);
  const currentLang = SUPPORTED_LANGUAGES.find((l) => l.code === activeLanguage) || SUPPORTED_LANGUAGES[0];
  const currentTheme = getTheme(activeTheme);

  // Click outside to close dropdowns
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (langRef.current && !langRef.current.contains(e.target as Node)) {
        setIsLangOpen(false);
      }
      if (themeRef.current && !themeRef.current.contains(e.target as Node)) {
        setIsThemeOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <header
      id="app-header"
      className="px-3 sm:px-5 lg:px-8 py-2.5 sticky top-0 z-40 backdrop-blur-xl border-b transition-colors duration-200"
      style={{
        backgroundColor: `${currentTheme.colors.headerBg}f0`,
        borderColor: currentTheme.colors.border,
        color: currentTheme.colors.text,
      }}
    >
      <div className="w-full max-w-[1920px] mx-auto flex flex-wrap items-center justify-between gap-3">
        {/* Brand & Logo */}
        <div className="flex items-center gap-3">
          <div
            className="w-11 h-11 rounded-xl flex items-center justify-center p-1 shadow-lg overflow-hidden shrink-0 border"
            style={{
              backgroundColor: currentTheme.colors.subpanelBg,
              borderColor: currentTheme.colors.border,
            }}
          >
            <img
              src="/logo.png"
              alt="Chart DNA Logo"
              className="w-full h-full object-cover rounded-lg"
            />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold tracking-tight flex items-center gap-1.5 font-mono" style={{ color: currentTheme.colors.text }}>
                <span>{t("appTitle", "CHART")}</span>
                <span className="font-extrabold" style={{ color: currentTheme.colors.primary }}>DNA</span>
              </h1>
              <span
                className="px-2 py-0.5 text-[10px] font-semibold rounded-full border"
                style={{
                  backgroundColor: `${currentTheme.colors.secondary}15`,
                  color: currentTheme.colors.secondary,
                  borderColor: `${currentTheme.colors.secondary}30`,
                }}
              >
                v2.3 Pro
              </span>
            </div>
            <p className="text-xs line-clamp-1 max-w-md" style={{ color: currentTheme.colors.textMuted }}>
              {t("appSubtitle", "Next-Gen Algorithmic Pattern Search Engine powered by DTW & Pearson")}
            </p>
          </div>
        </div>

        {/* Data Badge & Quick Stats */}
        <div
          className="hidden md:flex items-center gap-2.5 px-3.5 py-1.5 rounded-xl text-xs backdrop-blur-md border"
          style={{
            backgroundColor: `${currentTheme.colors.subpanelBg}cc`,
            borderColor: currentTheme.colors.borderSubtle,
            color: currentTheme.colors.textMuted,
          }}
        >
          <div className="flex items-center gap-1.5" style={{ color: currentTheme.colors.text }}>
            <Layers className="w-3.5 h-3.5" style={{ color: currentTheme.colors.primary }} />
            <span>
              {selectedDatasetsCount} {t("selectedDatasets", "دیتاست فعال")}
            </span>
          </div>
          <span style={{ color: currentTheme.colors.border }}>•</span>
          <div className="flex items-center gap-1.5" style={{ color: currentTheme.colors.text }}>
            <TrendingUp className="w-3.5 h-3.5" style={{ color: currentTheme.colors.secondary }} />
            <span>
              {totalCandlesCount.toLocaleString()} {t("candlesCount", "کندل")}
            </span>
          </div>
        </div>

        {/* Actions: Theme Dropdown, Language Dropdown, Settings */}
        <div className="flex items-center gap-2">
          {/* Quick Theme Selector Dropdown */}
          <div className="relative" ref={themeRef}>
            <button
              id="btn-quick-theme"
              onClick={() => {
                setIsThemeOpen(!isThemeOpen);
                setIsLangOpen(false);
              }}
              className="flex items-center gap-1.5 px-2.5 py-1.5 backdrop-blur-md border text-xs font-medium rounded-xl transition-all duration-150 cursor-pointer shadow-sm active:scale-[0.98]"
              style={{
                backgroundColor: `${currentTheme.colors.subpanelBg}ee`,
                borderColor: currentTheme.colors.border,
                color: currentTheme.colors.text,
              }}
              title={t("themes", "انتخاب تم رنگی")}
            >
              <Palette className="w-3.5 h-3.5" style={{ color: currentTheme.colors.primary }} />
              <span className="hidden sm:inline font-medium text-xs">
                {currentTheme.name[activeLanguage] || currentTheme.name.en}
              </span>
              <span
                className="w-2.5 h-2.5 rounded-full border border-black/40"
                style={{ backgroundColor: currentTheme.colors.primary }}
              />
              <ChevronDown className="w-3 h-3 opacity-70" />
            </button>

            {isThemeOpen && (
              <div
                className="absolute right-0 rtl:right-auto rtl:left-0 mt-2 w-64 max-h-80 border rounded-2xl p-2 shadow-2xl z-50 overflow-y-auto backdrop-blur-2xl"
                style={{
                  backgroundColor: currentTheme.colors.cardBg,
                  borderColor: currentTheme.colors.border,
                  color: currentTheme.colors.text,
                }}
              >
                <div
                  className="px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider border-b mb-1"
                  style={{
                    color: currentTheme.colors.textMuted,
                    borderColor: currentTheme.colors.borderSubtle,
                  }}
                >
                  {t("tabThemes", "۱۰ تم رنگی مختلف")}
                </div>
                {THEMES.map((th) => {
                  const isCur = th.id === activeTheme;
                  return (
                    <button
                      key={th.id}
                      onClick={() => {
                        onSelectTheme(th.id);
                        setIsThemeOpen(false);
                      }}
                      className="w-full text-left rtl:text-right flex items-center justify-between px-2.5 py-2 rounded-xl text-xs transition-colors cursor-pointer"
                      style={{
                        backgroundColor: isCur ? `${th.colors.primary}25` : "transparent",
                        color: isCur ? th.colors.primary : currentTheme.colors.text,
                      }}
                    >
                      <div className="flex items-center gap-2">
                        <span
                          className="w-3.5 h-3.5 rounded-full border border-black/50"
                          style={{ backgroundColor: th.colors.primary }}
                        />
                        <span>{th.name[activeLanguage] || th.name.en}</span>
                      </div>
                      {isCur && <Check className="w-3.5 h-3.5" style={{ color: th.colors.primary }} />}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* 10 Languages Dropdown */}
          <div className="relative" ref={langRef}>
            <button
              id="btn-quick-lang"
              onClick={() => {
                setIsLangOpen(!isLangOpen);
                setIsThemeOpen(false);
              }}
              className="flex items-center gap-1.5 px-2.5 py-1.5 backdrop-blur-md border text-xs font-medium rounded-xl transition-all duration-150 cursor-pointer shadow-sm active:scale-[0.98]"
              style={{
                backgroundColor: `${currentTheme.colors.subpanelBg}ee`,
                borderColor: currentTheme.colors.border,
                color: currentTheme.colors.text,
              }}
              title={t("language", "انتخاب زبان")}
            >
              <span className="text-base leading-none">{currentLang.flag}</span>
              <span className="font-mono text-xs font-bold">{currentLang.code.toUpperCase()}</span>
              <ChevronDown className="w-3 h-3 opacity-70" />
            </button>

            {isLangOpen && (
              <div
                className="absolute right-0 rtl:right-auto rtl:left-0 mt-2 w-52 max-h-80 border rounded-2xl p-2 shadow-2xl z-50 overflow-y-auto backdrop-blur-2xl"
                style={{
                  backgroundColor: currentTheme.colors.cardBg,
                  borderColor: currentTheme.colors.border,
                  color: currentTheme.colors.text,
                }}
              >
                <div
                  className="px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider border-b mb-1"
                  style={{
                    color: currentTheme.colors.textMuted,
                    borderColor: currentTheme.colors.borderSubtle,
                  }}
                >
                  {t("tabLanguages", "۱۰ زبان زنده دنیا")}
                </div>
                {SUPPORTED_LANGUAGES.map((lang) => {
                  const isCur = lang.code === activeLanguage;
                  return (
                    <button
                      key={lang.code}
                      onClick={() => {
                        onSelectLanguage(lang.code);
                        setIsLangOpen(false);
                      }}
                      className="w-full text-left rtl:text-right flex items-center justify-between px-2.5 py-2 rounded-xl text-xs transition-colors cursor-pointer"
                      style={{
                        backgroundColor: isCur ? `${currentTheme.colors.secondary}25` : "transparent",
                        color: isCur ? currentTheme.colors.secondary : currentTheme.colors.text,
                      }}
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="text-lg">{lang.flag}</span>
                        <div className="flex flex-col">
                          <span>{lang.name}</span>
                          <span className="text-[9px]" style={{ color: currentTheme.colors.textMuted }}>{lang.englishName}</span>
                        </div>
                      </div>
                      {isCur && <Check className="w-3.5 h-3.5" style={{ color: currentTheme.colors.secondary }} />}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Full Settings Modal Trigger */}
          <button
            id="btn-open-settings"
            onClick={onOpenSettings}
            className="flex items-center gap-1.5 px-3 py-1.5 backdrop-blur-md border text-xs font-semibold rounded-xl transition-all duration-150 cursor-pointer shadow-sm active:scale-[0.98]"
            style={{
              backgroundColor: `${currentTheme.colors.primary}20`,
              borderColor: `${currentTheme.colors.primary}50`,
              color: currentTheme.colors.primary,
            }}
          >
            <SettingsIcon className="w-3.5 h-3.5" style={{ color: currentTheme.colors.primary }} />
            <span>{t("settings", "تنظیمات")}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
