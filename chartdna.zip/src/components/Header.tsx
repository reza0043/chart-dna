import React from "react";
import {
  Layers,
  Settings as SettingsIcon,
  TrendingUp,
  Globe,
} from "lucide-react";

interface HeaderProps {
  activeSymbol: string;
  selectedDatasetsCount: number;
  totalCandlesCount: number;
  onOpenSettings: () => void;
  isPersian: boolean;
  onToggleLanguage: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeSymbol,
  selectedDatasetsCount,
  totalCandlesCount,
  onOpenSettings,
  isPersian,
  onToggleLanguage,
}) => {
  return (
    <header
      id="app-header"
      className="bg-[#0f172a]/95 border-b border-slate-800/80 px-3 sm:px-5 lg:px-8 py-2.5 sticky top-0 z-40 backdrop-blur-md"
    >
      <div className="w-full max-w-[1920px] mx-auto flex flex-wrap items-center justify-between gap-3">
        {/* Brand & Logo */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-black border border-slate-700/80 flex items-center justify-center p-1 shadow-lg shadow-cyan-950/40 overflow-hidden shrink-0">
            <img
              src="/logo.png"
              alt="Chart DNA Logo"
              className="w-full h-full object-cover rounded-lg"
            />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold text-white tracking-tight flex items-center gap-1.5 font-mono">
                <span className="text-slate-100">CHART</span>
                <span className="text-cyan-400 font-extrabold">DNA</span>
              </h1>
              <span className="px-2 py-0.5 text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-full">
                v2.2 Pro
              </span>
            </div>
            <p className="text-xs text-slate-400">
              {isPersian
                ? "موتور هوشمند تطبیق الگوی چارت و هوش بازار"
                : "Algorithmic Market Pattern DNA & Technical Intelligence"}
            </p>
          </div>
        </div>

        {/* Data Badge & Quick Stats */}
        <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-slate-900/80 border border-slate-800 rounded-lg text-xs">
          <div className="flex items-center gap-1.5 text-slate-300">
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            <span>{selectedDatasetsCount} {isPersian ? "تایم‌فریم فعال" : "Timeframes"}</span>
          </div>
          <span className="text-slate-600">•</span>
          <div className="flex items-center gap-1.5 text-slate-300">
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            <span>{totalCandlesCount.toLocaleString()} {isPersian ? "کندل بارگذاری شده" : "Candles"}</span>
          </div>
        </div>

        {/* Actions: Settings & Language only */}
        <div className="flex items-center gap-2">
          {/* Settings */}
          <button
            id="btn-open-settings"
            onClick={onOpenSettings}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-white/[0.06] hover:bg-white/[0.1] active:bg-white/[0.04] backdrop-blur-md border border-white/[0.12] hover:border-cyan-500/40 text-slate-100 text-xs font-semibold rounded-xl transition-all duration-150 cursor-pointer shadow-sm active:scale-[0.98]"
          >
            <SettingsIcon className="w-3.5 h-3.5 text-cyan-400" />
            <span>{isPersian ? "تنظیمات" : "Settings"}</span>
          </button>

          {/* Language Toggle */}
          <button
            id="btn-toggle-lang"
            onClick={onToggleLanguage}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-white/[0.04] hover:bg-white/[0.08] active:bg-white/[0.03] backdrop-blur-md border border-white/[0.08] hover:border-slate-600 text-slate-300 text-xs font-medium rounded-xl transition-all duration-150 cursor-pointer active:scale-[0.98]"
            title="Toggle English / Persian"
          >
            <Globe className="w-3.5 h-3.5 text-slate-400" />
            <span className="font-mono text-[11px]">{isPersian ? "EN" : "فا"}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
