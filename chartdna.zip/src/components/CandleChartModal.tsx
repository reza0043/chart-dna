import React, { useRef, useEffect, useState } from "react";
import {
  X,
  Maximize2,
  Minimize2,
  Sliders,
  Sparkles,
  TrendingUp,
  TrendingDown,
  Minus,
  Info,
  Calendar,
  Layers,
  ZoomIn,
  ZoomOut,
  AlertCircle,
  Eye,
} from "lucide-react";
import { MatchResult, Candle, MarketDataset } from "../engine/types";
import { LanguageCode, getTranslation } from "../i18n/languages";
import { ThemeId, getTheme } from "../theme/themes";

interface CandleChartModalProps {
  isOpen: boolean;
  onClose: () => void;
  result: MatchResult | null;
  datasets: MarketDataset[];
  activeLanguage: LanguageCode;
  activeTheme?: ThemeId;
}

export const CandleChartModal: React.FC<CandleChartModalProps> = ({
  isOpen,
  onClose,
  result,
  datasets,
  activeLanguage,
  activeTheme = "cyber-obsidian",
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const t = (key: string, fallback?: string) => getTranslation(activeLanguage, key, fallback);
  const theme = getTheme(activeTheme);
  const isPersian = activeLanguage === "fa";

  // Settings
  const [beforeCount, setBeforeCount] = useState(40);
  const [afterCount, setAfterCount] = useState(40);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  // Colors (TradingView theme)
  const [bgColor, setBgColor] = useState(theme.colors.bg || "#0b0f17");
  const [gridColor, setGridColor] = useState("rgba(255, 255, 255, 0.07)");
  const [bullColor, setBullColor] = useState("#10b981");
  const [bearColor, setBearColor] = useState("#ef4444");
  const [patternHighlight, setPatternHighlight] = useState("rgba(56, 189, 248, 0.16)");

  // Hover candle state
  const [hoverCandle, setHoverCandle] = useState<{
    candle: Candle;
    index: number;
    x: number;
    y: number;
  } | null>(null);

  // Container dimensions for stable rendering
  const [dimensions, setDimensions] = useState({ width: 800, height: 500 });


  // Resolve matching dataset
  const dataset = React.useMemo(() => {
    if (!result) return datasets[0] || null;
    return (
      (result.datasetId && datasets.find((d) => d.id === result.datasetId)) ||
      datasets.find(
        (d) =>
          d.symbol.toUpperCase() === result.symbol.toUpperCase() &&
          d.timeframe.toUpperCase() === result.timeframe.toUpperCase()
      ) ||
      datasets.find((d) => d.name.toLowerCase() === result.fileName.toLowerCase()) ||
      datasets.find((d) => d.symbol.toUpperCase() === result.symbol.toUpperCase()) ||
      datasets[0] ||
      null
    );
  }, [result, datasets]);

  // Extract visible candles around match
  const totalCandles = dataset?.candles || [];
  const startIdx = result ? Math.max(0, result.startIndex - beforeCount) : 0;
  const endIdx = result ? Math.min(totalCandles.length, result.endIndex + afterCount + 1) : 0;
  const visibleCandles = React.useMemo(() => {
    if (!result || totalCandles.length === 0) return [];
    return totalCandles.slice(startIdx, endIdx);
  }, [totalCandles, startIdx, endIdx, result]);

  const patternLocalStart = result ? Math.max(0, result.startIndex - startIdx) : 0;
  const patternLocalEnd = result ? Math.min(visibleCandles.length - 1, result.endIndex - startIdx) : 0;

  // Track container size with ResizeObserver
  useEffect(() => {
    if (!isOpen) return;
    const container = containerRef.current;
    if (!container) return;

    const updateSize = () => {
      const w = container.clientWidth || 800;
      const h = container.clientHeight || 500;
      if (w > 0 && h > 0) {
        setDimensions({ width: w, height: h });
      }
    };

    updateSize();
    const ro = new ResizeObserver(() => {
      updateSize();
    });
    ro.observe(container);

    return () => ro.disconnect();
  }, [isOpen, isFullscreen, showSettings]);

  // Draw Candlestick Chart
  useEffect(() => {
    if (!isOpen || !result) return;
    const canvas = canvasRef.current;
    if (!canvas || visibleCandles.length === 0) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const { width, height } = dimensions;

    canvas.width = width * dpr;
    canvas.height = height * dpr;

    ctx.resetTransform?.();
    ctx.scale(dpr, dpr);

    // 1. Background
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, width, height);

    // Padding
    const padLeft = 20;
    const padRight = 80;
    const padTop = 35;
    const padBottom = 40;
    const plotWidth = Math.max(10, width - padLeft - padRight);
    const plotHeight = Math.max(10, height - padTop - padBottom);

    // 2. Price Bounds
    let minPrice = Infinity;
    let maxPrice = -Infinity;

    for (const c of visibleCandles) {
      if (c.low < minPrice) minPrice = c.low;
      if (c.high > maxPrice) maxPrice = c.high;
    }

    if (minPrice === maxPrice || !isFinite(minPrice) || !isFinite(maxPrice)) {
      minPrice = 1;
      maxPrice = 2;
    }

    const pricePadding = (maxPrice - minPrice) * 0.08 || 0.01;
    minPrice -= pricePadding;
    maxPrice += pricePadding;
    const totalRange = maxPrice - minPrice || 1;

    const mapY = (price: number) =>
      padTop + plotHeight - ((price - minPrice) / totalRange) * plotHeight;
    const candleWidth = Math.max(3, (plotWidth / visibleCandles.length) * 0.72);
    const mapX = (idx: number) =>
      padLeft + (idx + 0.5) * (plotWidth / visibleCandles.length);

    // 3. Grid Lines (Horizontal Price Levels)
    ctx.strokeStyle = gridColor;
    ctx.lineWidth = 1;
    ctx.fillStyle = "#94a3b8";
    ctx.font = "10px sans-serif";
    ctx.textAlign = "left";

    const priceSteps = 6;
    for (let i = 0; i <= priceSteps; i++) {
      const p = minPrice + (totalRange / priceSteps) * i;
      const y = mapY(p);

      ctx.beginPath();
      ctx.moveTo(padLeft, y);
      ctx.lineTo(width - padRight, y);
      ctx.stroke();

      // Right axis price label
      const formattedPrice =
        p >= 1000 ? p.toFixed(2) : p >= 10 ? p.toFixed(3) : p.toFixed(5);
      ctx.fillText(formattedPrice, width - padRight + 8, y + 3);
    }

    // 4. Highlight Pattern Area
    if (patternLocalStart >= 0 && patternLocalEnd < visibleCandles.length) {
      const leftX = mapX(patternLocalStart) - candleWidth * 1.2;
      const rightX = mapX(patternLocalEnd) + candleWidth * 1.2;
      const spanWidth = rightX - leftX;

      // Fill span
      ctx.fillStyle = patternHighlight;
      ctx.fillRect(leftX, padTop, spanWidth, plotHeight);

      // Border outline for pattern span
      ctx.strokeStyle = "rgba(56, 189, 248, 0.4)";
      ctx.lineWidth = 1.5;
      ctx.strokeRect(leftX, padTop, spanWidth, plotHeight);

      // Top label for Pattern Window
      ctx.fillStyle = "#38bdf8";
      ctx.font = "bold 11px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(
        isPersian ? "🎯 محدوده الگوی کشف شده" : "🎯 Matched Pattern Span",
        leftX + spanWidth / 2,
        padTop - 10
      );
    }

    // 5. Draw Candlesticks (Wicks and Bodies)
    for (let i = 0; i < visibleCandles.length; i++) {
      const c = visibleCandles[i];
      const x = mapX(i);
      const isBull = c.close >= c.open;
      const color = isBull ? bullColor : bearColor;

      const yOpen = mapY(c.open);
      const yClose = mapY(c.close);
      const yHigh = mapY(c.high);
      const yLow = mapY(c.low);

      // High-Low Wick
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(x, yHigh);
      ctx.lineTo(x, yLow);
      ctx.stroke();

      // Body
      const bodyTop = Math.min(yOpen, yClose);
      const bodyHeight = Math.max(1.5, Math.abs(yClose - yOpen));

      ctx.fillStyle = color;
      ctx.fillRect(x - candleWidth / 2, bodyTop, candleWidth, bodyHeight);
    }

    // 6. Crosshair & Hover Tooltip
    if (hoverCandle) {
      ctx.save();
      ctx.setLineDash([4, 4]);
      ctx.strokeStyle = "rgba(255, 255, 255, 0.35)";
      ctx.lineWidth = 1;

      // Vertical line
      ctx.beginPath();
      ctx.moveTo(hoverCandle.x, padTop);
      ctx.lineTo(hoverCandle.x, height - padBottom);
      ctx.stroke();

      // Horizontal line
      ctx.beginPath();
      ctx.moveTo(padLeft, hoverCandle.y);
      ctx.lineTo(width - padRight, hoverCandle.y);
      ctx.stroke();

      ctx.restore();
    }

    // 7. Time Axis labels at bottom
    ctx.fillStyle = "#64748b";
    ctx.font = "10px sans-serif";
    ctx.textAlign = "center";

    const labelStep = Math.max(1, Math.floor(visibleCandles.length / 8));
    for (let i = 0; i < visibleCandles.length; i += labelStep) {
      const x = mapX(i);
      const rawTs = visibleCandles[i].timestamp;
      const ts = rawTs.includes(" ") ? rawTs.split(" ")[1] : rawTs;
      ctx.fillText(ts, x, height - 12);
    }
  }, [
    isOpen,
    result,
    visibleCandles,
    dimensions,
    bgColor,
    gridColor,
    bullColor,
    bearColor,
    patternHighlight,
    patternLocalStart,
    patternLocalEnd,
    hoverCandle,
    isPersian,
  ]);

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas || visibleCandles.length === 0) return;
    const rect = canvas.getBoundingClientRect();
    const padLeft = 20;
    const padRight = 80;
    const plotWidth = rect.width - padLeft - padRight;

    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    if (mouseX >= padLeft && mouseX <= rect.width - padRight) {
      const idx = Math.floor(
        ((mouseX - padLeft) / plotWidth) * visibleCandles.length
      );
      if (idx >= 0 && idx < visibleCandles.length) {
        setHoverCandle({
          candle: visibleCandles[idx],
          index: idx,
          x: mouseX,
          y: mouseY,
        });
      }
    } else {
      setHoverCandle(null);
    }
  };

  if (!isOpen || !result) return null;

  return (
    <div
      id="candle-chart-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/85 backdrop-blur-md"
    >
      <div
        className={`border rounded-2xl flex flex-col shadow-2xl overflow-hidden transition-all duration-200 ${
          isFullscreen ? "w-full h-full rounded-none" : "w-full max-w-6xl h-[90vh]"
        }`}
        style={{
          backgroundColor: theme.colors.cardBg,
          borderColor: theme.colors.border,
          color: theme.colors.text,
        }}
      >
        {/* Top Title & Info Bar */}
        <div
          className="border-b px-4 py-3 flex flex-wrap items-center justify-between gap-3"
          style={{
            backgroundColor: theme.colors.headerBg,
            borderColor: theme.colors.borderSubtle,
          }}
        >
          <div className="flex items-center gap-3">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs shadow-inner"
              style={{
                backgroundColor: `${theme.colors.primary}20`,
                color: theme.colors.primary,
              }}
            >
              OHLC
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold" style={{ color: theme.colors.text }}>
                  {result.symbol} — {result.timeframe}
                </h2>
                <span
                  className="px-2 py-0.5 rounded font-mono text-xs font-bold border"
                  style={{
                    backgroundColor: `${theme.colors.secondary}20`,
                    color: theme.colors.secondary,
                    borderColor: `${theme.colors.secondary}40`,
                  }}
                >
                  {result.similarity.toFixed(2)}% {isPersian ? "شباهت" : "Match"}
                </span>
                <span
                  className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                    result.trend === "up"
                      ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                      : result.trend === "down"
                      ? "bg-rose-500/20 text-rose-400 border border-rose-500/30"
                      : "bg-slate-800 text-slate-300 border border-slate-700"
                  }`}
                >
                  {result.trend === "up"
                    ? (isPersian ? "صعودی ▲" : "▲ Bullish")
                    : result.trend === "down"
                    ? (isPersian ? "نزولی ▼" : "▼ Bearish")
                    : (isPersian ? "رنج ▬" : "▬ Range")}
                </span>
              </div>
              <p className="text-xs font-mono mt-0.5" style={{ color: theme.colors.textMuted }}>
                {isPersian ? "بازه الگو:" : "Pattern Span:"} {result.startTime} → {result.endTime} ({visibleCandles.length} candles in view)
              </p>
            </div>
          </div>

          {/* Quick Candle OHLC HUD on hover */}
          {hoverCandle ? (
            <div
              className="hidden lg:flex items-center gap-3 px-3 py-1.5 rounded-xl text-xs font-mono border"
              style={{
                backgroundColor: theme.colors.subpanelBg,
                borderColor: theme.colors.borderSubtle,
              }}
            >
              <span style={{ color: theme.colors.textMuted }}>{hoverCandle.candle.timestamp}</span>
              <span style={{ color: theme.colors.textMuted }}>
                O: <strong style={{ color: theme.colors.text }}>{hoverCandle.candle.open}</strong>
              </span>
              <span className="text-emerald-400">
                H: <strong className="text-emerald-300">{hoverCandle.candle.high}</strong>
              </span>
              <span className="text-rose-400">
                L: <strong className="text-rose-300">{hoverCandle.candle.low}</strong>
              </span>
              <span style={{ color: theme.colors.textMuted }}>
                C:{" "}
                <strong
                  className={
                    hoverCandle.candle.close >= hoverCandle.candle.open
                      ? "text-emerald-400"
                      : "text-rose-400"
                  }
                >
                  {hoverCandle.candle.close}
                </strong>
              </span>
            </div>
          ) : (
            <div className="hidden lg:flex items-center gap-2 text-xs font-sans" style={{ color: theme.colors.textMuted }}>
              <Info className="w-3.5 h-3.5" />
              <span>
                {isPersian
                  ? "ماوس را روی کندل‌ها حرکت دهید تا اطلاعات قیمتی نمایش داده شود"
                  : "Hover over candles for precise OHLC details"}
              </span>
            </div>
          )}

          {/* Header Controls */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowSettings(!showSettings)}
              className="p-2 rounded-xl border transition-colors cursor-pointer"
              style={{
                backgroundColor: showSettings ? theme.colors.primary : theme.colors.subpanelBg,
                borderColor: showSettings ? theme.colors.primary : theme.colors.borderSubtle,
                color: showSettings ? theme.colors.primaryText : theme.colors.text,
              }}
              title={isPersian ? "تنظیمات بازه و ظاهر" : "Candle display settings"}
            >
              <Sliders className="w-4 h-4" />
            </button>

            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 rounded-xl border transition-colors cursor-pointer"
              style={{
                backgroundColor: theme.colors.subpanelBg,
                borderColor: theme.colors.borderSubtle,
                color: theme.colors.text,
              }}
              title={isFullscreen ? "خروج از تمام صفحه" : "تمام صفحه"}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/40 border border-rose-500/30 text-rose-300 transition-colors cursor-pointer"
              title={isPersian ? "بستن پنجره" : "Close window"}
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Main Body */}
        <div className="flex-1 flex flex-col lg:flex-row overflow-hidden relative min-h-0">
          {/* Settings Drawer (Collapsible) */}
          {showSettings && (
            <div
              className="w-full lg:w-72 border-b lg:border-b-0 lg:border-r p-4 flex flex-col gap-4 text-xs overflow-y-auto z-10"
              style={{
                backgroundColor: theme.colors.subpanelBg,
                borderColor: theme.colors.borderSubtle,
              }}
            >
              <h3 className="font-bold text-slate-200 text-sm flex items-center gap-2">
                <Sliders className="w-4 h-4 text-cyan-400" />
                <span>{isPersian ? "تنظیمات نمایش کندل‌ها" : "Candle View Settings"}</span>
              </h3>

              {/* Before Count */}
              <div>
                <label className="block text-slate-300 font-medium mb-1.5">
                  {isPersian ? "تعداد کندل قبل از الگو:" : "Candles Before Pattern:"}
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="range"
                    min="10"
                    max="200"
                    step="5"
                    value={beforeCount}
                    onChange={(e) => setBeforeCount(parseInt(e.target.value))}
                    className="flex-1 accent-cyan-400"
                  />
                  <span className="font-mono text-cyan-300 w-8 text-right">{beforeCount}</span>
                </div>
              </div>

              {/* After Count */}
              <div>
                <label className="block text-slate-300 font-medium mb-1.5">
                  {isPersian ? "تعداد کندل بعد از الگو (آینده):" : "Candles After Pattern (Future):"}
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="range"
                    min="10"
                    max="200"
                    step="5"
                    value={afterCount}
                    onChange={(e) => setAfterCount(parseInt(e.target.value))}
                    className="flex-1 accent-emerald-400"
                  />
                  <span className="font-mono text-emerald-300 w-8 text-right">{afterCount}</span>
                </div>
              </div>

              {/* Quick presets for range */}
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => {
                    setBeforeCount(20);
                    setAfterCount(20);
                  }}
                  className="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-[11px] text-slate-300"
                >
                  ±20
                </button>
                <button
                  onClick={() => {
                    setBeforeCount(50);
                    setAfterCount(50);
                  }}
                  className="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-[11px] text-slate-300"
                >
                  ±50
                </button>
                <button
                  onClick={() => {
                    setBeforeCount(100);
                    setAfterCount(100);
                  }}
                  className="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-[11px] text-slate-300"
                >
                  ±100
                </button>
              </div>

              {/* Color Customizer */}
              <div className="border-t border-slate-800 pt-3 flex flex-col gap-2.5">
                <h4 className="font-semibold text-slate-300">
                  {isPersian ? "رنگ‌بندی چارت" : "Chart Colors"}
                </h4>

                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Bullish Candle:</span>
                  <input
                    type="color"
                    value={bullColor}
                    onChange={(e) => setBullColor(e.target.value)}
                    className="w-6 h-6 rounded cursor-pointer bg-transparent border-0"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Bearish Candle:</span>
                  <input
                    type="color"
                    value={bearColor}
                    onChange={(e) => setBearColor(e.target.value)}
                    className="w-6 h-6 rounded cursor-pointer bg-transparent border-0"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Interactive Candlestick Canvas Container */}
          <div
            ref={containerRef}
            className="flex-1 h-full bg-[#0b0f17] relative flex items-center justify-center p-2 min-h-0 w-full overflow-hidden"
          >
            {visibleCandles.length > 0 ? (
              <canvas
                ref={canvasRef}
                onMouseMove={handleCanvasMouseMove}
                onMouseLeave={() => setHoverCandle(null)}
                className="w-full h-full block cursor-crosshair"
              />
            ) : (
              <div className="p-8 text-center flex flex-col items-center gap-3 text-slate-400">
                <AlertCircle className="w-10 h-10 text-amber-400" />
                <h4 className="text-sm font-bold text-slate-200">
                  {isPersian
                    ? "کندل‌های این الگو در دیتابیس فعال بارگذاری نشدند."
                    : "No candle records found for this result."}
                </h4>
                <p className="text-xs text-slate-500 font-mono max-w-md">
                  {isPersian
                    ? `نماد: ${result.symbol} | تایم‌فریم: ${result.timeframe} | فایل: ${result.fileName}`
                    : `Symbol: ${result.symbol} | Timeframe: ${result.timeframe} | File: ${result.fileName}`}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
