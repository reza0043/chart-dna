import React, { useState } from "react";
import {
  Sparkles,
  X,
  Upload,
  Send,
  Loader2,
  Bot,
  FileText,
  AlertCircle,
  Copy,
  Check,
  Zap,
} from "lucide-react";
import { MatchResult } from "../engine/types";
import { LanguageCode, getTranslation } from "../i18n/languages";
import { ThemeId, getTheme } from "../theme/themes";

interface AIVisionModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentImageBase64: string | null;
  referencePattern: number[] | null;
  selectedMatch: MatchResult | null;
  activeLanguage: LanguageCode;
  activeTheme?: ThemeId;
}

export const AIVisionModal: React.FC<AIVisionModalProps> = ({
  isOpen,
  onClose,
  currentImageBase64,
  referencePattern,
  selectedMatch,
  activeLanguage,
  activeTheme = "cyber-obsidian",
}) => {
  const [imageBase64, setImageBase64] = useState<string | null>(currentImageBase64);
  const [promptExtra, setPromptExtra] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [analysisText, setAnalysisText] = useState<string | null>(null);
  const [errorText, setErrorText] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const t = (key: string, fallback?: string) => getTranslation(activeLanguage, key, fallback);
  const theme = getTheme(activeTheme);
  const isPersian = activeLanguage === "fa";

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (ev) => {
      setImageBase64(ev.target?.result as string);
      setAnalysisText(null);
      setErrorText(null);
    };
    reader.readAsDataURL(file);
  };

  const handleRunAnalysis = async () => {
    if (!imageBase64) {
      setErrorText(
        isPersian
          ? "لطفاً ابتدا یک تصویر چارت بارگذاری کنید."
          : "Please upload or provide a chart screenshot first."
      );
      return;
    }

    setIsLoading(true);
    setErrorText(null);
    setAnalysisText(null);

    try {
      const response = await fetch("/api/ai-vision", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64,
          promptExtra: `${promptExtra} (Please respond in ${activeLanguage === "fa" ? "Persian technical terms" : activeLanguage} language)`,
          patternContext: selectedMatch
            ? {
                symbol: selectedMatch.symbol,
                timeframe: selectedMatch.timeframe,
                similarity: selectedMatch.similarity,
                trend: selectedMatch.trend,
              }
            : null,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Failed to analyze chart.");
      }

      setAnalysisText(data.analysis);
    } catch (err: any) {
      setErrorText(err.message || "Failed to contact AI Vision server.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    if (!analysisText) return;
    navigator.clipboard.writeText(analysisText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      id="ai-vision-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-black/80 backdrop-blur-sm"
    >
      <div
        className="border rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden"
        style={{
          backgroundColor: theme.colors.cardBg,
          borderColor: theme.colors.border,
          color: theme.colors.text,
        }}
      >
        {/* Header */}
        <div
          className="border-b px-5 py-3.5 flex items-center justify-between"
          style={{
            backgroundColor: theme.colors.headerBg,
            borderColor: theme.colors.borderSubtle,
          }}
        >
          <div className="flex items-center gap-3">
            <div
              className="w-9 h-9 rounded-xl border flex items-center justify-center"
              style={{
                backgroundColor: `${theme.colors.primary}20`,
                color: theme.colors.primary,
                borderColor: `${theme.colors.primary}40`,
              }}
            >
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold" style={{ color: theme.colors.text }}>
                  {t("aiVision", "AI Technical Chart Vision")}
                </h2>
                <span
                  className="px-2 py-0.5 text-[10px] font-semibold rounded-full border"
                  style={{
                    backgroundColor: `${theme.colors.primary}20`,
                    color: theme.colors.primary,
                    borderColor: `${theme.colors.primary}40`,
                  }}
                >
                  Gemini 2.5 Flash
                </span>
              </div>
              <p className="text-xs" style={{ color: theme.colors.textMuted }}>
                {t("aiVisionDesc", "Automated trend confirmation, key support/resistance levels, and structural pattern recognition")}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg transition-colors border"
            style={{
              backgroundColor: theme.colors.subpanelBg,
              borderColor: theme.colors.borderSubtle,
              color: theme.colors.textMuted,
            }}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 flex-1 overflow-y-auto flex flex-col md:flex-row gap-5 text-xs">
          {/* Left: Input & Preview */}
          <div className="w-full md:w-1/2 flex flex-col gap-4">
            <div className="flex flex-col gap-2">
              <label className="font-semibold flex items-center justify-between" style={{ color: theme.colors.text }}>
                <span>{t("chartImageSource", "Chart Image Source:")}</span>
                <label
                  className="text-[11px] hover:underline cursor-pointer flex items-center gap-1"
                  style={{ color: theme.colors.primary }}
                >
                  <Upload className="w-3 h-3" />
                  <span>{t("changeImage", "Upload Different Image")}</span>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleFileUpload}
                  />
                </label>
              </label>

              <div
                className="h-44 border rounded-xl overflow-hidden flex items-center justify-center p-2"
                style={{
                  backgroundColor: theme.colors.subpanelBg,
                  borderColor: theme.colors.borderSubtle,
                }}
              >
                {imageBase64 ? (
                  <img
                    src={imageBase64}
                    alt="Chart preview"
                    className="max-h-full max-w-full object-contain rounded"
                  />
                ) : (
                  <div className="text-center" style={{ color: theme.colors.textMuted }}>
                    <Bot className="w-8 h-8 mx-auto mb-1 opacity-60" />
                    <p>{t("noDataLoaded", "No chart image loaded")}</p>
                  </div>
                )}
              </div>
            </div>

            {/* Custom Notes */}
            <div className="flex flex-col gap-1.5">
              <label className="font-semibold" style={{ color: theme.colors.text }}>
                {t("customFocusPrompt", "Custom Focus / Extra Prompt:")}
              </label>
              <textarea
                value={promptExtra}
                onChange={(e) => setPromptExtra(e.target.value)}
                placeholder={
                  isPersian
                    ? "مثال: سطوح حمایت و مقاومت کلیدی را مشخص کن و نسبت ریسک به ریوارد ورود را تخمین بزن..."
                    : "e.g., Identify key support/resistance zones, evaluate breakout momentum, and summarize forward probability..."
                }
                rows={3}
                className="w-full border rounded-xl p-3 focus:outline-none resize-none text-xs"
                style={{
                  backgroundColor: theme.colors.subpanelBg,
                  borderColor: theme.colors.borderSubtle,
                  color: theme.colors.text,
                }}
              />
            </div>

            {/* Run Button */}
            <button
              onClick={handleRunAnalysis}
              disabled={isLoading || !imageBase64}
              className="w-full py-3 px-4 font-bold text-sm rounded-xl flex items-center justify-center gap-2 transition-all shadow-lg cursor-pointer"
              style={{
                backgroundColor: !isLoading && imageBase64 ? theme.colors.primary : `${theme.colors.subpanelBg}`,
                color: !isLoading && imageBase64 ? theme.colors.primaryText : theme.colors.textMuted,
                border: `1px solid ${theme.colors.border}`,
                opacity: !isLoading && imageBase64 ? 1 : 0.6,
              }}
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>{t("processingAI", "Analyzing Chart with AI...")}</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 fill-current" />
                  <span>{t("startAiAnalysis", "Generate AI Technical Analysis")}</span>
                </>
              )}
            </button>
          </div>

          {/* Right: AI Output Response */}
          <div className="w-full md:w-1/2 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="font-semibold flex items-center gap-1.5" style={{ color: theme.colors.text }}>
                <FileText className="w-4 h-4" style={{ color: theme.colors.primary }} />
                <span>{t("aiReportTitle", "AI Technical Intelligence Report:")}</span>
              </span>

              {analysisText && (
                <button
                  onClick={handleCopy}
                  className="flex items-center gap-1 text-[11px] px-2 py-1 rounded-lg border cursor-pointer"
                  style={{
                    backgroundColor: `${theme.colors.primary}20`,
                    borderColor: `${theme.colors.primary}40`,
                    color: theme.colors.primary,
                  }}
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copied ? t("copied", "Copied!") : t("copyReport", "Copy Report")}</span>
                </button>
              )}
            </div>

            <div
              className="flex-1 border rounded-xl p-4 overflow-y-auto max-h-[380px] min-h-[220px]"
              style={{
                backgroundColor: theme.colors.subpanelBg,
                borderColor: theme.colors.borderSubtle,
                color: theme.colors.text,
              }}
            >
              {isLoading ? (
                <div className="flex flex-col items-center justify-center h-full gap-3" style={{ color: theme.colors.textMuted }}>
                  <Loader2 className="w-8 h-8 animate-spin" style={{ color: theme.colors.primary }} />
                  <p className="text-center">
                    {t("aiScanningCandles", "Scanning candle structures, order blocks, and classical geometries...")}
                  </p>
                </div>
              ) : errorText ? (
                <div className="flex items-start gap-2 p-3 bg-rose-950/30 border border-rose-800/50 rounded-xl text-rose-300">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <p>{errorText}</p>
                </div>
              ) : analysisText ? (
                <div className="prose prose-invert prose-xs max-w-none leading-relaxed whitespace-pre-wrap font-sans" style={{ color: theme.colors.text }}>
                  {analysisText}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full gap-2 text-center p-6" style={{ color: theme.colors.textMuted }}>
                  <Sparkles className="w-8 h-8 opacity-40" style={{ color: theme.colors.primary }} />
                  <p>
                    {t("aiPromptHint", "Provide a chart image and click Generate AI Technical Analysis to receive a structured breakdown.")}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

