import React, { useState } from "react";
import {
  Sparkles,
  X,
  Upload,
  Send,
  Loader2,
  Bot,
  FileText,
  AlertCircle,
  Copy,
  Check,
  Zap,
} from "lucide-react";
import { MatchResult } from "../engine/types";

interface AIVisionModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentImageBase64: string | null;
  referencePattern: number[] | null;
  selectedMatch: MatchResult | null;
  isPersian: boolean;
}

export const AIVisionModal: React.FC<AIVisionModalProps> = ({
  isOpen,
  onClose,
  currentImageBase64,
  referencePattern,
  selectedMatch,
  isPersian,
}) => {
  const [imageBase64, setImageBase64] = useState<string | null>(currentImageBase64);
  const [promptExtra, setPromptExtra] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [analysisText, setAnalysisText] = useState<string | null>(null);
  const [errorText, setErrorText] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (ev) => {
      setImageBase64(ev.target?.result as string);
      setAnalysisText(null);
      setErrorText(null);
    };
    reader.readAsDataURL(file);
  };

  const handleRunAnalysis = async () => {
    if (!imageBase64) {
      setErrorText(
        isPersian
          ? "لطفاً ابتدا یک تصویر چارت بارگذاری کنید."
          : "Please upload or provide a chart screenshot first."
      );
      return;
    }

    setIsLoading(true);
    setErrorText(null);
    setAnalysisText(null);

    try {
      const response = await fetch("/api/ai-vision", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64,
          promptExtra: `${promptExtra} ${isPersian ? "(لطفاً پاسخ را به زبان فارسی روان تکنیکال بنویسید)" : ""}`,
          patternContext: selectedMatch
            ? {
                symbol: selectedMatch.symbol,
                timeframe: selectedMatch.timeframe,
                similarity: selectedMatch.similarity,
                trend: selectedMatch.trend,
              }
            : null,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Failed to analyze chart.");
      }

      setAnalysisText(data.analysis);
    } catch (err: any) {
      setErrorText(err.message || "Failed to contact AI Vision server.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    if (!analysisText) return;
    navigator.clipboard.writeText(analysisText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      id="ai-vision-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-black/80 backdrop-blur-sm"
    >
      <div className="bg-[#0d1322] border border-purple-500/30 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-950/80 via-slate-900 to-indigo-950/80 border-b border-purple-500/20 px-5 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-purple-500/20 text-purple-300 border border-purple-500/30 flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold text-white">
                  {isPersian ? "بینایی هوش مصنوعی چارت (AI Chart Vision)" : "AI Technical Chart Vision"}
                </h2>
                <span className="px-2 py-0.5 text-[10px] font-semibold bg-purple-500/20 text-purple-300 rounded-full border border-purple-500/30">
                  Gemini 2.5 Flash
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {isPersian
                  ? "تحلیل خودکار روند، سطوح کلیدی و احتمال ادامه‌دار بودن الگو با پردازش تصویر چارت"
                  : "Automated trend confirmation, key support/resistance levels, and structural pattern recognition"}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 flex-1 overflow-y-auto flex flex-col md:flex-row gap-5 text-xs text-slate-300">
          {/* Left: Input & Preview */}
          <div className="w-full md:w-1/2 flex flex-col gap-4">
            <div className="flex flex-col gap-2">
              <label className="font-semibold text-slate-200 flex items-center justify-between">
                <span>{isPersian ? "تصویر چارت تکنیکال:" : "Chart Image Source:"}</span>
                <label className="text-[11px] text-purple-400 hover:underline cursor-pointer flex items-center gap-1">
                  <Upload className="w-3 h-3" />
                  <span>{isPersian ? "تغییر تصویر" : "Upload Different Image"}</span>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleFileUpload}
                  />
                </label>
              </label>

              <div className="h-44 bg-slate-950 border border-slate-800 rounded-xl overflow-hidden flex items-center justify-center p-2">
                {imageBase64 ? (
                  <img
                    src={imageBase64}
                    alt="Chart preview"
                    className="max-h-full max-w-full object-contain rounded"
                  />
                ) : (
                  <div className="text-center text-slate-500">
                    <Bot className="w-8 h-8 mx-auto mb-1 text-slate-600" />
                    <p>{isPersian ? "تصویری انتخاب نشده است" : "No chart image loaded"}</p>
                  </div>
                )}
              </div>
            </div>

            {/* Custom Notes */}
            <div className="flex flex-col gap-1.5">
              <label className="font-semibold text-slate-200">
                {isPersian ? "دستورات تکمیلی / تمرکز تحلیل:" : "Custom Focus / Extra Prompt:"}
              </label>
              <textarea
                value={promptExtra}
                onChange={(e) => setPromptExtra(e.target.value)}
                placeholder={
                  isPersian
                    ? "مثال: سطوح حمایت و مقاومت کلیدی را مشخص کن و نسبت ریسک به ریوارد ورود را تخمین بزن..."
                    : "e.g., Identify key support/resistance zones, evaluate breakout momentum, and summarize forward probability..."
                }
                rows={3}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-200 focus:outline-none focus:border-purple-500 resize-none text-xs"
              />
            </div>

            {/* Run Button */}
            <button
              onClick={handleRunAnalysis}
              disabled={isLoading || !imageBase64}
              className={`w-full py-3 px-4 font-bold text-sm rounded-xl flex items-center justify-center gap-2 transition-all shadow-lg ${
                !isLoading && imageBase64
                  ? "bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-purple-600/25 cursor-pointer active:scale-[0.98]"
                  : "bg-slate-800 text-slate-500 border border-slate-800 cursor-not-allowed"
              }`}
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>{isPersian ? "در حال پردازش تصویر با Gemini..." : "Analyzing Chart with AI..."}</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 fill-current" />
                  <span>{isPersian ? "شروع تحلیل هوشمند چارت" : "Generate AI Technical Analysis"}</span>
                </>
              )}
            </button>
          </div>

          {/* Right: AI Output Response */}
          <div className="w-full md:w-1/2 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-purple-400" />
                <span>{isPersian ? "گزارش تحلیل ساختاری هوش مصنوعی:" : "AI Technical Intelligence Report:"}</span>
              </span>

              {analysisText && (
                <button
                  onClick={handleCopy}
                  className="flex items-center gap-1 text-[11px] text-purple-300 hover:text-purple-200 px-2 py-1 bg-purple-950/40 rounded-lg border border-purple-500/30"
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copied ? (isPersian ? "کپی شد!" : "Copied!") : (isPersian ? "کپی متن" : "Copy Report")}</span>
                </button>
              )}
            </div>

            <div className="flex-1 bg-slate-950 border border-slate-800 rounded-xl p-4 overflow-y-auto max-h-[380px] min-h-[220px]">
              {isLoading ? (
                <div className="flex flex-col items-center justify-center h-full gap-3 text-slate-400">
                  <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
                  <p className="text-center">
                    {isPersian
                      ? "مدل Gemini 2.5 Flash در حال شناسایی ساختار کندل‌ها و سطوح تکنیکال است..."
                      : "Scanning candle structures, order blocks, and classical geometries..."}
                  </p>
                </div>
              ) : errorText ? (
                <div className="flex items-start gap-2 p-3 bg-rose-950/30 border border-rose-800/50 rounded-xl text-rose-300">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <p>{errorText}</p>
                </div>
              ) : analysisText ? (
                <div className="prose prose-invert prose-xs max-w-none text-slate-300 leading-relaxed whitespace-pre-wrap font-sans">
                  {analysisText}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-slate-500 gap-2 text-center p-6">
                  <Sparkles className="w-8 h-8 text-purple-500/40" />
                  <p>
                    {isPersian
                      ? "تصویر چارت را انتخاب کنید و دکمه شروع تحلیل را بزنید تا هوش مصنوعی سناریوهای حرکتی را پیش‌بینی کند."
                      : "Provide a chart image and click Generate AI Technical Analysis to receive a structured breakdown."}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
