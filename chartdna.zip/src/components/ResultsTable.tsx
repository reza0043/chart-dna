import React, { useState } from "react";
import {
  Table,
  TrendingUp,
  TrendingDown,
  Minus,
  Maximize2,
  ExternalLink,
  Search,
  Filter,
  Eye,
  Sparkles,
} from "lucide-react";
import { MatchResult } from "../engine/types";

interface ResultsTableProps {
  results: MatchResult[];
  selectedIndex: number | null;
  onSelectResult: (index: number) => void;
  onOpenCandleChart: (result: MatchResult) => void;
  isPersian: boolean;
}

export const ResultsTable: React.FC<ResultsTableProps> = ({
  results,
  selectedIndex,
  onSelectResult,
  onOpenCandleChart,
  isPersian,
}) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterTrend, setFilterTrend] = useState<"all" | "up" | "down" | "range">("all");

  const filteredResults = results.filter((r) => {
    const matchesSearch =
      r.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.fileName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.startTime.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTrend = filterTrend === "all" || r.trend === filterTrend;
    return matchesSearch && matchesTrend;
  });

  const selectedResult =
    selectedIndex !== null && results[selectedIndex]
      ? results[selectedIndex]
      : results[0] || null;

  return (
    <div
      id="results-table-card"
      className="bg-[#0f172a] border border-slate-800 rounded-2xl p-4 flex flex-col gap-3 shadow-lg flex-1 min-h-[320px] max-h-[440px]"
    >
      {/* Table Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Table className="w-4 h-4 text-emerald-400" />
          <h2 className="text-sm font-bold text-slate-100">
            {isPersian ? "جدول نتایج تطبیق الگوی چارت" : "Pattern Similarity Match Results"}
          </h2>
          <span className="px-2 py-0.5 text-xs font-mono bg-slate-800 text-slate-300 rounded-full border border-slate-700">
            {filteredResults.length} / {results.length}
          </span>
        </div>

        {/* Selected Result Quick Action & Filters */}
        <div className="flex flex-wrap items-center gap-2">
          {selectedResult && (
            <button
              onClick={() => onOpenCandleChart(selectedResult)}
              className="flex items-center gap-1.5 px-3 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 active:bg-emerald-500/15 border border-emerald-400/30 text-emerald-200 hover:text-white text-xs font-semibold rounded-lg shadow-sm backdrop-blur-md transition-all duration-150 cursor-pointer active:scale-[0.98]"
              title={isPersian ? "باز کردن چارت کندلی تعاملی" : "Open Candlestick Chart Window"}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>
                {isPersian
                  ? `چارت کندلی (${selectedResult.symbol} #${selectedResult.rank})`
                  : `Open Candles (#${selectedResult.rank})`}
              </span>
            </button>
          )}

          {/* Trend Filter */}
          <select
            value={filterTrend}
            onChange={(e) => setFilterTrend(e.target.value as any)}
            className="bg-white/[0.04] border border-white/[0.08] text-slate-300 text-xs rounded-lg px-2.5 py-1 focus:outline-none focus:border-emerald-400/50 backdrop-blur-md"
          >
            <option value="all" className="bg-slate-900 text-slate-200">{isPersian ? "همه روندها" : "All Trends"}</option>
            <option value="up" className="bg-slate-900 text-slate-200">{isPersian ? "فقط صعودی (Bullish)" : "Bullish Only"}</option>
            <option value="down" className="bg-slate-900 text-slate-200">{isPersian ? "فقط نزولی (Bearish)" : "Bearish Only"}</option>
            <option value="range" className="bg-slate-900 text-slate-200">{isPersian ? "فقط رنج (Range)" : "Range Only"}</option>
          </select>

          {/* Search Box */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={isPersian ? "جستجو..." : "Filter..."}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-white/[0.04] border border-white/[0.08] text-slate-200 text-xs rounded-lg pl-8 pr-2.5 py-1 w-32 md:w-36 focus:outline-none focus:border-emerald-400/50 backdrop-blur-md"
            />
          </div>
        </div>
      </div>

      {/* Subtitle / Tip */}
      <p className="text-[11px] text-slate-400">
        {isPersian
          ? "💡 روی هر ردیف کلیک کنید تا انتخاب شود یا با کلیک روی دکمه «نمایش چارت»، پنجره کندل‌های واقعی باز شود."
          : "💡 Click a row to select or click «View Candles» / double-click row to open full interactive candlestick window."}
      </p>

      {/* Results Table Container */}
      <div className="flex-1 overflow-x-auto overflow-y-auto max-h-[380px] border border-slate-800/90 rounded-xl bg-[#090d16]">
        {filteredResults.length > 0 ? (
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-900/90 text-slate-400 uppercase text-[10px] font-semibold sticky top-0 z-10 border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3 text-center w-12">{isPersian ? "ردیف" : "Rank"}</th>
                <th className="py-2.5 px-3 text-center">{isPersian ? "شباهت" : "Similarity"}</th>
                <th className="py-2.5 px-3">{isPersian ? "نماد / تایم‌فریم" : "Symbol / TF"}</th>
                <th className="py-2.5 px-3">{isPersian ? "زمان شروع الگو" : "Start Time"}</th>
                <th className="py-2.5 px-3 text-center">{isPersian ? "ادامه روند" : "Future Trend"}</th>
                <th className="py-2.5 px-3 text-center w-28">{isPersian ? "چارت کندل‌ها" : "Candles"}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {filteredResults.map((result, idx) => {
                const originalIndex = results.indexOf(result);
                const isSelected = selectedIndex === originalIndex;
                const isTop1 = result.rank === 1;

                return (
                  <tr
                    key={`${result.fileName}_${result.startIndex}_${idx}`}
                    onClick={() => onSelectResult(originalIndex)}
                    onDoubleClick={() => onOpenCandleChart(result)}
                    className={`cursor-pointer transition-colors select-none ${
                      isSelected
                        ? "bg-emerald-950/40 text-emerald-200 border-l-4 border-l-emerald-400"
                        : isTop1
                        ? "bg-emerald-950/20 text-slate-200 hover:bg-slate-800/60"
                        : idx % 2 === 0
                        ? "bg-slate-950/40 text-slate-300 hover:bg-slate-800/50"
                        : "bg-slate-900/30 text-slate-300 hover:bg-slate-800/50"
                    }`}
                  >
                    {/* Rank */}
                    <td className="py-2.5 px-3 text-center font-bold">
                      {isTop1 ? (
                        <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[11px]">
                          #1 ⭐
                        </span>
                      ) : (
                        `#${result.rank}`
                      )}
                    </td>

                    {/* Similarity */}
                    <td className="py-2.5 px-3 text-center">
                      <span
                        className={`font-bold text-[11px] px-2 py-0.5 rounded-md ${
                          result.similarity >= 90
                            ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                            : result.similarity >= 80
                            ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/30"
                            : "bg-slate-800 text-slate-300"
                        }`}
                      >
                        {result.similarity.toFixed(2)}%
                      </span>
                    </td>

                    {/* Symbol / File */}
                    <td className="py-2.5 px-3 font-sans font-medium text-slate-200">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-slate-100">{result.symbol}</span>
                        <span className="text-[10px] px-1.5 py-0.2 bg-slate-800 text-cyan-300 border border-slate-700 rounded font-mono font-bold">
                          {result.timeframe}
                        </span>
                      </div>
                    </td>

                    {/* Start Time */}
                    <td className="py-2.5 px-3 text-slate-400 text-[11px]">
                      {result.startTime}
                    </td>

                    {/* Trend */}
                    <td className="py-2.5 px-3 text-center">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold ${
                          result.trend === "up"
                            ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                            : result.trend === "down"
                            ? "bg-rose-500/20 text-rose-400 border border-rose-500/30"
                            : "bg-slate-800 text-slate-400 border border-slate-700"
                        }`}
                      >
                        {result.trend === "up" && <TrendingUp className="w-3 h-3" />}
                        {result.trend === "down" && <TrendingDown className="w-3 h-3" />}
                        {result.trend === "range" && <Minus className="w-3 h-3" />}
                        <span>
                          {result.trend === "up"
                            ? isPersian ? "صعودی" : "Bullish"
                            : result.trend === "down"
                            ? isPersian ? "نزولی" : "Bearish"
                            : isPersian ? "رنج" : "Range"}
                        </span>
                      </span>
                    </td>

                    {/* Open Candles button */}
                    <td className="py-2 px-3 text-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenCandleChart(result);
                        }}
                        className="flex items-center justify-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-600/30 hover:bg-emerald-600 text-emerald-300 hover:text-white border border-emerald-500/40 transition-all font-sans text-xs font-semibold cursor-pointer shadow-sm w-full"
                        title={isPersian ? "مشاهده چارت کندل‌ها و آینده الگو" : "View Candlestick & Future Chart"}
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>{isPersian ? "نمایش چارت" : "View"}</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        ) : (
          <div className="flex flex-col items-center justify-center p-8 text-center text-slate-500 gap-2">
            <p className="text-xs">
              {results.length === 0
                ? isPersian
                  ? "هنوز هیچ نتیجه‌ای یافت نشده است. الگویی را مشخص و دکمه شروع تحلیل DNA را فشار دهید."
                  : "No matches found yet. Extract a pattern and click Start DNA Search."
                : isPersian
                ? "هیچ نتیجه‌ای با فیلتر انتخابی شما همخوانی ندارد."
                : "No results match the current search or trend filter."}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
