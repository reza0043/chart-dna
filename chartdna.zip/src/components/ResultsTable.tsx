import React, { useState } from "react";
import {
  Table,
  TrendingUp,
  TrendingDown,
  Minus,
  Maximize2,
  ExternalLink,
  Search,
  Filter,
  Eye,
  Sparkles,
} from "lucide-react";
import { MatchResult } from "../engine/types";
import { LanguageCode, getTranslation } from "../i18n/languages";
import { ThemeId, getTheme } from "../theme/themes";

interface ResultsTableProps {
  results: MatchResult[];
  selectedIndex: number | null;
  onSelectResult: (index: number) => void;
  onOpenCandleChart: (result: MatchResult) => void;
  activeLanguage: LanguageCode;
  activeTheme: ThemeId;
}

export const ResultsTable: React.FC<ResultsTableProps> = ({
  results,
  selectedIndex,
  onSelectResult,
  onOpenCandleChart,
  activeLanguage,
  activeTheme,
}) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterTrend, setFilterTrend] = useState<"all" | "up" | "down" | "range">("all");

  const t = (key: string, fallback?: string) => getTranslation(activeLanguage, key, fallback);
  const theme = getTheme(activeTheme);

  const filteredResults = results.filter((r) => {
    const matchesSearch =
      r.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.fileName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.startTime.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTrend = filterTrend === "all" || r.trend === filterTrend;
    return matchesSearch && matchesTrend;
  });

  const selectedResult =
    selectedIndex !== null && results[selectedIndex]
      ? results[selectedIndex]
      : results[0] || null;

  return (
    <div
      id="results-table-card"
      className="border rounded-2xl p-4 flex flex-col gap-3 shadow-lg flex-1 min-h-[320px] max-h-[440px] backdrop-blur-xl transition-colors duration-200"
      style={{
        backgroundColor: `${theme.colors.cardBg}ee`,
        borderColor: theme.colors.border,
        color: theme.colors.text,
      }}
    >
      {/* Table Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Table className="w-4 h-4" style={{ color: theme.colors.primary }} />
          <h2 className="text-sm font-bold" style={{ color: theme.colors.text }}>
            {t("resultsTitle", "Pattern Similarity Match Results")}
          </h2>
          <span
            className="px-2 py-0.5 text-xs font-mono rounded-full border"
            style={{
              backgroundColor: theme.colors.subpanelBg,
              borderColor: theme.colors.borderSubtle,
              color: theme.colors.textMuted,
            }}
          >
            {filteredResults.length} / {results.length}
          </span>
        </div>

        {/* Selected Result Quick Action & Filters */}
        <div className="flex flex-wrap items-center gap-2">
          {selectedResult && (
            <button
              onClick={() => onOpenCandleChart(selectedResult)}
              className="flex items-center gap-1.5 px-3 py-1 border text-xs font-semibold rounded-lg shadow-sm backdrop-blur-md transition-all duration-150 cursor-pointer active:scale-[0.98]"
              style={{
                backgroundColor: `${theme.colors.primary}20`,
                borderColor: `${theme.colors.primary}40`,
                color: theme.colors.primary,
              }}
              title={t("interactiveCandlestick", "Open Candlestick Chart Window")}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>
                {t("interactiveCandlestick", "Candles")} (#{selectedResult.rank})
              </span>
            </button>
          )}

          {/* Trend Filter */}
          <select
            value={filterTrend}
            onChange={(e) => setFilterTrend(e.target.value as any)}
            className="border text-xs rounded-lg px-2.5 py-1 focus:outline-none backdrop-blur-md cursor-pointer"
            style={{
              backgroundColor: theme.colors.subpanelBg,
              borderColor: theme.colors.borderSubtle,
              color: theme.colors.text,
            }}
          >
            <option value="all" style={{ backgroundColor: theme.colors.cardBg, color: theme.colors.text }}>{t("allTrends", "All Trends")}</option>
            <option value="up" style={{ backgroundColor: theme.colors.cardBg, color: theme.colors.text }}>{t("bullish", "Bullish Only")}</option>
            <option value="down" style={{ backgroundColor: theme.colors.cardBg, color: theme.colors.text }}>{t("bearish", "Bearish Only")}</option>
            <option value="range" style={{ backgroundColor: theme.colors.cardBg, color: theme.colors.text }}>{t("range", "Range Only")}</option>
          </select>

          {/* Search Box */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2" style={{ color: theme.colors.textMuted }} />
            <input
              type="text"
              placeholder={t("filter", "Filter...")}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="border text-xs rounded-lg pl-8 pr-2.5 py-1 w-32 md:w-36 focus:outline-none backdrop-blur-md"
              style={{
                backgroundColor: theme.colors.subpanelBg,
                borderColor: theme.colors.borderSubtle,
                color: theme.colors.text,
              }}
            />
          </div>
        </div>
      </div>

      {/* Subtitle / Tip */}
      <p className="text-[11px]" style={{ color: theme.colors.textMuted }}>
        💡 {t("resultsSubtitle", "Click a row to select or click «View» to open full interactive candlestick window.")}
      </p>

      {/* Results Table Container */}
      <div
        className="flex-1 overflow-x-auto overflow-y-auto max-h-[380px] border rounded-xl"
        style={{
          backgroundColor: theme.colors.bg,
          borderColor: theme.colors.border,
        }}
      >
        {filteredResults.length > 0 ? (
          <table className="w-full text-left rtl:text-right text-xs border-collapse">
            <thead
              className="uppercase text-[10px] font-semibold sticky top-0 z-10 border-b backdrop-blur-md"
              style={{
                backgroundColor: `${theme.colors.headerBg}f0`,
                borderColor: theme.colors.borderSubtle,
                color: theme.colors.textMuted,
              }}
            >
              <tr>
                <th className="py-2.5 px-3 text-center w-12">{t("rank", "Rank")}</th>
                <th className="py-2.5 px-3 text-center">{t("similarity", "Similarity")}</th>
                <th className="py-2.5 px-3">{t("symbolTf", "Symbol / TF")}</th>
                <th className="py-2.5 px-3">{t("startTime", "Start Time")}</th>
                <th className="py-2.5 px-3 text-center">{t("futureTrend", "Future Trend")}</th>
                <th className="py-2.5 px-3 text-center w-28">{t("viewChart", "Candles")}</th>
              </tr>
            </thead>
            <tbody className="divide-y font-mono" style={{ borderColor: theme.colors.borderSubtle }}>
              {filteredResults.map((result, idx) => {
                const originalIndex = results.indexOf(result);
                const isSelected = selectedIndex === originalIndex;
                const isTop1 = result.rank === 1;

                return (
                  <tr
                    key={`${result.fileName}_${result.startIndex}_${idx}`}
                    onClick={() => onSelectResult(originalIndex)}
                    onDoubleClick={() => onOpenCandleChart(result)}
                    className="cursor-pointer transition-colors select-none"
                    style={{
                      backgroundColor: isSelected
                        ? `${theme.colors.primary}25`
                        : isTop1
                        ? `${theme.colors.primary}10`
                        : idx % 2 === 0
                        ? `${theme.colors.subpanelBg}40`
                        : "transparent",
                      color: isSelected ? theme.colors.primary : theme.colors.text,
                    }}
                  >
                    {/* Rank */}
                    <td className="py-2.5 px-3 text-center font-bold">
                      {isTop1 ? (
                        <span
                          className="px-1.5 py-0.5 rounded text-[11px]"
                          style={{
                            backgroundColor: `${theme.colors.primary}20`,
                            color: theme.colors.primary,
                          }}
                        >
                          #1 ⭐
                        </span>
                      ) : (
                        `#${result.rank}`
                      )}
                    </td>

                    {/* Similarity */}
                    <td className="py-2.5 px-3 text-center">
                      <span
                        className="font-bold text-[11px] px-2 py-0.5 rounded-md border"
                        style={{
                          backgroundColor: `${theme.colors.primary}15`,
                          borderColor: `${theme.colors.primary}30`,
                          color: theme.colors.primary,
                        }}
                      >
                        {result.similarity.toFixed(2)}%
                      </span>
                    </td>

                    {/* Symbol / File */}
                    <td className="py-2.5 px-3 font-sans font-medium">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold" style={{ color: theme.colors.text }}>{result.symbol}</span>
                        <span
                          className="text-[10px] px-1.5 py-0.2 border rounded font-mono font-bold"
                          style={{
                            backgroundColor: theme.colors.subpanelBg,
                            borderColor: theme.colors.borderSubtle,
                            color: theme.colors.secondary,
                          }}
                        >
                          {result.timeframe}
                        </span>
                      </div>
                    </td>

                    {/* Start Time */}
                    <td className="py-2.5 px-3 text-[11px]" style={{ color: theme.colors.textMuted }}>
                      {result.startTime}
                    </td>

                    {/* Trend */}
                    <td className="py-2.5 px-3 text-center">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold ${
                          result.trend === "up"
                            ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                            : result.trend === "down"
                            ? "bg-rose-500/20 text-rose-400 border border-rose-500/30"
                            : "bg-slate-800 text-slate-400 border border-slate-700"
                        }`}
                      >
                        {result.trend === "up" && <TrendingUp className="w-3 h-3" />}
                        {result.trend === "down" && <TrendingDown className="w-3 h-3" />}
                        {result.trend === "range" && <Minus className="w-3 h-3" />}
                        <span>
                          {result.trend === "up"
                            ? t("bullish", "Bullish")
                            : result.trend === "down"
                            ? t("bearish", "Bearish")
                            : t("range", "Range")}
                        </span>
                      </span>
                    </td>

                    {/* Open Candles button */}
                    <td className="py-2 px-3 text-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenCandleChart(result);
                        }}
                        className="flex items-center justify-center gap-1.5 px-2.5 py-1 rounded-lg border transition-all font-sans text-xs font-semibold cursor-pointer shadow-sm w-full active:scale-[0.98]"
                        style={{
                          backgroundColor: `${theme.colors.primary}20`,
                          borderColor: `${theme.colors.primary}40`,
                          color: theme.colors.primary,
                        }}
                        title={t("interactiveCandlestick", "View Candlestick & Future Chart")}
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>{t("viewChart", "View")}</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        ) : (
          <div className="flex flex-col items-center justify-center p-8 text-center gap-2" style={{ color: theme.colors.textMuted }}>
            <p className="text-xs">
              {results.length === 0
                ? t("noResultsYet", "No matches found yet. Extract a pattern and click Start DNA Search.")
                : t("noMatchesFilter", "No results match the current search or trend filter.")}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

