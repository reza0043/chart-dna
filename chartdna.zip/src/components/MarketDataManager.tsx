import React, { useState, useRef } from "react";
import {
  FolderOpen,
  FileSpreadsheet,
  Upload,
  Check,
  CheckSquare,
  Square,
  Trash2,
  Search,
  Layers,
  Sparkles,
  AlertCircle,
  Clock,
  Database,
  Plus,
  RefreshCw,
} from "lucide-react";
import { MarketDataset } from "../engine/types";
import { readAndParseFile } from "../engine/csvFolderParser";
import { buildMultiTimeframeSuite } from "../engine/timeframeBuilder";

interface MarketDataManagerProps {
  datasets: MarketDataset[];
  onUpdateDatasets: (newDatasets: MarketDataset[]) => void;
  selectedDatasetIds: string[];
  onToggleDatasetId: (id: string) => void;
  onSelectAllDatasets: (select: boolean) => void;
  isPersian: boolean;
}

const TIMEFRAME_ORDER = ["M1", "M5", "M15", "M30", "H1", "H4", "D1", "W1", "MN"];

export const MarketDataManager: React.FC<MarketDataManagerProps> = ({
  datasets,
  onUpdateDatasets,
  selectedDatasetIds,
  onToggleDatasetId,
  onSelectAllDatasets,
  isPersian,
}) => {
  const folderInputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [isLoading, setIsLoading] = useState(false);
  const [loadingProgress, setLoadingProgress] = useState<{
    current: number;
    total: number;
    currentFile: string;
  } | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  // Group datasets by symbol
  const groupedDatasets = React.useMemo(() => {
    const map = new Map<string, MarketDataset[]>();
    for (const d of datasets) {
      const sym = d.symbol || "OTHER";
      if (!map.has(sym)) {
        map.set(sym, []);
      }
      map.get(sym)!.push(d);
    }

    // Sort timeframes within each symbol
    const result: { symbol: string; items: MarketDataset[] }[] = [];
    map.forEach((items, symbol) => {
      items.sort((a, b) => {
        const idxA = TIMEFRAME_ORDER.indexOf(a.timeframe.toUpperCase());
        const idxB = TIMEFRAME_ORDER.indexOf(b.timeframe.toUpperCase());
        return (idxA >= 0 ? idxA : 999) - (idxB >= 0 ? idxB : 999);
      });
      result.push({ symbol, items });
    });

    // Sort symbols alphabetically
    return result.sort((a, b) => a.symbol.localeCompare(b.symbol));
  }, [datasets]);

  // Filtered symbols based on search
  const filteredGroups = groupedDatasets.filter((g) =>
    g.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
    g.items.some((item) => item.name.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  // Handle files parsing (both from folder or multi-file input)
  const processFiles = async (fileList: FileList | File[]) => {
    const files = Array.from(fileList).filter((f) =>
      f.name.endsWith(".csv") || f.name.endsWith(".txt") || f.name.endsWith(".CSV")
    );

    if (files.length === 0) {
      setErrorMessage(
        isPersian
          ? "هیچ فایل داده با پسوند .csv یا .txt در مسیر انتخاب شده یافت نشد."
          : "No .csv or .txt market data files found in selected path."
      );
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    const newDatasets: MarketDataset[] = [];
    const errors: string[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      setLoadingProgress({
        current: i + 1,
        total: files.length,
        currentFile: file.name,
      });

      try {
        const dataset = await readAndParseFile(file);
        newDatasets.push(dataset);
      } catch (err: any) {
        errors.push(`${file.name}: ${err.message || "خطا در خواندن فایل"}`);
      }
    }

    if (newDatasets.length > 0) {
      // Merge with existing datasets without duplicating same symbol + timeframe
      const existingMap = new Map<string, MarketDataset>();
      for (const d of datasets) {
        const key = `${d.symbol.toUpperCase()}_${d.timeframe.toUpperCase()}`;
        existingMap.set(key, d);
      }

      // Add/overwrite with newly parsed datasets
      const newIdsToSelect: string[] = [];
      for (const d of newDatasets) {
        const key = `${d.symbol.toUpperCase()}_${d.timeframe.toUpperCase()}`;
        existingMap.set(key, d);
        newIdsToSelect.push(d.id);
      }

      const mergedList = Array.from(existingMap.values());
      onUpdateDatasets(mergedList);

      // Auto-select all newly added datasets
      const updatedSelection = Array.from(new Set([...selectedDatasetIds, ...newIdsToSelect]));
      // Trigger toggle or select all
      for (const id of newIdsToSelect) {
        if (!selectedDatasetIds.includes(id)) {
          onToggleDatasetId(id);
        }
      }

      setSuccessMessage(
        isPersian
          ? `✅ تعداد ${newDatasets.length} دیتاست با موفقیت از پوشه خوانده و به موتور اضافه شد.`
          : `✅ Successfully loaded ${newDatasets.length} datasets from folder.`
      );
    }

    if (errors.length > 0) {
      setErrorMessage(
        isPersian
          ? `برخی فایل‌ها خوانده نشدند (${errors.length} خطا): ${errors.slice(0, 3).join(" | ")}`
          : `Some files could not be read (${errors.length} errors): ${errors.slice(0, 3).join(" | ")}`
      );
    }

    setIsLoading(false);
    setLoadingProgress(null);
  };

  const handleFolderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFiles(e.target.files);
    }
  };

  const handleFilesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFiles(e.target.files);
    }
  };

  // Toggle all timeframes for a given symbol
  const handleToggleSymbol = (symbol: string) => {
    const group = groupedDatasets.find((g) => g.symbol === symbol);
    if (!group) return;

    const groupIds = group.items.map((item) => item.id);
    const areAllSelected = groupIds.every((id) => selectedDatasetIds.includes(id));

    groupIds.forEach((id) => {
      const isCurrentlySelected = selectedDatasetIds.includes(id);
      if (areAllSelected && isCurrentlySelected) {
        onToggleDatasetId(id);
      } else if (!areAllSelected && !isCurrentlySelected) {
        onToggleDatasetId(id);
      }
    });
  };

  // Delete symbol and all its datasets
  const handleDeleteSymbol = (symbol: string) => {
    const updated = datasets.filter((d) => d.symbol !== symbol);
    onUpdateDatasets(updated);
  };

  // Generate multi-timeframe suite from M1 if available
  const handleGenerateTimeframesFromM1 = (symbol: string) => {
    const group = groupedDatasets.find((g) => g.symbol === symbol);
    if (!group) return;

    const m1Item = group.items.find((item) => item.timeframe.toUpperCase() === "M1");
    if (!m1Item) return;

    const suite = buildMultiTimeframeSuite(symbol, m1Item.candles);
    const existingOtherSymbols = datasets.filter((d) => d.symbol !== symbol);
    onUpdateDatasets([...existingOtherSymbols, ...suite]);

    // Select all generated timeframes
    suite.forEach((d) => {
      if (!selectedDatasetIds.includes(d.id)) {
        onToggleDatasetId(d.id);
      }
    });

    setSuccessMessage(
      isPersian
        ? `تایم‌فریم‌های استاندارد (M5 تا D1) برای نماد ${symbol} از روی کندل‌های M1 تولید شدند.`
        : `Generated M5 to D1 timeframe suite for ${symbol} from M1 candles.`
    );
  };

  // Compute total active candles for search engine
  const activeDatasets = datasets.filter((d) => selectedDatasetIds.includes(d.id));
  const totalActiveCandles = activeDatasets.reduce((acc, d) => acc + d.candles.length, 0);

  return (
    <div id="market-data-manager" className="flex flex-col gap-4">
      {/* 1. Folder & File Selector Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {/* Select Folder of CSVs Button */}
        <div
          onClick={() => folderInputRef.current?.click()}
          className="border-2 border-dashed border-emerald-500/40 hover:border-emerald-400 bg-emerald-950/20 hover:bg-emerald-950/30 rounded-2xl p-4 flex flex-col items-center justify-center gap-2 cursor-pointer transition-all text-center group"
        >
          <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform">
            <FolderOpen className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-emerald-300">
              {isPersian ? "انتخاب فولدر دیتاهای CSV" : "Select Folder with CSV Data"}
            </h4>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {isPersian
                ? "پوشه نمادها را از سیستم خود انتخاب کنید تا همه فایل‌ها خودکار دسته‌بندی شوند"
                : "Choose directory on your PC containing symbol & timeframe CSV files"}
            </p>
          </div>
          <span className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded-lg shadow-sm">
            {isPersian ? "انتخاب مسیر پوشه" : "Browse Folder"}
          </span>
          {/* Webkit directory file input */}
          <input
            ref={folderInputRef}
            type="file"
            multiple
            // @ts-ignore
            webkitdirectory=""
            // @ts-ignore
            directory=""
            onChange={handleFolderChange}
            className="hidden"
          />
        </div>

        {/* Select Individual / Multiple Files */}
        <div
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-cyan-500/40 hover:border-cyan-400 bg-cyan-950/20 hover:bg-cyan-950/30 rounded-2xl p-4 flex flex-col items-center justify-center gap-2 cursor-pointer transition-all text-center group"
        >
          <div className="w-12 h-12 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center group-hover:scale-110 transition-transform">
            <FileSpreadsheet className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-cyan-300">
              {isPersian ? "انتخاب چندین فایل CSV متفرقه" : "Select Multiple CSV Files"}
            </h4>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {isPersian
                ? "انتخاب یک یا چند فایل از متاتریدر، تریدینگ‌ویو یا صرافی‌ها"
                : "Select specific CSV files (MetaTrader 4/5, TradingView, Binance)"}
            </p>
          </div>
          <span className="px-3 py-1 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs rounded-lg shadow-sm">
            {isPersian ? "انتخاب فایل‌ها" : "Browse Files"}
          </span>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept=".csv,.txt"
            onChange={handleFilesChange}
            className="hidden"
          />
        </div>
      </div>

      {/* Loading & Progress indicator */}
      {isLoading && loadingProgress && (
        <div className="p-3 bg-slate-900 border border-cyan-500/40 rounded-xl flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-cyan-300 flex items-center gap-2">
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              {isPersian
                ? `در حال پردازش و استخراج کندل‌ها (${loadingProgress.current} از ${loadingProgress.total})...`
                : `Parsing CSV files (${loadingProgress.current} / ${loadingProgress.total})...`}
            </span>
            <span className="font-mono text-slate-400 truncate max-w-xs">
              {loadingProgress.currentFile}
            </span>
          </div>
          <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-cyan-400 transition-all duration-150"
              style={{
                width: `${Math.round((loadingProgress.current / loadingProgress.total) * 100)}%`,
              }}
            />
          </div>
        </div>
      )}

      {/* Status Messages */}
      {successMessage && (
        <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs rounded-xl flex items-center gap-2">
          <Check className="w-4 h-4 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {errorMessage && (
        <div className="p-2.5 bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs rounded-xl flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* 2. Top Summary & Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-900/90 border border-slate-800 rounded-xl text-xs">
        {/* Active Stats */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 font-bold text-emerald-400">
            <CheckSquare className="w-4 h-4" />
            <span>
              {isPersian
                ? `${activeDatasets.length} دیتاست فعال برای جستجو`
                : `${activeDatasets.length} active datasets for scanning`}
            </span>
          </div>
          <span className="text-slate-600">|</span>
          <span className="text-slate-300 font-mono">
            {totalActiveCandles.toLocaleString()}{" "}
            {isPersian ? "کندل کل" : "total candles"}
          </span>
        </div>

        {/* Global Select/Deselect and Search */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => onSelectAllDatasets(true)}
              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-cyan-400 font-medium text-xs transition-colors border border-slate-700"
            >
              {isPersian ? "✓ انتخاب همه" : "Select All"}
            </button>
            <button
              onClick={() => onSelectAllDatasets(false)}
              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 font-medium text-xs transition-colors border border-slate-700"
            >
              {isPersian ? "✗ لغو همه" : "Deselect All"}
            </button>
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={isPersian ? "فیلتر نمادها..." : "Filter symbols..."}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-slate-950 border border-slate-800 text-slate-200 text-xs rounded-lg pl-8 pr-2.5 py-1 w-32 md:w-40 focus:outline-none focus:border-cyan-500"
            />
          </div>
        </div>
      </div>

      {/* 3. Grouped Datasets View (Symbol Rows + Timeframe Pills) */}
      <div className="flex flex-col gap-2.5 max-h-[340px] overflow-y-auto pr-1">
        {filteredGroups.length > 0 ? (
          filteredGroups.map(({ symbol, items }) => {
            const groupIds = items.map((i) => i.id);
            const selectedCount = groupIds.filter((id) => selectedDatasetIds.includes(id)).length;
            const areAllSelected = selectedCount === items.length;
            const isPartiallySelected = selectedCount > 0 && selectedCount < items.length;
            const totalSymbolCandles = items.reduce((acc, i) => acc + i.candles.length, 0);
            const hasM1 = items.some((i) => i.timeframe.toUpperCase() === "M1");

            return (
              <div
                key={symbol}
                className="bg-[#090d16] border border-slate-800/90 rounded-xl p-3 flex flex-col gap-2.5 hover:border-slate-700/80 transition-all"
              >
                {/* Row Header: Symbol Name, Master Checkbox & Quick Actions */}
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-3">
                    {/* Symbol Master Checkbox */}
                    <button
                      onClick={() => handleToggleSymbol(symbol)}
                      className="flex items-center gap-2 cursor-pointer group"
                      title={isPersian ? "انتخاب / لغو انتخاب همه تایم‌فریم‌های این نماد" : "Toggle all timeframes for this symbol"}
                    >
                      <div
                        className={`w-4 h-4 rounded flex items-center justify-center border transition-colors ${
                          areAllSelected
                            ? "bg-emerald-600 border-emerald-500 text-white"
                            : isPartiallySelected
                            ? "bg-cyan-600/30 border-cyan-500 text-cyan-300"
                            : "bg-slate-900 border-slate-700 group-hover:border-slate-500"
                        }`}
                      >
                        {areAllSelected ? (
                          <Check className="w-3 h-3" />
                        ) : isPartiallySelected ? (
                          <span className="w-2 h-0.5 bg-cyan-400" />
                        ) : null}
                      </div>

                      <span className="font-bold text-sm text-slate-100 font-mono tracking-wide">
                        {symbol}
                      </span>
                    </button>

                    {/* Badge: Active Timeframes */}
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-800 text-slate-300 border border-slate-700">
                      {selectedCount} / {items.length} {isPersian ? "تایم‌فریم" : "TFs"}
                    </span>

                    {/* Total Candles */}
                    <span className="text-[11px] text-slate-500 font-mono">
                      ({totalSymbolCandles.toLocaleString()} candles)
                    </span>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2">
                    {hasM1 && items.length < 5 && (
                      <button
                        onClick={() => handleGenerateTimeframesFromM1(symbol)}
                        className="flex items-center gap-1 text-[11px] text-cyan-400 hover:text-cyan-300 px-2 py-0.5 bg-cyan-950/40 border border-cyan-800/60 rounded-md"
                        title="Auto-resample M5, M15, H1, H4, D1 from base M1"
                      >
                        <Sparkles className="w-3 h-3" />
                        <span>{isPersian ? "+ تولید سایر تایم‌فریم‌ها" : "+ Generate TFs"}</span>
                      </button>
                    )}

                    <button
                      onClick={() => handleDeleteSymbol(symbol)}
                      className="p-1 rounded text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                      title={isPersian ? "حذف این نماد" : "Remove this symbol"}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Row Content: Timeframe Checkbox Chips */}
                <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-900">
                  {items.map((item) => {
                    const isSelected = selectedDatasetIds.includes(item.id);
                    return (
                      <button
                        key={item.id}
                        onClick={() => onToggleDatasetId(item.id)}
                        className={`flex items-center gap-2 px-2.5 py-1 rounded-lg text-xs font-mono transition-all border select-none ${
                          isSelected
                            ? "bg-emerald-950/60 border-emerald-500/60 text-emerald-200 shadow-sm"
                            : "bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200"
                        }`}
                      >
                        <div
                          className={`w-3.5 h-3.5 rounded flex items-center justify-center border ${
                            isSelected
                              ? "bg-emerald-500 border-emerald-400 text-white"
                              : "bg-slate-800 border-slate-700"
                          }`}
                        >
                          {isSelected && <Check className="w-2.5 h-2.5" />}
                        </div>

                        <span className="font-bold">{item.timeframe}</span>
                        <span className="text-[10px] text-slate-500">
                          {item.candles.length}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })
        ) : (
          <div className="p-8 text-center bg-slate-950/40 border border-slate-800 rounded-xl text-slate-400 text-xs">
            {searchQuery
              ? (isPersian ? "هیچ نمادی با این عبارت یافت نشد." : "No symbols matching filter.")
              : (isPersian
                  ? "هیچ داده بازاری وجود ندارد. لطفاً با دکمه بالا یک پوشه یا فایل‌های CSV را انتخاب نمایید."
                  : "No market data loaded yet. Please select a folder or CSV files above.")}
          </div>
        )}
      </div>
    </div>
  );
};
