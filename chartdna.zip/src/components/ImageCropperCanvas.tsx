import React, { useRef, useState, useEffect } from "react";
import { Upload, Crosshair, Check } from "lucide-react";
import { extractPathFromImageData } from "../engine/imageExtractor";
import { LanguageCode, getTranslation } from "../i18n/languages";
import { ThemeId, getTheme } from "../theme/themes";

interface ImageCropperCanvasProps {
  imageSrc: string | null;
  onImageLoaded: (img: HTMLImageElement) => void;
  onPatternExtracted: (pattern: number[]) => void;
  activeLanguage: LanguageCode;
  activeTheme?: ThemeId;
}

interface CropRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export const ImageCropperCanvas: React.FC<ImageCropperCanvasProps> = ({
  imageSrc,
  onImageLoaded,
  onPatternExtracted,
  activeLanguage,
  activeTheme = "cyber-obsidian",
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [imageObj, setImageObj] = useState<HTMLImageElement | null>(null);
  const [crop, setCrop] = useState<CropRect | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number } | null>(null);
  const [extractStatus, setExtractStatus] = useState<string | null>(null);

  const t = (key: string, fallback?: string) => getTranslation(activeLanguage, key, fallback);
  const theme = getTheme(activeTheme);

  // Load image when imageSrc changes
  useEffect(() => {
    if (!imageSrc) {
      setImageObj(null);
      setCrop(null);
      return;
    }

    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      setImageObj(img);
      onImageLoaded(img);
      // Auto-set default crop box around the central 70% of the chart
      const initialCrop: CropRect = {
        x: Math.round(img.width * 0.15),
        y: Math.round(img.height * 0.15),
        width: Math.round(img.width * 0.7),
        height: Math.round(img.height * 0.7),
      };
      setCrop(initialCrop);
      // Auto-extract initial pattern
      setTimeout(() => performExtraction(img, initialCrop), 100);
    };
    img.src = imageSrc;
  }, [imageSrc]);

  // Redraw canvas whenever image or crop changes
  useEffect(() => {
    drawCanvas();
  }, [imageObj, crop]);

  const drawCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas || !imageObj) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set canvas dimensions
    canvas.width = imageObj.width;
    canvas.height = imageObj.height;

    // Draw main image
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(imageObj, 0, 0);

    // If crop box exists, draw semi-transparent overlay + crop borders
    if (crop && crop.width > 0 && crop.height > 0) {
      // Dark overlay outside crop box
      ctx.fillStyle = "rgba(0, 0, 0, 0.55)";
      // Top
      ctx.fillRect(0, 0, canvas.width, crop.y);
      // Bottom
      ctx.fillRect(0, crop.y + crop.height, canvas.width, canvas.height - (crop.y + crop.height));
      // Left
      ctx.fillRect(0, crop.y, crop.x, crop.height);
      // Right
      ctx.fillRect(crop.x + crop.width, crop.y, canvas.width - (crop.x + crop.width), crop.height);

      // Crop border (bright yellow/gold neon)
      ctx.strokeStyle = "#eab308";
      ctx.lineWidth = 2.5;
      ctx.setLineDash([6, 3]);
      ctx.strokeRect(crop.x, crop.y, crop.width, crop.height);

      // Corner handles
      ctx.setLineDash([]);
      ctx.fillStyle = "#facc15";
      const handleSize = 8;
      // Top-left
      ctx.fillRect(crop.x - handleSize / 2, crop.y - handleSize / 2, handleSize, handleSize);
      // Top-right
      ctx.fillRect(crop.x + crop.width - handleSize / 2, crop.y - handleSize / 2, handleSize, handleSize);
      // Bottom-left
      ctx.fillRect(crop.x - handleSize / 2, crop.y + crop.height - handleSize / 2, handleSize, handleSize);
      // Bottom-right
      ctx.fillRect(crop.x + crop.width - handleSize / 2, crop.y + crop.height - handleSize / 2, handleSize, handleSize);

      // Center crosshair
      ctx.strokeStyle = "rgba(250, 204, 21, 0.4)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(crop.x + crop.width / 2, crop.y);
      ctx.lineTo(crop.x + crop.width / 2, crop.y + crop.height);
      ctx.moveTo(crop.x, crop.y + crop.height / 2);
      ctx.lineTo(crop.x + crop.width, crop.y + crop.height / 2);
      ctx.stroke();
    }
  };

  const getCanvasCoords = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!imageObj) return;
    const { x, y } = getCanvasCoords(e);
    setIsDragging(true);
    setDragStart({ x, y });
    setCrop({ x, y, width: 0, height: 0 });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDragging || !dragStart || !imageObj) return;
    const { x, y } = getCanvasCoords(e);

    const x1 = Math.max(0, Math.min(dragStart.x, x));
    const y1 = Math.max(0, Math.min(dragStart.y, y));
    const x2 = Math.min(imageObj.width, Math.max(dragStart.x, x));
    const y2 = Math.min(imageObj.height, Math.max(dragStart.y, y));

    setCrop({
      x: Math.round(x1),
      y: Math.round(y1),
      width: Math.round(x2 - x1),
      height: Math.round(y2 - y1),
    });
  };

  const handleMouseUp = () => {
    if (!isDragging || !crop || !imageObj) return;
    setIsDragging(false);

    if (crop.width > 20 && crop.height > 20) {
      performExtraction(imageObj, crop);
    }
  };

  const performExtraction = (img: HTMLImageElement, cropRect: CropRect) => {
    try {
      setExtractStatus(t("extractFromCrop", "Extracting DNA Curve..."));

      // Create offscreen canvas for cropped slice
      const offCanvas = document.createElement("canvas");
      offCanvas.width = cropRect.width;
      offCanvas.height = cropRect.height;
      const offCtx = offCanvas.getContext("2d");
      if (!offCtx) return;

      offCtx.drawImage(
        img,
        cropRect.x,
        cropRect.y,
        cropRect.width,
        cropRect.height,
        0,
        0,
        cropRect.width,
        cropRect.height
      );

      const croppedImgData = offCtx.getImageData(0, 0, cropRect.width, cropRect.height);

      // Extract curve from cropped image
      const extractedCurve = extractPathFromImageData(croppedImgData);

      if (extractedCurve && extractedCurve.length > 0) {
        onPatternExtracted(extractedCurve);
        setExtractStatus(
          activeLanguage === "fa"
            ? `الگوی DNA استخراج گردید (${extractedCurve.length} نقطه نرمال‌سازی شد)`
            : `DNA Pattern Extracted (${extractedCurve.length} Points Normalized)`
        );
      } else {
        setExtractStatus(
          activeLanguage === "fa"
            ? "الگوی معتبری در کادر انتخاب شده یافت نشد"
            : "No distinct curve detected in crop selection"
        );
      }
      setTimeout(() => setExtractStatus(null), 3000);
    } catch (err) {
      console.error(err);
      setExtractStatus(t("noDataLoaded", "Extraction Error"));
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (ev) => {
      const result = ev.target?.result as string;
      const img = new Image();
      img.onload = () => {
        setImageObj(img);
        onImageLoaded(img);
        const initialCrop: CropRect = {
          x: Math.round(img.width * 0.15),
          y: Math.round(img.height * 0.15),
          width: Math.round(img.width * 0.7),
          height: Math.round(img.height * 0.7),
        };
        setCrop(initialCrop);
        performExtraction(img, initialCrop);
      };
      img.src = result;
    };
    reader.readAsDataURL(file);
  };

  return (
    <div
      id="image-cropper-card"
      className="border rounded-2xl p-4 flex flex-col gap-3 shadow-lg flex-1 h-[400px] overflow-hidden backdrop-blur-xl transition-colors duration-200"
      style={{
        backgroundColor: `${theme.colors.cardBg}f0`,
        borderColor: theme.colors.border,
        color: theme.colors.text,
      }}
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Crosshair className="w-4 h-4" style={{ color: theme.colors.primary }} />
          <h2 className="text-sm font-bold" style={{ color: theme.colors.text }}>
            {t("imageWorkspace", "Chart Image & Crop Selection")}
          </h2>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-2">
          {imageObj && (
            <button
              onClick={() => crop && imageObj && performExtraction(imageObj, crop)}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-lg transition-all duration-150 border backdrop-blur-md cursor-pointer active:scale-[0.98]"
              style={{
                backgroundColor: `${theme.colors.primary}20`,
                borderColor: `${theme.colors.primary}40`,
                color: theme.colors.primary,
              }}
              title="Re-extract pattern from current crop box"
            >
              <Check className="w-3.5 h-3.5" />
              <span>{t("reExtract", "Re-extract")}</span>
            </button>
          )}

          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-lg transition-all duration-150 border backdrop-blur-md cursor-pointer active:scale-[0.98]"
            style={{
              backgroundColor: `${theme.colors.subpanelBg}ee`,
              borderColor: theme.colors.borderSubtle,
              color: theme.colors.text,
            }}
          >
            <Upload className="w-3.5 h-3.5" style={{ color: theme.colors.secondary }} />
            <span>{t("uploadImage", "Upload Image")}</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFileInput}
          />
        </div>
      </div>

      {/* Canvas Area */}
      <div
        ref={containerRef}
        className="relative flex-1 border rounded-xl overflow-hidden flex items-center justify-center min-h-0"
        style={{
          backgroundColor: theme.colors.bg,
          borderColor: theme.colors.borderSubtle,
        }}
      >
        {imageObj ? (
          <div className="w-full h-full flex items-center justify-center p-2 overflow-auto">
            <canvas
              ref={canvasRef}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              className="max-w-full max-h-[380px] object-contain rounded-lg shadow-inner cursor-crosshair select-none"
            />
          </div>
        ) : (
          <div
            onClick={() => fileInputRef.current?.click()}
            className="flex flex-col items-center justify-center gap-3 text-center p-8 cursor-pointer transition-colors w-full h-full"
            style={{ color: theme.colors.textMuted }}
          >
            <div
              className="w-14 h-14 rounded-2xl border flex items-center justify-center"
              style={{
                backgroundColor: theme.colors.subpanelBg,
                borderColor: theme.colors.borderSubtle,
              }}
            >
              <Upload className="w-7 h-7" style={{ color: theme.colors.primary }} />
            </div>
            <div>
              <p className="text-sm font-semibold" style={{ color: theme.colors.text }}>
                {t("dropImageHere", "Drop financial chart screenshot here or click to browse")}
              </p>
              <p className="text-xs mt-1" style={{ color: theme.colors.textMuted }}>
                {t("cropInstruction", "Supports PNG, JPG, WebP — drag to crop the target pattern curve")}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Status bar */}
      {extractStatus && (
        <div
          className="text-xs font-mono px-3 py-1.5 border rounded-lg flex items-center gap-2"
          style={{
            backgroundColor: `${theme.colors.subpanelBg}ee`,
            borderColor: theme.colors.borderSubtle,
            color: theme.colors.primary,
          }}
        >
          <span
            className="w-2 h-2 rounded-full animate-pulse"
            style={{ backgroundColor: theme.colors.primary }}
          />
          <span>{extractStatus}</span>
        </div>
      )}
    </div>
  );
};
