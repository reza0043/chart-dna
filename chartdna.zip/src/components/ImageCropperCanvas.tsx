import React, { useRef, useState, useEffect } from "react";
import { Upload, ZoomIn, ZoomOut, RotateCcw, Crosshair, Check } from "lucide-react";
import { extractPathFromImageData } from "../engine/imageExtractor";

interface ImageCropperCanvasProps {
  imageSrc: string | null;
  onImageLoaded: (img: HTMLImageElement) => void;
  onPatternExtracted: (pattern: number[]) => void;
  isPersian: boolean;
}

interface CropRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export const ImageCropperCanvas: React.FC<ImageCropperCanvasProps> = ({
  imageSrc,
  onImageLoaded,
  onPatternExtracted,
  isPersian,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [imageObj, setImageObj] = useState<HTMLImageElement | null>(null);
  const [crop, setCrop] = useState<CropRect | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number } | null>(null);
  const [zoom, setZoom] = useState(1);
  const [extractStatus, setExtractStatus] = useState<string | null>(null);

  // Load image when imageSrc changes
  useEffect(() => {
    if (!imageSrc) {
      setImageObj(null);
      setCrop(null);
      return;
    }

    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      setImageObj(img);
      onImageLoaded(img);
      // Auto-set default crop box around the central 70% of the chart
      const initialCrop: CropRect = {
        x: Math.round(img.width * 0.15),
        y: Math.round(img.height * 0.15),
        width: Math.round(img.width * 0.7),
        height: Math.round(img.height * 0.7),
      };
      setCrop(initialCrop);
      // Auto-extract initial pattern
      setTimeout(() => performExtraction(img, initialCrop), 100);
    };
    img.src = imageSrc;
  }, [imageSrc]);

  // Redraw canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !imageObj) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = imageObj.width;
    canvas.height = imageObj.height;

    // Draw base image
    ctx.drawImage(imageObj, 0, 0);

    // Draw crop overlay if exists
    if (crop && crop.width > 5 && crop.height > 5) {
      // Darken outside area
      ctx.fillStyle = "rgba(0, 0, 0, 0.55)";
      ctx.fillRect(0, 0, canvas.width, crop.y);
      ctx.fillRect(0, crop.y + crop.height, canvas.width, canvas.height - (crop.y + crop.height));
      ctx.fillRect(0, crop.y, crop.x, crop.height);
      ctx.fillRect(crop.x + crop.width, crop.y, canvas.width - (crop.x + crop.width), crop.height);

      // Crop box border
      ctx.strokeStyle = "#38bdf8";
      ctx.lineWidth = 2.5;
      ctx.setLineDash([6, 4]);
      ctx.strokeRect(crop.x, crop.y, crop.width, crop.height);
      ctx.setLineDash([]);

      // Corner handles
      const handleSize = 8;
      ctx.fillStyle = "#38bdf8";
      ctx.fillRect(crop.x - handleSize / 2, crop.y - handleSize / 2, handleSize, handleSize);
      ctx.fillRect(crop.x + crop.width - handleSize / 2, crop.y - handleSize / 2, handleSize, handleSize);
      ctx.fillRect(crop.x - handleSize / 2, crop.y + crop.height - handleSize / 2, handleSize, handleSize);
      ctx.fillRect(crop.x + crop.width - handleSize / 2, crop.y + crop.height - handleSize / 2, handleSize, handleSize);

      // Label
      ctx.fillStyle = "rgba(15, 23, 42, 0.9)";
      ctx.fillRect(crop.x, crop.y - 24, 120, 20);
      ctx.fillStyle = "#38bdf8";
      ctx.font = "bold 11px sans-serif";
      ctx.fillText(`Crop: ${Math.round(crop.width)}x${Math.round(crop.height)}`, crop.x + 6, crop.y - 10);
    }
  }, [imageObj, crop]);

  const performExtraction = (img: HTMLImageElement, cropArea: CropRect) => {
    try {
      const offscreen = document.createElement("canvas");
      offscreen.width = cropArea.width;
      offscreen.height = cropArea.height;
      const offCtx = offscreen.getContext("2d");
      if (!offCtx) return;

      offCtx.drawImage(
        img,
        cropArea.x,
        cropArea.y,
        cropArea.width,
        cropArea.height,
        0,
        0,
        cropArea.width,
        cropArea.height
      );

      const imgData = offCtx.getImageData(0, 0, cropArea.width, cropArea.height);
      const pattern = extractPathFromImageData(imgData);

      if (pattern && pattern.length >= 10) {
        onPatternExtracted(pattern);
        setExtractStatus(
          isPersian
            ? `الگوی مرجع با موفقیت استخراج شد (${pattern.length} نقطه نرمالایز شده)`
            : `Reference pattern successfully extracted (${pattern.length} normalized points)`
        );
      } else {
        setExtractStatus(
          isPersian
            ? "مسیر پیوسته‌ای یافت نشد. لطفاً کادر را دقیق‌تر روی خطوط نمودار تنظیم کنید."
            : "No continuous trend line detected. Adjust crop to encompass the chart candles."
        );
      }
    } catch (e: any) {
      console.error(e);
      setExtractStatus(e.message);
    }
  };

  const getCanvasCoords = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!imageObj) return;
    const coords = getCanvasCoords(e);
    setDragStart(coords);
    setIsDragging(true);
    setCrop({
      x: coords.x,
      y: coords.y,
      width: 0,
      height: 0,
    });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDragging || !dragStart || !imageObj) return;
    const coords = getCanvasCoords(e);

    const x = Math.min(dragStart.x, coords.x);
    const y = Math.min(dragStart.y, coords.y);
    const width = Math.abs(coords.x - dragStart.x);
    const height = Math.abs(coords.y - dragStart.y);

    setCrop({
      x: Math.max(0, Math.min(imageObj.width - 1, x)),
      y: Math.max(0, Math.min(imageObj.height - 1, y)),
      width: Math.min(imageObj.width - x, width),
      height: Math.min(imageObj.height - y, height),
    });
  };

  const handleMouseUp = () => {
    if (!isDragging || !crop || !imageObj) return;
    setIsDragging(false);
    if (crop.width > 15 && crop.height > 15) {
      performExtraction(imageObj, crop);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      const img = new Image();
      img.onload = () => {
        setImageObj(img);
        onImageLoaded(img);
        const initialCrop: CropRect = {
          x: Math.round(img.width * 0.15),
          y: Math.round(img.height * 0.15),
          width: Math.round(img.width * 0.7),
          height: Math.round(img.height * 0.7),
        };
        setCrop(initialCrop);
        performExtraction(img, initialCrop);
      };
      img.src = result;
    };
    reader.readAsDataURL(file);
  };

  return (
    <div
      id="image-cropper-card"
      className="bg-[#0f172a] border border-slate-800 rounded-2xl p-4 flex flex-col gap-3 shadow-lg flex-1 h-[400px] overflow-hidden"
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Crosshair className="w-4 h-4 text-cyan-400" />
          <h2 className="text-sm font-bold text-slate-100">
            {isPersian ? "تصویر نمودار و محدوده کراپ (Crop)" : "Chart Image & Crop Selection"}
          </h2>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-2">
          {imageObj && (
            <button
              onClick={() => crop && imageObj && performExtraction(imageObj, crop)}
              className="flex items-center gap-1 px-2.5 py-1 bg-cyan-500/15 hover:bg-cyan-500/25 active:bg-cyan-500/10 text-cyan-300 text-xs font-semibold rounded-lg transition-all duration-150 border border-cyan-400/30 backdrop-blur-md cursor-pointer active:scale-[0.98]"
              title="Re-extract pattern from current crop box"
            >
              <Check className="w-3.5 h-3.5" />
              <span>{isPersian ? "استخراج مجدد" : "Re-extract"}</span>
            </button>
          )}

          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-1 bg-white/[0.06] hover:bg-white/[0.1] active:bg-white/[0.04] text-slate-200 hover:text-white text-xs font-medium rounded-lg transition-all duration-150 border border-white/[0.12] hover:border-emerald-500/40 backdrop-blur-md cursor-pointer active:scale-[0.98]"
          >
            <Upload className="w-3.5 h-3.5 text-emerald-400" />
            <span>{isPersian ? "آپلود تصویر" : "Upload Image"}</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFileInput}
          />
        </div>
      </div>

      {/* Canvas Area */}
      <div
        ref={containerRef}
        className="relative flex-1 bg-[#090d16] border border-slate-800/80 rounded-xl overflow-hidden flex items-center justify-center min-h-0"
      >
        {imageObj ? (
          <div className="w-full h-full flex items-center justify-center p-2 overflow-auto">
            <canvas
              ref={canvasRef}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              className="max-w-full max-h-[380px] object-contain rounded-lg shadow-inner cursor-crosshair select-none"
            />
          </div>
        ) : (
          <div
            onClick={() => fileInputRef.current?.click()}
            className="flex flex-col items-center justify-center gap-3 text-center p-8 cursor-pointer hover:bg-slate-900/50 transition-colors w-full h-full"
          >
            <div className="w-14 h-14 rounded-2xl bg-slate-800/80 border border-slate-700 flex items-center justify-center text-slate-400">
              <Upload className="w-7 h-7 text-cyan-400" />
            </div>
            <div>
              <p className="text-sm font-semibold text-slate-200">
                {isPersian
                  ? "تصویر نمودار چارت را اینجا رها کنید یا کلیک نمایید"
                  : "Drop financial chart screenshot here or click to browse"}
              </p>
              <p className="text-xs text-slate-400 mt-1">
                {isPersian
                  ? "پشتیبانی از فرمت‌های PNG، JPG، WebP — سپس با موس کادر الگو را رسم کنید"
                  : "Supports PNG, JPG, WebP — drag to crop the target pattern curve"}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Status bar */}
      {extractStatus && (
        <div className="text-xs font-mono px-3 py-1.5 bg-slate-900/90 border border-slate-800/80 rounded-lg text-cyan-300 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
          <span>{extractStatus}</span>
        </div>
      )}
    </div>
  );
};
