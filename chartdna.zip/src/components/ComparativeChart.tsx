import React, { useRef, useEffect } from "react";
import { LineChart, Activity, Info, Eye } from "lucide-react";
import { MatchResult } from "../engine/types";
import { normalizeShape, resampleSeries } from "../engine/normalizer";

interface ComparativeChartProps {
  referencePattern: number[] | null;
  selectedMatch: MatchResult | null;
  onOpenCandleChart?: (match: MatchResult) => void;
  isPersian: boolean;
}

export const ComparativeChart: React.FC<ComparativeChartProps> = ({
  referencePattern,
  selectedMatch,
  onOpenCandleChart,
  isPersian,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const drawChart = () => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Handle high DPI and container sizing stably
    const dpr = window.devicePixelRatio || 1;
    const width = container.clientWidth || 300;
    const height = container.clientHeight || 240;

    canvas.width = width * dpr;
    canvas.height = height * dpr;

    ctx.resetTransform?.();
    ctx.scale(dpr, dpr);

    // Clear background
    ctx.fillStyle = "#090d16";
    ctx.fillRect(0, 0, width, height);

    // Padding for axes
    const padLeft = 45;
    const padRight = 35;
    const padTop = 35;
    const padBottom = 35;
    const plotWidth = width - padLeft - padRight;
    const plotHeight = height - padTop - padBottom;

    if (!referencePattern || referencePattern.length === 0) {
      // Empty placeholder state
      ctx.fillStyle = "#64748b";
      ctx.font = "13px sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(
        isPersian ? "هنوز الگویی استخراج یا انتخاب نشده است" : "No reference pattern extracted or selected yet",
        width / 2,
        height / 2
      );
      return;
    }

    // Grid lines
    ctx.strokeStyle = "rgba(255, 255, 255, 0.05)";
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = padTop + (plotHeight / 4) * i;
      ctx.beginPath();
      ctx.moveTo(padLeft, y);
      ctx.lineTo(width - padRight, y);
      ctx.stroke();
    }
    for (let i = 0; i <= 6; i++) {
      const x = padLeft + (plotWidth / 6) * i;
      ctx.beginPath();
      ctx.moveTo(x, padTop);
      ctx.lineTo(x, height - padBottom);
      ctx.stroke();
    }

    // Normalize reference (500 points)
    const normLen = 500;
    const normRef = normalizeShape(resampleSeries(referencePattern, normLen));

    // Determine bounds
    let normMatch: number[] = [];
    let normFuture: number[] = [];

    if (selectedMatch) {
      normMatch = normalizeShape(resampleSeries(selectedMatch.pattern, normLen));

      if (selectedMatch.future && selectedMatch.future.length > 0) {
        // Future points normalized relative to pattern's price scale and end point
        const pFirst = selectedMatch.pattern[0];
        const pRange = Math.max(...selectedMatch.pattern) - Math.min(...selectedMatch.pattern) || 1;
        const normRefRange = Math.max(...normMatch) - Math.min(...normMatch) || 1;

        normFuture = selectedMatch.future.map((f) => {
          const delta = (f - pFirst) / pRange;
          return normMatch[0] + delta * normRefRange;
        });
      }
    }

    // Total points along X axis
    const totalXPoints = normLen + (normFuture.length > 0 ? normFuture.length : 0);

    // Coordinate mapping functions
    const mapX = (idx: number) => padLeft + (idx / Math.max(1, totalXPoints - 1)) * plotWidth;

    // Gather all Y values for min/max scaling
    const allY = [...normRef, ...normMatch, ...normFuture];
    const minY = Math.min(...allY, -1.1);
    const maxY = Math.max(...allY, 1.1);
    const ySpan = maxY - minY || 1;

    const mapY = (val: number) => padTop + plotHeight - ((val - minY) / ySpan) * plotHeight;

    // Vertical transition line between pattern and future
    if (normFuture.length > 0) {
      const splitX = mapX(normLen - 1);
      ctx.strokeStyle = "rgba(148, 163, 184, 0.4)";
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(splitX, padTop);
      ctx.lineTo(splitX, height - padBottom);
      ctx.stroke();
      ctx.setLineDash([]);

      // Label on top
      ctx.fillStyle = "#94a3b8";
      ctx.font = "10px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(isPersian ? "پایان الگو / شروع آینده" : "Pattern End | Future", splitX, padTop - 8);
    }

    // 1. Draw Reference Pattern (Blue / Cyan Glow)
    ctx.strokeStyle = "#38bdf8";
    ctx.lineWidth = 2.8;
    ctx.beginPath();
    for (let i = 0; i < normRef.length; i++) {
      const x = mapX(i);
      const y = mapY(normRef[i]);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // 2. Draw Found Pattern in Market Data (Orange/Amber)
    if (normMatch.length > 0) {
      ctx.strokeStyle = "#f97316";
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      for (let i = 0; i < normMatch.length; i++) {
        const x = mapX(i);
        const y = mapY(normMatch[i]);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }

    // 3. Draw Future Movement (Emerald Green with dots)
    if (normFuture.length > 0) {
      ctx.strokeStyle = "#10b981";
      ctx.lineWidth = 2.5;
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      const startX = mapX(normLen - 1);
      const startY = normMatch.length > 0 ? mapY(normMatch[normMatch.length - 1]) : mapY(normRef[normRef.length - 1]);
      ctx.moveTo(startX, startY);

      for (let i = 0; i < normFuture.length; i++) {
        const x = mapX(normLen + i);
        const y = mapY(normFuture[i]);
        ctx.lineTo(x, y);
      }
      ctx.stroke();
      ctx.setLineDash([]);

      // Draw dot markers on future candles
      ctx.fillStyle = "#10b981";
      for (let i = 0; i < normFuture.length; i++) {
        const x = mapX(normLen + i);
        const y = mapY(normFuture[i]);
        ctx.beginPath();
        ctx.arc(x, y, 3, 0, 2 * Math.PI);
        ctx.fill();
      }
    }

    // Bottom Time Axis labels
    ctx.fillStyle = "#64748b";
    ctx.font = "10px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("0", mapX(0), height - 12);
    ctx.fillText("250", mapX(Math.floor(normLen / 2)), height - 12);
    ctx.fillText(`500 (${isPersian ? "الگو" : "Pattern"})`, mapX(normLen - 1), height - 12);
    if (normFuture.length > 0) {
      ctx.fillText(`+${normFuture.length} ${isPersian ? "کندل" : "candles"}`, mapX(totalXPoints - 1), height - 12);
    }
  };

  useEffect(() => {
    drawChart();

    const container = containerRef.current;
    if (!container) return;

    let resizeObserver: ResizeObserver | null = null;
    if (typeof ResizeObserver !== "undefined") {
      resizeObserver = new ResizeObserver(() => {
        drawChart();
      });
      resizeObserver.observe(container);
    }

    const handleWindowResize = () => drawChart();
    window.addEventListener("resize", handleWindowResize);

    return () => {
      if (resizeObserver && container) {
        resizeObserver.unobserve(container);
      }
      window.removeEventListener("resize", handleWindowResize);
    };
  }, [referencePattern, selectedMatch, isPersian]);

  return (
    <div
      id="comparative-chart-card"
      className="bg-[#0f172a] border border-slate-800 rounded-2xl p-4 flex flex-col gap-3 shadow-lg flex-1 h-[400px] overflow-hidden"
    >
      {/* Header with Title and Legend */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <LineChart className="w-4 h-4 text-emerald-400" />
          <h2 className="text-sm font-bold text-slate-100">
            {isPersian ? "مسیر الگو و مقایسه نتیجه انتخابی" : "Pattern Overlay & Projected Forward Path"}
          </h2>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center gap-3 text-xs">
          {referencePattern && referencePattern.length > 0 && (
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-1 bg-[#38bdf8] rounded-full" />
              <span className="text-slate-300">{isPersian ? "الگوی مرجع" : "Reference DNA"}</span>
            </div>
          )}

          {selectedMatch && (
            <>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-1 bg-[#f97316] rounded-full" />
                <span className="text-slate-300">{isPersian ? "الگوی کشف شده" : "Matched History"}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-1 bg-[#10b981] rounded-full" />
                <span className="text-slate-300">
                  {isPersian
                    ? `آینده (${selectedMatch.future.length} کندل)`
                    : `Forward Future (+${selectedMatch.future.length})`}
                </span>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Selected Match Info Bar */}
      {selectedMatch && (
        <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-1.5 bg-slate-900/90 border border-slate-800 rounded-xl text-xs">
          <div className="flex items-center gap-2">
            <span className="font-bold text-emerald-400 font-mono">
              #{selectedMatch.rank} • {selectedMatch.similarity.toFixed(2)}%
            </span>
            <span className="text-slate-500">|</span>
            <span className="text-slate-300 font-medium">
              {selectedMatch.symbol} ({selectedMatch.timeframe})
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-3 text-slate-400 text-[11px]">
            <span>{isPersian ? "شروع:" : "Start:"} <span className="text-slate-200 font-mono">{selectedMatch.startTime}</span></span>
            <span className="text-slate-600">•</span>
            <span>{isPersian ? "پایان:" : "End:"} <span className="text-slate-200 font-mono">{selectedMatch.endTime}</span></span>
            <span className="text-slate-600">•</span>
            <span
              className={`px-2 py-0.5 rounded-md font-bold text-[10px] ${
                selectedMatch.trend === "up"
                  ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                  : selectedMatch.trend === "down"
                  ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                  : "bg-slate-700/50 text-slate-300 border border-slate-600"
              }`}
            >
              {selectedMatch.trend === "up" ? (isPersian ? "صعودی ▲" : "BULLISH ▲") : selectedMatch.trend === "down" ? (isPersian ? "نزولی ▼" : "BEARISH ▼") : (isPersian ? "رنج ▬" : "RANGE ▬")}
            </span>
            {onOpenCandleChart && (
              <button
                onClick={() => onOpenCandleChart(selectedMatch)}
                className="flex items-center gap-1 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold text-[11px] transition-all shadow-sm cursor-pointer ml-1"
                title={isPersian ? "باز کردن چارت کندل‌های ژاپنی و آینده" : "Open Candlestick Chart"}
              >
                <Eye className="w-3 h-3" />
                <span>{isPersian ? "مشاهده چارت کندلی" : "View Candles"}</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Canvas */}
      <div ref={containerRef} className="flex-1 bg-[#090d16] border border-slate-800/80 rounded-xl overflow-hidden min-h-0 relative">
        <canvas ref={canvasRef} className="w-full h-full block" />
      </div>
    </div>
  );
};
