/**
 * Normalization & Resampling utilities for Chart DNA pattern matching.
 * Ported from engine_core/normalizer.py
 */

export function normalizeShape(series: number[]): number[] {
  if (!series || series.length === 0) return [];
  const min = Math.min(...series);
  const max = Math.max(...series);

  if (max === min) {
    return series.map(() => 0);
  }

  // Normalize to [-1, 1] range: 2 * (x - min) / (max - min) - 1
  return series.map((x) => 2 * ((x - min) / (max - min)) - 1);
}

export function zscoreNormalize(series: number[]): number[] {
  if (!series || series.length === 0) return [];
  const n = series.length;
  const mean = series.reduce((acc, v) => acc + v, 0) / n;
  const variance = series.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / n;
  const std = Math.sqrt(variance);

  if (std < 1e-8) {
    return series.map(() => 0);
  }

  return series.map((x) => (x - mean) / std);
}

export function resampleSeries(series: number[], targetLength: number): number[] {
  if (!series || series.length === 0 || targetLength <= 0) return [];
  if (series.length === targetLength) return [...series];
  if (series.length === 1) return Array(targetLength).fill(series[0]);

  const originalLength = series.length;
  const resampled: number[] = new Array(targetLength);

  for (let i = 0; i < targetLength; i++) {
    const originalPos = (i / (targetLength - 1)) * (originalLength - 1);
    const leftIndex = Math.floor(originalPos);
    const rightIndex = Math.min(leftIndex + 1, originalLength - 1);
    const weight = originalPos - leftIndex;

    resampled[i] = (1 - weight) * series[leftIndex] + weight * series[rightIndex];
  }

  return resampled;
}

export function smoothMovingAverage(series: number[], windowSize: number = 3): number[] {
  if (!series || series.length <= windowSize) return series;
  const halfWindow = Math.floor(windowSize / 2);
  const result: number[] = [];

  for (let i = 0; i < series.length; i++) {
    let sum = 0;
    let count = 0;
    for (let j = -halfWindow; j <= halfWindow; j++) {
      const idx = i + j;
      if (idx >= 0 && idx < series.length) {
        sum += series[idx];
        count++;
      }
    }
    result.push(sum / count);
  }

  return result;
}
