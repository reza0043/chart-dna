import { normalizeShape, resampleSeries } from "./normalizer";
import { combinedSimilarity } from "./similarity";
import { MarketDataset, MatchResult, SearchConfig, TrendBreakdown } from "./types";

export class PatternMatcher {
  /**
   * Scans a single market dataset for pattern matches using sliding window.
   */
  public static findMatchesInDataset(
    referencePattern: number[],
    dataset: MarketDataset,
    config: SearchConfig,
    onProgress?: (progressPercent: number, statusText: string) => void,
    shouldStop?: () => boolean
  ): MatchResult[] {
    const { threshold, futureCandles, patternLength, skipOverlap, weights, rangeLookback } = config;
    const candles = dataset.candles;
    const requiredLength = patternLength + futureCandles;

    if (candles.length < requiredLength || referencePattern.length < 5) {
      return [];
    }

    // Resample reference pattern to the search pattern length and normalize
    const resampledRef = resampleSeries(referencePattern, patternLength);
    const normalizedRef = normalizeShape(resampledRef);

    const closePrices = candles.map((c) => c.close);
    const maxStart = candles.length - requiredLength;
    const matches: MatchResult[] = [];

    // Scan step (optimized for long series)
    const scanStep = 1;
    let lastMatchedEnd = -1;

    const progressEvery = Math.max(10, Math.floor(maxStart / 20));

    for (let i = 0; i <= maxStart; i += scanStep) {
      if (shouldStop && shouldStop()) {
        break;
      }

      if (i % progressEvery === 0 && onProgress) {
        const percent = Math.min(100, Math.round((i / maxStart) * 100));
        onProgress(percent, `Scanning ${dataset.name} (${i}/${maxStart} windows)`);
      }

      // Skip overlapping windows if match was already found nearby
      if (skipOverlap && i < lastMatchedEnd) {
        continue;
      }

      const windowSlice = closePrices.slice(i, i + patternLength);
      const normalizedWindow = normalizeShape(windowSlice);

      const simScore = combinedSimilarity(normalizedRef, normalizedWindow, weights);
      const simPercent = simScore * 100;

      if (simPercent >= threshold) {
        const endIndex = i + patternLength - 1;
        const futureSlice = closePrices.slice(i + patternLength, i + requiredLength);
        const trend = this.classifyTrend(windowSlice, futureSlice, rangeLookback);

        matches.push({
          rank: 0, // Assigned later
          datasetId: dataset.id,
          fileName: dataset.name,
          symbol: dataset.symbol || dataset.name,
          timeframe: dataset.timeframe || "M1",
          startIndex: i,
          endIndex: endIndex,
          startTime: candles[i]?.timestamp || String(i),
          endTime: candles[endIndex]?.timestamp || String(endIndex),
          similarity: simPercent,
          pattern: windowSlice,
          future: futureSlice,
          trend: trend,
          rawMatchIndices: { start: i, end: endIndex },
        });

        if (skipOverlap) {
          lastMatchedEnd = i + Math.floor(patternLength * 0.5);
        }
      }
    }

    return matches;
  }

  /**
   * Scans multiple datasets, sorts and ranks top matches.
   */
  public static async analyzeMultiDatasets(
    referencePattern: number[],
    datasets: MarketDataset[],
    config: SearchConfig,
    onProgress?: (progressPercent: number, message: string) => void,
    shouldStop?: () => boolean
  ): Promise<MatchResult[]> {
    if (datasets.length === 0) return [];

    let allMatches: MatchResult[] = [];
    const totalDatasets = datasets.length;

    for (let idx = 0; idx < totalDatasets; idx++) {
      if (shouldStop && shouldStop()) break;

      const dataset = datasets[idx];
      const startPct = (idx / totalDatasets) * 100;
      const endPct = ((idx + 1) / totalDatasets) * 100;

      const datasetMatches = this.findMatchesInDataset(
        referencePattern,
        dataset,
        config,
        (innerPct, status) => {
          if (onProgress) {
            const overallPct = startPct + ((endPct - startPct) * innerPct) / 100;
            onProgress(Math.min(99, Math.round(overallPct)), status);
          }
        },
        shouldStop
      );

      allMatches = allMatches.concat(datasetMatches);

      // Yield control briefly to keep UI responsive
      await new Promise((r) => setTimeout(r, 0));
    }

    // Sort descending by similarity
    allMatches.sort((a, b) => b.similarity - a.similarity);

    // Limit to top results and assign ranks
    const topMatches = allMatches.slice(0, config.topResults);
    topMatches.forEach((m, i) => {
      m.rank = i + 1;
    });

    if (onProgress) {
      onProgress(100, `Analysis complete. Found ${topMatches.length} pattern matches.`);
    }

    return topMatches;
  }

  /**
   * Classifies post-pattern trend (Up / Down / Range)
   * based on range lookback at the end of the future window.
   */
  public static classifyTrend(
    pattern: number[],
    future: number[],
    rangeLookback: number = 5
  ): "up" | "down" | "range" {
    if (!pattern.length || !future.length) return "range";

    const lastPatternPrice = pattern[pattern.length - 1];
    const lookback = Math.max(1, rangeLookback);
    const lookbackWindow =
      future.length >= lookback ? future.slice(future.length - lookback) : future;

    const rangeHigh = Math.max(...lookbackWindow);
    const rangeLow = Math.min(...lookbackWindow);

    if (lastPatternPrice >= rangeLow && lastPatternPrice <= rangeHigh) {
      return "range";
    }

    return lastPatternPrice < rangeLow ? "up" : "down";
  }

  /**
   * Computes percentage breakdown of Bullish, Bearish, and Range results.
   */
  public static computeTrendBreakdown(results: MatchResult[]): TrendBreakdown {
    let up = 0;
    let down = 0;
    let range = 0;

    for (const r of results) {
      if (r.trend === "up") up++;
      else if (r.trend === "down") down++;
      else range++;
    }

    const total = results.length;
    if (total === 0) {
      return {
        pctUp: 0,
        pctDown: 0,
        pctRange: 0,
        countUp: 0,
        countDown: 0,
        countRange: 0,
        total: 0,
      };
    }

    return {
      pctUp: (up / total) * 100,
      pctDown: (down / total) * 100,
      pctRange: (range / total) * 100,
      countUp: up,
      countDown: down,
      countRange: range,
      total: total,
    };
  }
}
