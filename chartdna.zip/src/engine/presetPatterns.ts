import { normalizeShape, resampleSeries } from "./normalizer";
import { MyDNAPattern } from "./types";

export interface PatternPreset {
  id: string;
  name: string;
  nameFa: string;
  category: "Reversal" | "Continuation" | "Harmonic" | "Custom";
  description: string;
  points: number[];
}

export const PRESET_PATTERNS: PatternPreset[] = [
  {
    id: "head_and_shoulders",
    name: "Head & Shoulders",
    nameFa: "سر و شانه سقف",
    category: "Reversal",
    description: "Classic bearish reversal: Left shoulder, higher head, right shoulder, then breakdown.",
    points: [
      0.0, 0.4, 0.7, 0.4, 0.2, 0.5, 0.9, 1.0, 0.9, 0.4, 0.2, 0.4, 0.68, 0.4, 0.1, -0.2
    ],
  },
  {
    id: "inv_head_and_shoulders",
    name: "Inverted Head & Shoulders",
    nameFa: "سر و شانه معکوس (کف)",
    category: "Reversal",
    description: "Classic bullish reversal: Left trough, lower head, right trough, then breakout.",
    points: [
      0.0, -0.4, -0.7, -0.4, -0.2, -0.5, -0.9, -1.0, -0.9, -0.4, -0.2, -0.4, -0.68, -0.4, -0.1, 0.2
    ],
  },
  {
    id: "double_top",
    name: "Double Top (M-Pattern)",
    nameFa: "سقف دوقلو (الگوی M)",
    category: "Reversal",
    description: "Two distinct peaks at approximately the same level with a neckline trough between them.",
    points: [
      -0.5, 0.0, 0.6, 0.95, 0.6, 0.1, -0.1, 0.2, 0.65, 0.95, 0.6, 0.0, -0.4, -0.8
    ],
  },
  {
    id: "double_bottom",
    name: "Double Bottom (W-Pattern)",
    nameFa: "کف دوقلو (الگوی W)",
    category: "Reversal",
    description: "Two distinct troughs at approximately the same level with a central peak between them.",
    points: [
      0.5, 0.0, -0.6, -0.95, -0.6, -0.1, 0.1, -0.2, -0.65, -0.95, -0.6, 0.0, 0.4, 0.8
    ],
  },
  {
    id: "bull_flag",
    name: "Bull Flag & Pole",
    nameFa: "پرچم صعودی (Bull Flag)",
    category: "Continuation",
    description: "Sharp upward pole followed by a tight downward sloping consolidation channel.",
    points: [
      -0.9, -0.5, 0.0, 0.6, 0.95, 1.0, 0.85, 0.7, 0.8, 0.65, 0.75, 0.6, 0.7, 0.55, 0.68
    ],
  },
  {
    id: "cup_and_handle",
    name: "Cup & Handle",
    nameFa: "کاپ و دسته (Cup & Handle)",
    category: "Continuation",
    description: "U-shaped rounded bottom recovery followed by a slight downward drift handle.",
    points: [
      0.8, 0.4, 0.0, -0.4, -0.7, -0.85, -0.85, -0.7, -0.4, 0.0, 0.4, 0.78, 0.65, 0.58, 0.68
    ],
  },
  {
    id: "ascending_triangle",
    name: "Ascending Triangle",
    nameFa: "مثلث افزایشی",
    category: "Continuation",
    description: "Horizontal upper resistance ceiling with rising higher lows.",
    points: [
      -0.8, -0.2, 0.6, 0.9, 0.2, -0.3, 0.4, 0.9, 0.0, 0.5, 0.9, 0.3, 0.7, 0.9
    ],
  },
  {
    id: "falling_wedge",
    name: "Falling Wedge",
    nameFa: "کنج نزولی (Falling Wedge)",
    category: "Reversal",
    description: "Downward sloping converging trendlines with diminishing volatility.",
    points: [
      0.9, 0.2, -0.4, 0.3, -0.2, -0.6, -0.1, -0.45, -0.75, -0.4, -0.6, -0.8, -0.55
    ],
  },
];

export function convertPresetToMyDNA(preset: PatternPreset): MyDNAPattern {
  const norm = normalizeShape(resampleSeries(preset.points, 80));
  return {
    id: preset.id,
    name: preset.name,
    category: preset.category,
    createdAt: new Date().toISOString().split("T")[0],
    points: preset.points,
    normalizedPoints: norm,
    notes: preset.description,
  };
}
