import { Candle, MarketDataset } from "./types";

export const TIMEFRAME_MINUTES: Record<string, number> = {
  M1: 1,
  M5: 5,
  M15: 15,
  M30: 30,
  H1: 60,
  H4: 240,
  D1: 1440,
};

/**
 * Builds aggregated timeframe candles (e.g. M5, M15, H1, D1) from base M1 candles.
 */
export function resampleCandles(
  baseCandles: Candle[],
  targetMinutes: number
): Candle[] {
  if (!baseCandles || baseCandles.length === 0) return [];
  if (targetMinutes <= 1) return [...baseCandles];

  const aggregated: Candle[] = [];

  for (let i = 0; i < baseCandles.length; i += targetMinutes) {
    const chunk = baseCandles.slice(i, i + targetMinutes);
    if (chunk.length === 0) continue;

    const open = chunk[0].open;
    const close = chunk[chunk.length - 1].close;
    let high = -Infinity;
    let low = Infinity;
    let volume = 0;

    for (const c of chunk) {
      if (c.high > high) high = c.high;
      if (c.low < low) low = c.low;
      if (c.volume) volume += c.volume;
    }

    aggregated.push({
      timestamp: chunk[0].timestamp,
      open,
      high,
      low,
      close,
      volume: volume || undefined,
    });
  }

  return aggregated;
}

/**
 * Generates full multi-timeframe dataset suite from single M1 dataset
 */
export function buildMultiTimeframeSuite(
  symbol: string,
  m1Candles: Candle[]
): MarketDataset[] {
  const timeframes = ["M1", "M5", "M15", "M30", "H1", "H4", "D1"];
  const datasets: MarketDataset[] = [];

  for (const tf of timeframes) {
    const minutes = TIMEFRAME_MINUTES[tf] || 1;
    const candles = minutes === 1 ? m1Candles : resampleCandles(m1Candles, minutes);

    datasets.push({
      id: `${symbol.toLowerCase()}_${tf.toLowerCase()}`,
      name: `${symbol} - ${tf}`,
      symbol: symbol,
      timeframe: tf,
      candles: candles,
    });
  }

  return datasets;
}

/**
 * Parses generic CSV text (supports standard MetaTrader, TradingView, Binance CSV exports)
 */
export function parseMarketCSV(
  csvContent: string,
  symbolName: string = "CUSTOM"
): MarketDataset {
  const lines = csvContent
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  if (lines.length < 2) {
    throw new Error("CSV file does not contain enough data rows.");
  }

  // Detect delimiter (, or ; or \t)
  const headerLine = lines[0];
  const delimiter = headerLine.includes("\t")
    ? "\t"
    : headerLine.includes(";")
    ? ";"
    : ",";

  const headers = headerLine
    .toLowerCase()
    .split(delimiter)
    .map((h) => h.replace(/["']/g, "").trim());

  // Find column indices
  let timeIdx = headers.findIndex((h) =>
    h.includes("time") || h.includes("date") || h.includes("datetime")
  );
  let openIdx = headers.findIndex((h) => h === "open" || h.includes("open"));
  let highIdx = headers.findIndex((h) => h === "high" || h.includes("high"));
  let lowIdx = headers.findIndex((h) => h === "low" || h.includes("low"));
  let closeIdx = headers.findIndex((h) => h === "close" || h.includes("close"));
  let volIdx = headers.findIndex((h) => h.includes("vol") || h.includes("volume"));

  // Fallback for headerless standard format (Date, Time, Open, High, Low, Close, Volume)
  if (openIdx === -1 || closeIdx === -1) {
    // Try MT4/MT5 standard: Date, Time, Open, High, Low, Close
    openIdx = 2;
    highIdx = 3;
    lowIdx = 4;
    closeIdx = 5;
    timeIdx = 0;
  }

  const candles: Candle[] = [];

  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(delimiter).map((c) => c.replace(/["']/g, "").trim());
    if (cols.length < 4) continue;

    const open = parseFloat(cols[openIdx]);
    const high = parseFloat(cols[highIdx >= 0 ? highIdx : openIdx]);
    const low = parseFloat(cols[lowIdx >= 0 ? lowIdx : openIdx]);
    const close = parseFloat(cols[closeIdx]);
    const volume = volIdx >= 0 ? parseFloat(cols[volIdx]) : undefined;
    const timestamp = timeIdx >= 0 ? cols[timeIdx] : `Candle ${i}`;

    if (!isNaN(open) && !isNaN(close)) {
      candles.push({
        timestamp,
        open,
        high: isNaN(high) ? Math.max(open, close) : high,
        low: isNaN(low) ? Math.min(open, close) : low,
        close,
        volume: !isNaN(volume!) ? volume : undefined,
      });
    }
  }

  if (candles.length === 0) {
    throw new Error("Could not parse valid OHLC candle rows from CSV.");
  }

  return {
    id: `custom_${Date.now()}`,
    name: symbolName,
    symbol: symbolName,
    timeframe: "M1",
    candles,
  };
}
