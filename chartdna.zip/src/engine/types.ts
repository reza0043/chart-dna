export interface Candle {
  timestamp: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

export interface MarketDataset {
  id: string;
  name: string;
  symbol: string;
  timeframe: string;
  candles: Candle[];
}

export interface MatchResult {
  rank: number;
  datasetId?: string;
  fileName: string;
  symbol: string;
  timeframe: string;
  startIndex: number;
  endIndex: number;
  startTime: string;
  endTime: string;
  similarity: number; // 0 to 100 percentage
  pattern: number[];
  future: number[];
  trend: "up" | "down" | "range";
  rawMatchIndices?: { start: number; end: number };
}

export interface SimilarityWeights {
  pearson: number;
  dtw: number;
  slope: number;
  structural: number;
}

export interface SearchConfig {
  threshold: number; // 70 to 100
  futureCandles: number; // e.g. 20
  patternLength: number; // e.g. 60
  topResults: number; // e.g. 50
  rangeLookback: number; // e.g. 5
  skipOverlap: boolean;
  weights: SimilarityWeights;
}

export interface MyDNAPattern {
  id: string;
  name: string;
  category?: string;
  createdAt: string;
  points: number[];
  normalizedPoints: number[];
  previewSvg?: string;
  notes?: string;
}

export interface TrendBreakdown {
  pctUp: number;
  pctDown: number;
  pctRange: number;
  countUp: number;
  countDown: number;
  countRange: number;
  total: number;
}

export interface CandleWindowData {
  fileName: string;
  symbol: string;
  timeframe: string;
  beforeCount: number;
  afterCount: number;
  patternStart: number;
  patternEnd: number;
  timestamps: string[];
  open: number[];
  high: number[];
  low: number[];
  close: number[];
  volume?: number[];
}
