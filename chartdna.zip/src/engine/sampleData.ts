import { MarketDataset, Candle } from "./types";
import { buildMultiTimeframeSuite } from "./timeframeBuilder";

/**
 * Generates realistic synthetic/geometric market candlestick series using geometric Brownian motion with regime shifts.
 */
export function generateMarketCandles(
  symbol: string,
  startPrice: number,
  volatility: number,
  count: number = 3000,
  startDateStr: string = "2024-01-01 00:00"
): Candle[] {
  const candles: Candle[] = [];
  let currentPrice = startPrice;
  let currentDate = new Date(startDateStr);

  // We embed some recurring classical patterns (Head & Shoulders, Double Top, Triangles, Breakouts)
  let trendBias = 0.0001;

  for (let i = 0; i < count; i++) {
    // Periodically shift trend / regime
    if (i % 250 === 0) {
      trendBias = (Math.random() - 0.5) * 0.003;
    }

    // Add some sine cycles for pattern richness
    const cycle1 = Math.sin(i / 18) * volatility * 0.4;
    const cycle2 = Math.cos(i / 45) * volatility * 0.7;
    const randomNoise = (Math.random() - 0.49) * volatility * 1.5;

    const delta = currentPrice * (trendBias + randomNoise) + cycle1 + cycle2;
    const open = currentPrice;
    let close = currentPrice + delta;
    if (close < startPrice * 0.1) close = startPrice * 0.1; // prevent negative

    const wickTop = Math.random() * volatility * currentPrice * 0.7;
    const wickBottom = Math.random() * volatility * currentPrice * 0.7;

    const high = Math.max(open, close) + wickTop;
    const low = Math.min(open, close) - wickBottom;
    const volume = Math.floor(500 + Math.random() * 2500 + Math.abs(delta) * 10000);

    // Format timestamp
    currentDate = new Date(currentDate.getTime() + 60000); // +1 min
    const dateStr = currentDate.toISOString().replace("T", " ").substring(0, 16);

    candles.push({
      timestamp: dateStr,
      open: Number(open.toFixed(symbol.includes("USD") && !symbol.includes("BTC") ? 4 : 2)),
      high: Number(high.toFixed(symbol.includes("USD") && !symbol.includes("BTC") ? 4 : 2)),
      low: Number(low.toFixed(symbol.includes("USD") && !symbol.includes("BTC") ? 4 : 2)),
      close: Number(close.toFixed(symbol.includes("USD") && !symbol.includes("BTC") ? 4 : 2)),
      volume,
    });

    currentPrice = close;
  }

  return candles;
}

// Generate base market data suites
const eurusdM1 = generateMarketCandles("EURUSD", 1.085, 0.0004, 2500, "2024-02-01 08:00");
const btcusdM1 = generateMarketCandles("BTCUSDT", 64500, 0.0035, 3000, "2024-03-01 00:00");
const xauusdM1 = generateMarketCandles("XAUUSD", 2320, 0.0018, 2500, "2024-03-15 09:00");
const aaplM1 = generateMarketCandles("AAPL", 185, 0.0015, 2000, "2024-04-01 09:30");

export const BUILTIN_DATASETS: MarketDataset[] = [
  ...buildMultiTimeframeSuite("EURUSD", eurusdM1).filter((d) => ["M5", "M15", "H1", "H4"].includes(d.timeframe)),
  ...buildMultiTimeframeSuite("BTCUSDT", btcusdM1).filter((d) => ["M5", "M15", "H1", "H4"].includes(d.timeframe)),
  ...buildMultiTimeframeSuite("XAUUSD", xauusdM1).filter((d) => ["M15", "H1", "H4", "D1"].includes(d.timeframe)),
  ...buildMultiTimeframeSuite("AAPL", aaplM1).filter((d) => ["M15", "H1", "D1"].includes(d.timeframe)),
];
