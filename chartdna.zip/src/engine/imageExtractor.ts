import { normalizeShape, resampleSeries } from "./normalizer";

/**
 * Extracts a normalized 1D price curve from a 2D chart crop ImageData.
 * Exactly replicates the image processing algorithm in ui/dashboard/reference.py
 */
export function extractPathFromImageData(imageData: ImageData): number[] | null {
  const { width, height, data } = imageData;
  if (width < 5 || height < 5) return null;

  // Step 1: Detect background brightness
  let totalBrightness = 0;
  const totalPixels = width * height;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];
    totalBrightness += (r + g + b) / 3;
  }

  const avgBrightness = totalBrightness / totalPixels;
  const isDarkBackground = avgBrightness < 150;

  // Step 2: Build boolean mask for chart line / candle pixels
  // A pixel belongs to the chart line if it is saturated (colored line/candles)
  // or bright white/neon on dark background, or distinct dark on light background.
  const yPositions: (number | null)[] = new Array(width).fill(null);

  for (let x = 0; x < width; x++) {
    const matchingYs: number[] = [];

    for (let y = 0; y < height; y++) {
      const idx = (y * width + x) * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];

      const max = Math.max(r, g, b);
      const min = Math.min(r, g, b);
      const saturation = max - min;

      const isColored = saturation > 40 && max > 60;
      const isBright = r > 185 && g > 185 && b > 185;
      const isDarkInk = r < 90 && g < 90 && b < 90 && !isDarkBackground;

      let isMatch = false;
      if (isDarkBackground) {
        isMatch = isColored || isBright;
      } else {
        isMatch = isColored || isDarkInk;
      }

      if (isMatch) {
        matchingYs.push(y);
      }
    }

    if (matchingYs.length > 0) {
      matchingYs.sort((a, b) => a - b);
      const mid = Math.floor(matchingYs.length / 2);
      const medianY =
        matchingYs.length % 2 !== 0
          ? matchingYs[mid]
          : (matchingYs[mid - 1] + matchingYs[mid]) / 2;
      yPositions[x] = medianY;
    }
  }

  // Step 3: Check valid columns count
  const validIndices: number[] = [];
  yPositions.forEach((y, idx) => {
    if (y !== null) validIndices.push(idx);
  });

  const minRequiredValid = Math.max(10, Math.floor(width * 0.08));
  if (validIndices.length < minRequiredValid) {
    // Fallback: If strict color filter didn't find enough, try contrast edge detection
    return extractPathByLuminanceEdges(imageData);
  }

  // Step 4: Linear interpolation only between firstValid and lastValid
  const firstValid = validIndices[0];
  const lastValid = validIndices[validIndices.length - 1];
  const trimmedWidth = lastValid - firstValid + 1;

  if (trimmedWidth < 10) return null;

  const interpolatedY: number[] = new Array(trimmedWidth);

  for (let i = 0; i < trimmedWidth; i++) {
    const x = firstValid + i;
    if (yPositions[x] !== null) {
      interpolatedY[i] = yPositions[x]!;
    } else {
      // Find previous valid and next valid for interpolation
      let prevIdx = -1;
      let nextIdx = -1;

      for (let j = x - 1; j >= firstValid; j--) {
        if (yPositions[j] !== null) {
          prevIdx = j;
          break;
        }
      }
      for (let j = x + 1; j <= lastValid; j++) {
        if (yPositions[j] !== null) {
          nextIdx = j;
          break;
        }
      }

      if (prevIdx !== -1 && nextIdx !== -1) {
        const factor = (x - prevIdx) / (nextIdx - prevIdx);
        interpolatedY[i] =
          yPositions[prevIdx]! + factor * (yPositions[nextIdx]! - yPositions[prevIdx]!);
      } else if (prevIdx !== -1) {
        interpolatedY[i] = yPositions[prevIdx]!;
      } else if (nextIdx !== -1) {
        interpolatedY[i] = yPositions[nextIdx]!;
      } else {
        interpolatedY[i] = height / 2;
      }
    }
  }

  // Step 5: Invert Y so up is higher price
  const priceLikePath = interpolatedY.map((y) => -y);

  // Step 6: Edge-padded moving average convolution smoothing
  const windowSize = Math.max(3, Math.min(15, Math.floor(trimmedWidth / 25)));
  const smoothed = convolveWithEdgePadding(priceLikePath, windowSize);

  // Step 7: Trim margins to remove edge artifacts
  const margin = Math.max(2, Math.round(trimmedWidth * 0.02));
  const finalTrimmed =
    trimmedWidth - 2 * margin >= 10
      ? smoothed.slice(margin, trimmedWidth - margin)
      : smoothed;

  // Step 8: Resample to 500 points & normalize shape
  return normalizeShape(resampleSeries(finalTrimmed, 500));
}

function convolveWithEdgePadding(series: number[], windowSize: number): number[] {
  const n = series.length;
  if (n <= windowSize) return series;

  const padLeft = Math.floor((windowSize - 1) / 2);
  const padRight = windowSize - 1 - padLeft;

  const padded: number[] = [
    ...new Array(padLeft).fill(series[0]),
    ...series,
    ...new Array(padRight).fill(series[n - 1]),
  ];

  const result: number[] = [];
  for (let i = 0; i < n; i++) {
    let sum = 0;
    for (let j = 0; j < windowSize; j++) {
      sum += padded[i + j];
    }
    result.push(sum / windowSize);
  }

  return result;
}

function extractPathByLuminanceEdges(imageData: ImageData): number[] | null {
  const { width, height, data } = imageData;
  const colCenters: number[] = [];

  for (let x = 0; x < width; x++) {
    let weightedYSum = 0;
    let weightSum = 0;

    for (let y = 0; y < height; y++) {
      const idx = (y * width + x) * 4;
      const lum = (data[idx] * 0.299 + data[idx + 1] * 0.587 + data[idx + 2] * 0.114);
      // High contrast weight
      const weight = Math.abs(lum - 128);
      if (weight > 30) {
        weightedYSum += y * weight;
        weightSum += weight;
      }
    }

    colCenters.push(weightSum > 0 ? -(weightedYSum / weightSum) : 0);
  }

  return normalizeShape(resampleSeries(colCenters, 500));
}
