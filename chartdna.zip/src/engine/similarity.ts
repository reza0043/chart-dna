import { dtwSimilarity } from "./dtw";
import { structuralSimilarity } from "./patternDetector";
import { SimilarityWeights } from "./types";

/**
 * Calculates Pearson Correlation Coefficient r between two series.
 * Bounds r from [-1, 1] into [0, 1] for similarity percentage calculation.
 */
export function pearsonSimilarity(x: number[], y: number[]): number {
  const n = x.length;
  if (n !== y.length || n < 2) return 0;

  const meanX = x.reduce((a, b) => a + b, 0) / n;
  const meanY = y.reduce((a, b) => a + b, 0) / n;

  let num = 0;
  let denX = 0;
  let denY = 0;

  for (let i = 0; i < n; i++) {
    const dx = x[i] - meanX;
    const dy = y[i] - meanY;
    num += dx * dy;
    denX += dx * dx;
    denY += dy * dy;
  }

  const denom = Math.sqrt(denX * denY);
  if (denom < 1e-9) return 0;

  const r = num / denom;
  // Map Pearson correlation [-1, 1] to [0, 1]
  return Math.max(0, Math.min(1, (r + 1) / 2));
}

/**
 * Calculates slope/gradient similarity between two series.
 */
export function slopeSimilarity(x: number[], y: number[]): number {
  const n = x.length;
  if (n !== y.length || n < 2) return 0;

  let matches = 0;
  for (let i = 1; i < n; i++) {
    const dx = x[i] - x[i - 1];
    const dy = y[i] - y[i - 1];

    if ((dx >= 0 && dy >= 0) || (dx <= 0 && dy <= 0)) {
      matches++;
    }
  }

  return matches / (n - 1);
}

/**
 * Calculates Mean Absolute Difference similarity on normalized [0, 1] scale.
 */
export function meanAbsDiffSimilarity(x: number[], y: number[]): number {
  const n = x.length;
  if (n !== y.length || n === 0) return 0;

  let sumDiff = 0;
  for (let i = 0; i < n; i++) {
    sumDiff += Math.abs(x[i] - y[i]);
  }

  const mad = sumDiff / n;
  return Math.max(0, 1.0 - mad / 2.0);
}

export const DEFAULT_WEIGHTS: SimilarityWeights = {
  pearson: 0.40,
  dtw: 0.30,
  slope: 0.15,
  structural: 0.15,
};

/**
 * Combines Pearson, DTW, Slope, and Structural similarities.
 * Returns a score in range [0, 1].
 */
export function combinedSimilarity(
  p1: number[],
  p2: number[],
  weights: SimilarityWeights = DEFAULT_WEIGHTS
): number {
  if (p1.length === 0 || p2.length === 0) return 0;

  const pScore = pearsonSimilarity(p1, p2);
  const dScore = dtwSimilarity(p1, p2);
  const sScore = slopeSimilarity(p1, p2);
  const strScore = structuralSimilarity(p1, p2);

  const totalWeight =
    weights.pearson + weights.dtw + weights.slope + weights.structural;

  if (totalWeight <= 0) return pScore;

  const score =
    (pScore * weights.pearson +
      dScore * weights.dtw +
      sScore * weights.slope +
      strScore * weights.structural) /
    totalWeight;

  return Math.max(0, Math.min(1, score));
}
