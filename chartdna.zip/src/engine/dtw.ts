/**
 * Dynamic Time Warping (DTW) Implementation with Sakoe-Chiba band constraint.
 * Ported from engine_core/dtw.py
 */

export function dtwDistance(s1: number[], s2: number[], w?: number): number {
  const n = s1.length;
  const m = s2.length;
  if (n === 0 || m === 0) return Infinity;

  // Window constraint
  const window = w !== undefined ? Math.max(w, Math.abs(n - m)) : Math.max(n, m);

  // Initialize DP matrix with Infinity
  const dtw: number[][] = Array.from({ length: n + 1 }, () =>
    new Array(m + 1).fill(Infinity)
  );
  dtw[0][0] = 0;

  for (let i = 1; i <= n; i++) {
    const jStart = Math.max(1, i - window);
    const jEnd = Math.min(m, i + window);

    for (let j = jStart; j <= jEnd; j++) {
      const cost = Math.abs(s1[i - 1] - s2[j - 1]);
      dtw[i][j] = cost + Math.min(
        dtw[i - 1][j],     // insertion
        dtw[i][j - 1],     // deletion
        dtw[i - 1][j - 1]  // match
      );
    }
  }

  return dtw[n][m];
}

export function dtwSimilarity(s1: number[], s2: number[], w?: number): number {
  const dist = dtwDistance(s1, s2, w);
  if (!isFinite(dist)) return 0;
  // Normalized distance per step
  const maxLen = Math.max(s1.length, s2.length);
  const normalizedDist = dist / (maxLen || 1);
  return 1.0 / (1.0 + normalizedDist);
}
