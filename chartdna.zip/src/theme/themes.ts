export type ThemeId =
  | "cyber-obsidian"
  | "tokyo-midnight"
  | "emerald-matrix"
  | "royal-amber"
  | "solar-flare"
  | "arctic-frost"
  | "synthwave-80s"
  | "titanium-slate"
  | "carbon-oled"
  | "high-tech-light";

export interface ThemeDefinition {
  id: ThemeId;
  name: {
    en: string;
    fa: string;
    ar: string;
    es: string;
    fr: string;
    de: string;
    ru: string;
    zh: string;
    tr: string;
    ja: string;
  };
  description: {
    en: string;
    fa: string;
    ar: string;
    es: string;
    fr: string;
    de: string;
    ru: string;
    zh: string;
    tr: string;
    ja: string;
  };
  isLight: boolean;
  colors: {
    primary: string; // main accent
    primaryHover: string;
    primaryText: string;
    secondary: string; // secondary accent
    bg: string; // main page background
    cardBg: string; // card container background
    subpanelBg: string; // inner box / row / toolbar background
    headerBg: string;
    sidebarBg: string;
    border: string;
    borderSubtle: string;
    text: string;
    textMuted: string;
    dnaLine: string; // reference line in comparative chart
    matchedLine: string; // matched historical pattern line
    futureLine: string; // forward outcome projection line
  };
  glowClass: string;
  badgeClass: string;
}

export const THEMES: ThemeDefinition[] = [
  {
    id: "cyber-obsidian",
    name: {
      en: "Cyber Obsidian",
      fa: "سایبر آبسیدین (پیش‌فرض)",
      ar: "حجر السج السيبراني",
      es: "Obsidiana Cyber",
      fr: "Obsidienne Cyber",
      de: "Cyber Obsidian",
      ru: "Кибер Обсидиан",
      zh: "赛博黑曜石 (默认)",
      tr: "Siber Obsidyen",
      ja: "サイバー・オブシディアン",
    },
    description: {
      en: "Deep obsidian black with electric cyan and emerald laser highlights",
      fa: "پس‌زمینه آبسیدین عمیق با نورهای نئونی سایان لیزری و هایلایت‌های زمردی",
      ar: "خلفية سبجية داكنة مع لمسات باللون السماوي والزمردي المشع",
      es: "Negro obsidiana profundo con reflejos cian eléctrico y esmeralda láser",
      fr: "Noir obsidienne profond avec reflets cyan électrique et émeraude laser",
      de: "Tiefes Obsidian-Schwarz mit elektrischem Cyan & Smaragd-Laser",
      ru: "Глубокий обсидиановый с неоновым цианом и изумрудным лазером",
      zh: "深邃黑曜石底色搭配电光青与翡翠绿激光高光",
      tr: "Elektrik camgöbeği ve zümrüt lazer vurgulu derin obsidyen siyahı",
      ja: "ディープ・オブシディアンに電光シアンとエメラルドのレーザー光",
    },
    isLight: false,
    colors: {
      primary: "#06b6d4",
      primaryHover: "#0891b2",
      primaryText: "#ffffff",
      secondary: "#10b981",
      bg: "#060913",
      cardBg: "#0b101c",
      subpanelBg: "#101728",
      headerBg: "#080c18",
      sidebarBg: "#0b101c",
      border: "rgba(30, 41, 59, 0.7)",
      borderSubtle: "rgba(30, 41, 59, 0.45)",
      text: "#f8fafc",
      textMuted: "#94a3b8",
      dnaLine: "#38bdf8",
      matchedLine: "#10b981",
      futureLine: "#f59e0b",
    },
    glowClass: "shadow-cyan-500/25",
    badgeClass: "bg-cyan-950/80 border-cyan-500/40 text-cyan-400",
  },
  {
    id: "tokyo-midnight",
    name: {
      en: "Tokyo Midnight",
      fa: "توکیو نیمه‌شب (بنفش و نئون)",
      ar: "منتصف ليل طوكيو",
      es: "Medianoche de Tokio",
      fr: "Tokyo Minuit",
      de: "Tokyo Mitternacht",
      ru: "Токио Полночь",
      zh: "东京午夜 (霓虹紫粉)",
      tr: "Tokyo Gece Yarısı",
      ja: "東京ミッドナイト (紫＆ネオン)",
    },
    description: {
      en: "Tokyo neon nightscape with vivid ultraviolet, deep indigo & electric magenta",
      fa: "فضای کلان‌شهر توکیو در شب با طیف ماوراء بنفش، ایندیگو و ماژنتای درخشان",
      ar: "أجواء طوكيو الليلية بألوان فوق البنفسجية والنيلي والماجنتا المتوهجة",
      es: "Paisaje nocturno de Tokio con ultravioleta vivo, índigo y magenta eléctrico",
      fr: "Nuit tokyoïte au néon avec ultraviolet éclatant, indigo profond et magenta",
      de: "Tokioter Neon-Nachtlandschaft mit Ultraviolett, Indigo & Magenta",
      ru: "Неоновый Токио с ультрафиолетом, глубоким индиго и яркой маджентой",
      zh: "东京赛博霓虹夜景，浓郁紫外光搭配电光品红与深靛蓝",
      tr: "Canlı ultraviyole, derin çivit ve elektrik macenta ile Tokyo neon gecesi",
      ja: "鮮烈なウルトラバイオレットとエレクトリック・マゼンタの夜景",
    },
    isLight: false,
    colors: {
      primary: "#a855f7",
      primaryHover: "#9333ea",
      primaryText: "#ffffff",
      secondary: "#ec4899",
      bg: "#070412",
      cardBg: "#0e0922",
      subpanelBg: "#170f38",
      headerBg: "#0a061a",
      sidebarBg: "#0e0922",
      border: "rgba(147, 51, 234, 0.4)",
      borderSubtle: "rgba(147, 51, 234, 0.22)",
      text: "#faf5ff",
      textMuted: "#d8b4fe",
      dnaLine: "#c084fc",
      matchedLine: "#f472b6",
      futureLine: "#38bdf8",
    },
    glowClass: "shadow-purple-500/25",
    badgeClass: "bg-purple-950/80 border-purple-500/40 text-purple-300",
  },
  {
    id: "emerald-matrix",
    name: {
      en: "Emerald Matrix",
      fa: "ماتریکس زمردی (سبز هکری)",
      ar: "مصفوفة الزمرد",
      es: "Matriz Esmeralda",
      fr: "Matrice Émeraude",
      de: "Smaragd-Matrix",
      ru: "Изумрудная Матрица",
      zh: "翡翠黑客帝国 (极客绿)",
      tr: "Zümrüt Matris",
      ja: "エメラルド・マトリックス",
    },
    description: {
      en: "Tactical terminal green with phosphor mint scanlines and deep jungle shadow",
      fa: "سبز ترمینال تاکتیکال با نورهای فسفری نعنایی و خطوط اسکن با کنتراست بالا",
      ar: "لون أخضر عسكري تكتيكي مع إضاءة فسفورية وظلال غابة عميقة",
      es: "Verde terminal táctico con líneas de fósforo menta y sombras profundas",
      fr: "Vert terminal tactique avec lignes phosphorescentes menthe et ombres intenses",
      de: "Taktisches Terminal-Grün mit Phosphor-Mint und tiefen Dschungel-Schatten",
      ru: "Тактический терминальный зеленый с фосфорным мятным свечением",
      zh: "经典终端战术绿，荧光薄荷扫描线与深邃黑底",
      tr: "Fosfor nane tarama çizgileri ve derin orman gölgeli taktik terminal yeşili",
      ja: "タクティカル端末グリーンと蛍光ミントの走査線",
    },
    isLight: false,
    colors: {
      primary: "#10b981",
      primaryHover: "#059669",
      primaryText: "#ffffff",
      secondary: "#34d399",
      bg: "#030e09",
      cardBg: "#061811",
      subpanelBg: "#0b2a1e",
      headerBg: "#04130d",
      sidebarBg: "#061811",
      border: "rgba(16, 185, 129, 0.4)",
      borderSubtle: "rgba(16, 185, 129, 0.2)",
      text: "#ecfdf5",
      textMuted: "#6ee7b7",
      dnaLine: "#34d399",
      matchedLine: "#10b981",
      futureLine: "#fbbf24",
    },
    glowClass: "shadow-emerald-500/25",
    badgeClass: "bg-emerald-950/80 border-emerald-500/40 text-emerald-300",
  },
  {
    id: "royal-amber",
    name: {
      en: "Royal Amber & Gold",
      fa: "کهربای سلطنتی و طلا",
      ar: "الكهرمان الملكي والذهب",
      es: "Ámbar Real y Oro",
      fr: "Ambre Royal et Or",
      de: "Königlicher Bernstein & Gold",
      ru: "Королевский Янтарь и Золото",
      zh: "皇家琥珀金 (尊享金黄)",
      tr: "Kraliyet Kehribarı ve Altın",
      ja: "ロイヤル・アンバー＆ゴールド",
    },
    description: {
      en: "Opulent luxury trading terminal with burnished gold, warm honey & topaz crystal",
      fa: "ترمینال معاملاتی لوکس با رگه‌های طلای صیقلی، عسلی گرم و کریستال‌های توپاز",
      ar: "منصة تداول فاخرة بالذهب المصقول والعسل الدافئ وكريستال التوباز",
      es: "Terminal de trading de lujo con oro pulido, miel cálida y cristal de topacio",
      fr: "Terminal de trading luxueux avec or bruni, miel chaud et cristal de topaze",
      de: "Luxuriöses Trading-Terminal mit poliertem Gold, warmem Honig & Topas",
      ru: "Роскошный торговый терминал с полированным золотом и теплым медом",
      zh: "奢华交易终端，流光抛光金与暖蜜蜡黄质感",
      tr: "Parlak altın, sıcak bal ve topaz kristalli lüks ticaret terminali",
      ja: "重厚なポリッシュドゴールドと温かみある琥珀ハニーの高級感",
    },
    isLight: false,
    colors: {
      primary: "#f59e0b",
      primaryHover: "#d97706",
      primaryText: "#181005",
      secondary: "#eab308",
      bg: "#0c0803",
      cardBg: "#171007",
      subpanelBg: "#251b0d",
      headerBg: "#120c05",
      sidebarBg: "#171007",
      border: "rgba(245, 158, 11, 0.4)",
      borderSubtle: "rgba(245, 158, 11, 0.2)",
      text: "#fffbeb",
      textMuted: "#fde68a",
      dnaLine: "#fbbf24",
      matchedLine: "#f59e0b",
      futureLine: "#38bdf8",
    },
    glowClass: "shadow-amber-500/25",
    badgeClass: "bg-amber-950/80 border-amber-500/40 text-amber-300",
  },
  {
    id: "solar-flare",
    name: {
      en: "Solar Flare",
      fa: "شراره خورشیدی (آتشفشانی)",
      ar: "التوهج الشمسي",
      es: "Llamarada Solar",
      fr: "Éruption Solaire",
      de: "Sonneneruption",
      ru: "Солнечная Вспышка",
      zh: "耀斑风暴 (熔岩炽红)",
      tr: "Güneş Parlaması",
      ja: "ソーラー・フレア (溶岩レッド)",
    },
    description: {
      en: "Volcanic energy with molten lava orange, ruby crimson and fiery plasma sparks",
      fa: "انرژی حرارتی آتشفشانی با نارنجی مذاب گدازه، یاقوت سرخ و جرقه‌های پلاسما",
      ar: "طاقة بركانية مع برتقالي الحمم المنصهرة والياقوتي وشرارات البلازما",
      es: "Energía volcánica con naranja de lava fundida, carmesí rubí y chispas de plasma",
      fr: "Énergie volcanique avec orange lave en fusion, pourpre rubis et plasma ardent",
      de: "Vulkanische Energie mit flüssigem Lava-Orange, Rubinrot & feurigem Plasma",
      ru: "Вулканическая энергия с лавовым оранжевым, рубиновым и огненной плазмой",
      zh: "火山熔岩赤橙与炽热等离子烈焰，能量澎湃",
      tr: "Erimiş lav turuncusu, yakut kırmızısı ve ateşli plazma kıvılcımları",
      ja: "溶岩オレンジとルビークリムゾンの灼熱プラズマエネルギー",
    },
    isLight: false,
    colors: {
      primary: "#f97316",
      primaryHover: "#ea580c",
      primaryText: "#ffffff",
      secondary: "#ef4444",
      bg: "#0e0505",
      cardBg: "#1a0b0b",
      subpanelBg: "#2b1212",
      headerBg: "#140707",
      sidebarBg: "#1a0b0b",
      border: "rgba(249, 115, 22, 0.4)",
      borderSubtle: "rgba(249, 115, 22, 0.2)",
      text: "#fff1f2",
      textMuted: "#fda4af",
      dnaLine: "#fb923c",
      matchedLine: "#ef4444",
      futureLine: "#facc15",
    },
    glowClass: "shadow-orange-500/25",
    badgeClass: "bg-orange-950/80 border-orange-500/40 text-orange-300",
  },
  {
    id: "arctic-frost",
    name: {
      en: "Arctic Frost",
      fa: "یخچال قطبی (آبی کریستالی)",
      ar: "صقيع القطب الشمالي",
      es: "Escarcha Ártica",
      fr: "Givre Arctique",
      de: "Arktischer Frost",
      ru: "Арктический Мороз",
      zh: "极地冰霜 (水晶湛蓝)",
      tr: "Kutup Donu",
      ja: "アークティック・フロスト (氷晶ブルー)",
    },
    description: {
      en: "Sub-zero crystalline fjord blue with glaciated cyan and hyper-clean diamond hue",
      fa: "آبی کریستالی یخچال‌های قطبی زیر صفر با سایان یخ‌زده و درخشش الماسی شفاف",
      ar: "أزرق جليدي نقي تحت الصفر مع سيان جليدي ولمعان ماسي فائق الوضوح",
      es: "Azul fiordo cristalino bajo cero con cian glaciar y tono de diamante limpio",
      fr: "Bleu fjord cristallin glacial avec cyan givré et éclat diamant ultra-pur",
      de: "Kristallines Fjord-Blau mit eisigem Cyan und diamantklarer Reinheit",
      ru: "Ледяной кристальный синий с ледниковым цианом и алмазной чистотой",
      zh: "零度极地晶蓝，冰川青霜与高纯度钻石棱光",
      tr: "Buzul camgöbeği ve elmas parlaklığında kristal fiyort mavisi",
      ja: "氷河の透明感をたたえる極寒クリスタルブルー＆ダイヤモンド",
    },
    isLight: false,
    colors: {
      primary: "#38bdf8",
      primaryHover: "#0284c7",
      primaryText: "#03172e",
      secondary: "#22d3ee",
      bg: "#050b14",
      cardBg: "#091629",
      subpanelBg: "#0e2444",
      headerBg: "#060f1b",
      sidebarBg: "#091629",
      border: "rgba(56, 189, 248, 0.4)",
      borderSubtle: "rgba(56, 189, 248, 0.2)",
      text: "#f0f9ff",
      textMuted: "#7dd3fc",
      dnaLine: "#38bdf8",
      matchedLine: "#22d3ee",
      futureLine: "#4ade80",
    },
    glowClass: "shadow-sky-500/25",
    badgeClass: "bg-sky-950/80 border-sky-500/40 text-sky-300",
  },
  {
    id: "synthwave-80s",
    name: {
      en: "Synthwave 80s",
      fa: "سینت‌ویو دهه ۸۰ (رترو سایبر)",
      ar: "سينث ويف الثمانينات",
      es: "Synthwave Ochentero",
      fr: "Synthwave Années 80",
      de: "Synthwave 80er",
      ru: "Синтвейв 80-х",
      zh: "80年代复古合成波",
      tr: "80'ler Synthwave",
      ja: "80s シンセウェーブ",
    },
    description: {
      en: "Retro arcade nightlife with vibrant hot pink, electric violet & laser teal",
      fa: "نوستالژی رترو کلاب‌های شبانه با رنگ‌های صورتی نئونی، بنفش و فیروزه‌ای لیزری",
      ar: "أجواء ألعاب الثمانينات مع الوردي الصاخب والبنفسجي الكهربائي",
      es: "Noche retro arcade con rosa intenso, violeta eléctrico y cian láser",
      fr: "Ambiance arcade rétro avec rose vif, violet électrique et sarcelle laser",
      de: "Retro-Arcade mit lebhaftem Pink, elektrischem Violett & Laser-Türkis",
      ru: "Ретро-аркада 80-х с неоновым розовым, электрическим фиолетовым и бирюзой",
      zh: "复古街机霓虹夜市搭配电光洋红与激光青蓝",
      tr: "Canlı sıcak pembe, elektrik mor ve lazer camgöbeği ile retro atari gecesi",
      ja: "レトロアーケードの夜景を彩るホットピンクとエレクトリック・バイオレット",
    },
    isLight: false,
    colors: {
      primary: "#d946ef",
      primaryHover: "#c026d3",
      primaryText: "#ffffff",
      secondary: "#06b6d4",
      bg: "#090518",
      cardBg: "#140c30",
      subpanelBg: "#21144f",
      headerBg: "#0d0723",
      sidebarBg: "#140c30",
      border: "rgba(217, 70, 239, 0.4)",
      borderSubtle: "rgba(217, 70, 239, 0.2)",
      text: "#fdf4ff",
      textMuted: "#f0abfc",
      dnaLine: "#e879f9",
      matchedLine: "#22d3ee",
      futureLine: "#fde047",
    },
    glowClass: "shadow-fuchsia-500/25",
    badgeClass: "bg-fuchsia-950/80 border-fuchsia-500/40 text-fuchsia-300",
  },
  {
    id: "titanium-slate",
    name: {
      en: "Titanium Slate",
      fa: "تیتانیوم اسلیت (فولادی مینیمال)",
      ar: "أردواز التيتانيوم",
      es: "Pizarra de Titanio",
      fr: "Ardoise Titane",
      de: "Titan-Schiefer",
      ru: "Титановый Сланец",
      zh: "钛金青灰 (工业极简)",
      tr: "Titanyum Arduvaz",
      ja: "チタニウム・スレート (工業ミニマル)",
    },
    description: {
      en: "Engineered aerospace metal with brushed graphite slate and precision cobalt lines",
      fa: "متریال مهندسی هوافضا با گرافیت برس‌خورده و خطوط کبالت دقیق و مینیمال",
      ar: "معدن فضائي هندسي مع جرافيت مصقول وخطوط كوبالت دقيقة",
      es: "Metal aeroespacial con pizarra de grafito cepillado y líneas de cobalto",
      fr: "Métal aérospatial avec graphite brossé et lignes cobalt de haute précision",
      de: "Luft- und Raumfahrtmetall mit gebürstetem Graphitschiefer und Kobalt",
      ru: "Аэрокосмический металл с матовым графитом и точными линиями кобальта",
      zh: "航空工程级拉丝石墨灰，搭配精准钴蓝线条",
      tr: "Fırçalanmış grafit arduvaz ve hassas kobalt çizgili havacılık metali",
      ja: "航空宇宙グレードのヘアライン石墨と高精度コバルトライン",
    },
    isLight: false,
    colors: {
      primary: "#60a5fa",
      primaryHover: "#3b82f6",
      primaryText: "#ffffff",
      secondary: "#94a3b8",
      bg: "#0a0d14",
      cardBg: "#121724",
      subpanelBg: "#1c2438",
      headerBg: "#0c111a",
      sidebarBg: "#121724",
      border: "rgba(148, 163, 184, 0.35)",
      borderSubtle: "rgba(148, 163, 184, 0.18)",
      text: "#f8fafc",
      textMuted: "#cbd5e1",
      dnaLine: "#94a3b8",
      matchedLine: "#60a5fa",
      futureLine: "#fbbf24",
    },
    glowClass: "shadow-slate-500/25",
    badgeClass: "bg-slate-900 border-slate-700 text-slate-300",
  },
  {
    id: "carbon-oled",
    name: {
      en: "Carbon OLED Pure Black",
      fa: "کربن OLED مشکی خالص",
      ar: "كربون OLED أسود نقي",
      es: "Carbono OLED Negro Puro",
      fr: "Carbone OLED Noir Pur",
      de: "Carbon OLED Reines Schwarz",
      ru: "Карбон OLED Чистый Черный",
      zh: "碳纤 OLED 纯黑",
      tr: "Karbon OLED Saf Siyah",
      ja: "カーボン OLED ピュアブラック",
    },
    description: {
      en: "True 100% pitch black OLED canvas for maximum contrast and zero battery drain",
      fa: "صفحه ۱۰۰٪ مشکی مطلق اولد با کنتراست حداکثری و شفافیت فوق‌العاده چشم‌نواز",
      ar: "شاشة سوداء نقية 100% بتقنية OLED لأقصى درجات التباين والوضوح",
      es: "Lienzo OLED 100% negro puro para máximo contraste y cero fatiga visual",
      fr: "Noir OLED 100% pur pour un contraste maximal et une clarté absolue",
      de: "Echtes 100% tiefschwarzes OLED-Design für maximalen Kontrast",
      ru: "Абсолютно черный 100% OLED экран для максимальной контрастности",
      zh: "真 100% 纯黑 OLED 视界，超高对比度与纯粹黑客质感",
      tr: "Maksimum kontrast ve sıfır göz yorgunluğu için %100 saf siyah OLED",
      ja: "最高コントラストを誇る真の100%ピュアブラックOLED",
    },
    isLight: false,
    colors: {
      primary: "#22c55e",
      primaryHover: "#16a34a",
      primaryText: "#000000",
      secondary: "#06b6d4",
      bg: "#000000",
      cardBg: "#0a0a0a",
      subpanelBg: "#141414",
      headerBg: "#050505",
      sidebarBg: "#0a0a0a",
      border: "rgba(34, 197, 94, 0.35)",
      borderSubtle: "rgba(255, 255, 255, 0.12)",
      text: "#ffffff",
      textMuted: "#a3a3a3",
      dnaLine: "#4ade80",
      matchedLine: "#38bdf8",
      futureLine: "#facc15",
    },
    glowClass: "shadow-green-500/25",
    badgeClass: "bg-neutral-800 border-neutral-700 text-green-400",
  },
  {
    id: "high-tech-light",
    name: {
      en: "High-Tech Daylight",
      fa: "دی‌لایت مدرن (تم روشن)",
      ar: "ضوء النهار عالي التقنية",
      es: "Luz Diurna Alta Tecnología",
      fr: "Lumière du Jour High-Tech",
      de: "High-Tech Tageslicht",
      ru: "Высокотехнологичный Светлый",
      zh: "明亮昼光 (极简高精)",
      tr: "Yüksek Teknoloji Gün Işığı",
      ja: "ハイテック・デイライト (ライト)",
    },
    description: {
      en: "Sophisticated pearl white laboratory canvas with crisp indigo & emerald precision",
      fa: "محیط آزمایشگاهی مدرن سفید مرواریدی با خطوط با کنتراست ایندیگو و زمردی",
      ar: "خلفية لؤلؤية بيضاء متطورة ومشرقة مع دقة زرقاء وزمردية عالية التباين",
      es: "Lienzo de laboratorio blanco perla con precisión índigo y esmeralda",
      fr: "Fond blanc perle ultra-propre avec précision indigo et émeraude",
      de: "Raffiniertes perlweißes Labor-Design mit präzisen Indigo- & Smaragd-Linien",
      ru: "Изысканный жемчужно-белый лабораторный стиль с индиго и изумрудом",
      zh: "高科技珠光白实验室界面，搭配精准深蓝与翡翠绿",
      tr: "İndigo ve zümrüt hassasiyetinde sofistike inci beyazı aydınlık tema",
      ja: "洗練されたパールホワイトに高精細インディゴ＆エメラルド",
    },
    isLight: true,
    colors: {
      primary: "#2563eb",
      primaryHover: "#1d4ed8",
      primaryText: "#ffffff",
      secondary: "#059669",
      bg: "#f1f5f9",
      cardBg: "#ffffff",
      subpanelBg: "#f8fafc",
      headerBg: "#ffffff",
      sidebarBg: "#ffffff",
      border: "rgba(203, 213, 225, 0.9)",
      borderSubtle: "rgba(226, 232, 240, 0.85)",
      text: "#0f172a",
      textMuted: "#475569",
      dnaLine: "#2563eb",
      matchedLine: "#059669",
      futureLine: "#d97706",
    },
    glowClass: "shadow-blue-500/15",
    badgeClass: "bg-blue-50 border-blue-200 text-blue-700",
  },
];

export function getTheme(themeId: ThemeId): ThemeDefinition {
  return THEMES.find((t) => t.id === themeId) || THEMES[0];
}

export function applyThemeVariables(theme: ThemeDefinition) {
  const root = document.documentElement;
  root.style.setProperty("--theme-bg", theme.colors.bg);
  root.style.setProperty("--theme-card-bg", theme.colors.cardBg);
  root.style.setProperty("--theme-subpanel-bg", theme.colors.subpanelBg);
  root.style.setProperty("--theme-header-bg", theme.colors.headerBg);
  root.style.setProperty("--theme-sidebar-bg", theme.colors.sidebarBg);
  root.style.setProperty("--theme-border", theme.colors.border);
  root.style.setProperty("--theme-border-subtle", theme.colors.borderSubtle);
  root.style.setProperty("--theme-text", theme.colors.text);
  root.style.setProperty("--theme-text-muted", theme.colors.textMuted);
  root.style.setProperty("--theme-primary", theme.colors.primary);
  root.style.setProperty("--theme-primary-hover", theme.colors.primaryHover);
  root.style.setProperty("--theme-primary-text", theme.colors.primaryText);
  root.style.setProperty("--theme-secondary", theme.colors.secondary);
  root.style.setProperty("--theme-dna-line", theme.colors.dnaLine);
  root.style.setProperty("--theme-matched-line", theme.colors.matchedLine);
  root.style.setProperty("--theme-future-line", theme.colors.futureLine);
}
